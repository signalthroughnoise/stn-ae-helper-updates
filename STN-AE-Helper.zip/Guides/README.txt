STN - AE Helper · Social Guides
================================

Every image in this folder shows up in Edit ▸ Social Guides.
- Subfolders become headings in the dropdown.
- A leading number ("01 ", "02 ") sets the order and is hidden in the list.
- PNG with transparency works best. Any size: guides are scaled to fit the
  sequence frame when added.

Safe-zone numbers used (on 1080×1920 unless noted), as of Oct 2026:
- Instagram & Facebook Reels: top 14%, bottom 35%, sides 6% (Meta guidance)
- Instagram & Facebook Stories: top 14%, bottom 20%, sides 6% (Meta guidance)
- TikTok: top 130, bottom 484 (minimum — longer captions cover more),
  left 44, right 140 px (TikTok ad safe-zone template)
- YouTube Shorts: top 288, bottom 672, left 48, right 192 px
  (Google universal safe zone for vertical video ads)
- Snapchat: top 150, bottom 330, no side margin (published Snap Ads spec,
  third-party source)
- Universal 9:16: the strictest of all of the above
- Feed 4:5 / 1:1: 5% margin (no platform UI sits over feed posts; also covers
  Instagram's 3:4 profile-grid crop)
- 16:9: SMPTE action safe 93%, title safe 90%; crop guides are center cuts

UI mockups (04 9x16 UI Mockups): approximate, generic layouts with a dummy
@yourbrand account — positions match each platform's safe zones, but they are
not the apps' actual artwork. Anything with "mockup" in its folder or file
name is added at 100% opacity; everything else at 50%.

Platforms change their interfaces — re-check these specs every few months.
