Panel background logo
- logo.png                 your original artwork (not used directly by the panel)
- logo_dark-theme.png      shown on the dark theme (light letters, trimmed)
- logo_light-theme.png     shown on the light theme (original colors, trimmed)
Shown very faintly in the bottom-right. Delete both theme files to hide it.
