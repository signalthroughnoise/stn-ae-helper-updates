/*
 * Deckhand Audio — voice-over recording.
 *
 * The panel is Chromium, so the capture side is Web Audio: enumerateDevices
 * for the input list, getUserMedia for the stream, an AnalyserNode for the
 * meter, and a ScriptProcessor tap for the samples.
 *
 * Two things drive the shape of this file:
 *
 * 1. MediaRecorder cannot produce WAV - it gives webm/opus. Premiere would
 *    have to conform that, and it would not match the VO tool's output. So we
 *    take the raw Float32 frames off a ScriptProcessor and write the RIFF
 *    header ourselves: 48 kHz, 16-bit, mono.
 *
 * 2. Microphone permission belongs to Premiere, not to this panel. macOS
 *    grants it to the host application, so Premiere Pro must be enabled under
 *    Privacy & Security > Microphone. Until something inside Premiere has
 *    asked once, it will not even be listed there. Device labels also stay
 *    blank until permission is granted, which is why the input list is only
 *    populated after the first successful getUserMedia.
 */
var DeckhandAudio = (function () {

  var fs, path;
  var NODE_OK = true;
  try { fs = require("fs"); path = require("path"); } catch (e) { NODE_OK = false; }

  var acs = null;
  try { acs = new CSInterface(); } catch (eC) { acs = null; }

  var TARGET_RATE = 48000;
  var VO_BIN = ["02_Audio", "01_VO"];

  /* The bin tree mirrors the disk tree, so a take lands in 02_Audio > 01_VO >
     MMDD rather than piling every day's reads into 01_VO. */
  function voBinPath(stamp) { return VO_BIN.concat([stamp]); }
  var LS_DEVICE = "dh_audioDevice";
  var LS_DIR    = "dh_audioDir";

  /* ---- state ---- */
  var ctx = null, stream = null, source = null, analyser = null, proc = null;
  var chunks = [], chunkLen = 0;
  var recording = false, armed = false;
  var meterTimer = null;
  var startedAt = 0;
  var srcRate = TARGET_RATE;

  function hostCall(fn, payload, cb) {
    if (!acs) return cb({ ok: false, error: "No CSInterface." });
    var arg = encodeURIComponent(JSON.stringify(payload || {}));
    acs.evalScript(fn + '("' + arg + '")', function (res) {
      var p; try { p = JSON.parse(res); } catch (e) { p = { ok: false, error: "Bad host response." }; }
      cb(p);
    });
  }

  function norm(p) { return String(p || "").replace(/\\/g, "/"); }
  function baseName(p) { var n = norm(p).replace(/\/+$/, ""), i = n.lastIndexOf("/"); return i === -1 ? n : n.substring(i + 1); }
  function dirOf(p) { var n = norm(p), i = n.lastIndexOf("/"); return i === -1 ? n : n.substring(0, i); }
  function isDir(p) { try { return fs.statSync(p).isDirectory(); } catch (e) { return false; } }
  function pad(n, w) { var s = String(n); while (s.length < w) s = "0" + s; return s; }

  function mmdd() {
    var d = new Date();
    return pad(d.getMonth() + 1, 2) + pad(d.getDate(), 2);
  }


  /* ---- project destination ----
     Auto mirrors the disk tree (02_Audio > 01_VO > MMDD). Manual stores a bin
     path by name, because DH_importVO resolves names via DH_binPath - a nodeId
     would break the moment the project is rebuilt. */
  var LS_BIN = "dh_audioBinPath";

  function savedBinPath() {
    try {
      var raw = window.localStorage.getItem(LS_BIN);
      if (!raw) return null;
      var v = JSON.parse(raw);
      return (v && v.length) ? v : null;
    } catch (e) { return null; }
  }
  function setSavedBinPath(parts) {
    try {
      if (parts && parts.length) window.localStorage.setItem(LS_BIN, JSON.stringify(parts));
      else window.localStorage.removeItem(LS_BIN);
    } catch (e) {}
  }
  function activeBinPath(stamp) {
    var manual = savedBinPath();
    if (manual) return manual;
    return VO_BIN.concat([stamp]);
  }
  function binTree(cb) { hostCall("DH_binTree", {}, cb); }

  /* ---- devices ----
     enumerateDevices works without permission - it just blanks the labels. So
     enumerate FIRST and always report what came back, then try getUserMedia to
     unlock the names and re-enumerate. Doing it the other way round means any
     getUserMedia rejection hides devices that are plainly there.

     getUserMedia also lives in three places depending on the Chromium build
     CEP shipped with, so all three are tried before giving up. */
  function gum(constraints) {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
      return navigator.mediaDevices.getUserMedia(constraints);
    }
    var legacy = navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia;
    if (!legacy) return null;
    return new Promise(function (res, rej) { legacy.call(navigator, constraints, res, rej); });
  }

  function rawEnumerate(cb) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return cb(null);
    navigator.mediaDevices.enumerateDevices().then(function (devs) { cb(devs); })
      ["catch"](function () { cb(null); });
  }

  function pickInputs(devs) {
    var out = [], i, d;
    if (!devs) return out;
    for (i = 0; i < devs.length; i++) {
      d = devs[i];
      if (d.kind !== "audioinput") continue;
      out.push({ id: d.deviceId, label: d.label || ("Input " + (out.length + 1) + " (name hidden)") });
    }
    return out;
  }

  function listInputs(cb) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) {
      return cb({ ok: false, noApi: true,
        error: "This panel has no mediaDevices API. The media-stream CEF flags are missing - reinstall so the new manifest takes effect, then fully quit and reopen Premiere." });
    }

    rawEnumerate(function (devs) {
      var first = pickInputs(devs);
      var needLabels = false, i;
      for (i = 0; i < first.length; i++) if (first[i].label.indexOf("name hidden") !== -1) needLabels = true;

      /* Already have names, or nothing to unlock - report and stop. */
      if (first.length && !needLabels) return cb({ ok: true, devices: first, unlocked: true });

      var p = gum({ audio: true });
      if (!p) {
        return cb({ ok: first.length > 0, devices: first, unlocked: false, noGum: true,
          error: "getUserMedia is unavailable in this panel build." });
      }

      p.then(function (st) {
        var t = st.getTracks(), k;
        for (k = 0; k < t.length; k++) t[k].stop();
        rawEnumerate(function (d2) {
          var second = pickInputs(d2);
          cb({ ok: true, devices: second.length ? second : first, unlocked: true });
        });
      })["catch"](function (err) {
        var name = (err && err.name) ? String(err.name) : String(err);
        var msg;
        if (name === "NotAllowedError" || name === "PermissionDeniedError") {
          msg = "Chromium refused the microphone (" + name + "). The panel needs --use-fake-ui-for-media-stream in the manifest - reinstall and restart Premiere.";
        } else if (name === "NotFoundError" || name === "DevicesNotFoundError") {
          msg = "No audio input device was offered to the panel (" + name + "), even though the system has one. This is usually Premiere lacking microphone permission at the OS level.";
        } else if (name === "NotReadableError" || name === "TrackStartError") {
          msg = "The device is busy (" + name + "). Another app - or another copy of this panel - already holds it.";
        } else {
          msg = "Microphone request failed: " + name;
        }
        cb({ ok: first.length > 0, devices: first, unlocked: false, error: msg });
      });
    });
  }

  /* Everything needed to tell where the chain broke, without guessing. */
  function diagnose(cb) {
    var info = [];
    info.push("location: " + String(window.location.protocol) + "//" + String(window.location.host || "(none)"));
    info.push("isSecureContext: " + String(window.isSecureContext));
    info.push("navigator.mediaDevices: " + (navigator.mediaDevices ? "present" : "MISSING"));
    info.push("enumerateDevices: " + ((navigator.mediaDevices && navigator.mediaDevices.enumerateDevices) ? "present" : "MISSING"));
    info.push("mediaDevices.getUserMedia: " + ((navigator.mediaDevices && navigator.mediaDevices.getUserMedia) ? "present" : "MISSING"));
    info.push("legacy getUserMedia: " + ((navigator.getUserMedia || navigator.webkitGetUserMedia) ? "present" : "MISSING"));
    info.push("AudioContext: " + ((window.AudioContext || window.webkitAudioContext) ? "present" : "MISSING"));

    rawEnumerate(function (devs) {
      if (!devs) { info.push("enumerateDevices: returned nothing"); return cb(info); }
      info.push("devices returned: " + devs.length);
      var i, d;
      for (i = 0; i < devs.length; i++) {
        d = devs[i];
        info.push("   [" + d.kind + "] " + (d.label ? d.label : "(label hidden)") +
                  "  id=" + (d.deviceId ? String(d.deviceId).substring(0, 12) : "(none)"));
      }
      var p = gum({ audio: true });
      if (!p) { info.push("getUserMedia: unavailable"); return cb(info); }
      p.then(function (st) {
        var t = st.getTracks(), k;
        info.push("getUserMedia: OK, " + t.length + " track(s)");
        for (k = 0; k < t.length; k++) { info.push("   track: " + t[k].label); t[k].stop(); }
        cb(info);
      })["catch"](function (err) {
        info.push("getUserMedia: FAILED " + ((err && err.name) ? err.name : String(err)));
        if (err && err.message) info.push("   " + String(err.message));
        cb(info);
      });
    });
  }

  /* ---- live input ----
     Opens the stream and wires the meter. Recording taps the same graph, so
     the meter keeps working while recording and levels are what was captured. */
  function arm(deviceId, cb) {
    disarm();

    var constraints = {
      audio: {
        echoCancellation: false,
        noiseSuppression: false,
        autoGainControl: false
      }
    };
    if (deviceId) constraints.audio.deviceId = { exact: deviceId };

    var gp = gum(constraints);
    if (!gp) return cb({ ok: false, error: "getUserMedia is unavailable in this panel build." });

    gp.then(function (s) {
      stream = s;
      try {
        /* Ask for 48k up front. If the device or this Chromium build refuses,
           we fall back and resample on write rather than failing. */
        ctx = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: TARGET_RATE });
      } catch (e1) {
        ctx = new (window.AudioContext || window.webkitAudioContext)();
      }
      srcRate = ctx.sampleRate;

      source = ctx.createMediaStreamSource(stream);
      analyser = ctx.createAnalyser();
      analyser.fftSize = 2048;
      analyser.smoothingTimeConstant = 0.2;
      source.connect(analyser);

      armed = true;
      cb({ ok: true, rate: srcRate });
    })["catch"](function (err) {
      cb({ ok: false, error: String(err) });
    });
  }

  function disarm() {
    stopMeter();
    try { if (proc) { proc.disconnect(); proc.onaudioprocess = null; } } catch (e) {}
    try { if (source) source.disconnect(); } catch (e2) {}
    try { if (stream) { var t = stream.getTracks(), i; for (i = 0; i < t.length; i++) t[i].stop(); } } catch (e3) {}
    try { if (ctx && ctx.close) ctx.close(); } catch (e4) {}
    proc = null; source = null; analyser = null; stream = null; ctx = null;
    armed = false; recording = false;
    chunks = []; chunkLen = 0;
  }

  /* ---- meter ----
     Peak drives the clip indicator, RMS drives the bar - peak alone jumps too
     hard to read at speech tempo. Both are reported in dBFS. */
  function startMeter(onLevel) {
    stopMeter();
    if (!analyser) return;
    var buf = new Float32Array(analyser.fftSize);

    meterTimer = window.setInterval(function () {
      if (!analyser) return;
      try { analyser.getFloatTimeDomainData(buf); }
      catch (e) {
        /* Older builds only expose the byte-domain call. */
        var b = new Uint8Array(analyser.fftSize);
        analyser.getByteTimeDomainData(b);
        var k; for (k = 0; k < b.length; k++) buf[k] = (b[k] - 128) / 128;
      }

      var i, v, peak = 0, sum = 0;
      for (i = 0; i < buf.length; i++) {
        v = buf[i];
        if (v < 0) v = -v;
        if (v > peak) peak = v;
        sum += buf[i] * buf[i];
      }
      var rms = Math.sqrt(sum / buf.length);
      onLevel({
        peakDb: peak > 0 ? 20 * Math.log(peak) / Math.LN10 : -100,
        rmsDb:  rms  > 0 ? 20 * Math.log(rms)  / Math.LN10 : -100,
        elapsed: recording ? ((new Date().getTime() - startedAt) / 1000) : 0
      });
    }, 50);
  }
  function stopMeter() { if (meterTimer) { window.clearInterval(meterTimer); meterTimer = null; } }

  /* True only when a live device is held. The menu-bar recording indicator
     follows the MediaStream track, so releasing it here is what makes the
     orange dot disappear. */
  function hasStream() { return !!stream; }

  /* ---- capture ----
     ScriptProcessor is deprecated but it is what this Chromium reliably has,
     and an AudioWorklet needs a separate module file the CEP sandbox makes
     awkward to load. A silent gain node keeps the graph pulling without
     routing input to the speakers. */
  function startRecording(cb) {
    if (!armed || !ctx || !source) return cb({ ok: false, error: "No input is open." });
    if (recording) return cb({ ok: false, error: "Already recording." });

    chunks = []; chunkLen = 0;
    proc = ctx.createScriptProcessor(4096, 1, 1);
    proc.onaudioprocess = function (ev) {
      if (!recording) return;
      var input = ev.inputBuffer.getChannelData(0);
      var copy = new Float32Array(input.length);
      copy.set(input);
      chunks.push(copy);
      chunkLen += copy.length;
    };
    source.connect(proc);

    var mute = ctx.createGain();
    mute.gain.value = 0;
    proc.connect(mute);
    mute.connect(ctx.destination);

    recording = true;
    startedAt = new Date().getTime();
    cb({ ok: true });
  }

  function stopRecording() {
    recording = false;
    try { if (proc) { proc.disconnect(); proc.onaudioprocess = null; } } catch (e) {}
    proc = null;

    var out = new Float32Array(chunkLen), off = 0, i;
    for (i = 0; i < chunks.length; i++) { out.set(chunks[i], off); off += chunks[i].length; }
    chunks = []; chunkLen = 0;
    return out;
  }

  /* Linear resample. Only runs when the device refused 48k; good enough for
     speech and far better than handing Premiere a mislabelled file. */
  function resample(data, from, to) {
    if (from === to) return data;
    var ratio = from / to;
    var len = Math.floor(data.length / ratio);
    var out = new Float32Array(len), i, pos, i0, i1, frac;
    for (i = 0; i < len; i++) {
      pos = i * ratio;
      i0 = Math.floor(pos);
      i1 = Math.min(i0 + 1, data.length - 1);
      frac = pos - i0;
      out[i] = data[i0] * (1 - frac) + data[i1] * frac;
    }
    return out;
  }

  /* 16-bit PCM mono RIFF. */
  function encodeWav(samples, rate) {
    var len = samples.length;
    var buf = new ArrayBuffer(44 + len * 2);
    var v = new DataView(buf);

    function str(off, s) { var i; for (i = 0; i < s.length; i++) v.setUint8(off + i, s.charCodeAt(i)); }

    str(0, "RIFF");
    v.setUint32(4, 36 + len * 2, true);
    str(8, "WAVE");
    str(12, "fmt ");
    v.setUint32(16, 16, true);
    v.setUint16(20, 1, true);          /* PCM */
    v.setUint16(22, 1, true);          /* mono */
    v.setUint32(24, rate, true);
    v.setUint32(28, rate * 2, true);   /* byte rate */
    v.setUint16(32, 2, true);          /* block align */
    v.setUint16(34, 16, true);         /* bit depth */
    str(36, "data");
    v.setUint32(40, len * 2, true);

    var off = 44, i, s;
    for (i = 0; i < len; i++) {
      s = samples[i];
      if (s > 1) s = 1; else if (s < -1) s = -1;
      v.setInt16(off, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
      off += 2;
    }
    return buf;
  }

  /* ---- output folder ----
     A remembered folder wins, so a job with an unusual layout only has to be
     set once. */
  function mkdirp(p) {
    if (!WRITING) return isDir(norm(p));
    var parts = norm(p).split("/"), cur = "", i;
    for (i = 0; i < parts.length; i++) {
      if (!parts[i]) { cur = ""; continue; }
      cur = cur ? cur + "/" + parts[i] : "/" + parts[i];
      if (!isDir(cur)) { try { fs.mkdirSync(cur); } catch (e) {} }
    }
    return isDir(norm(p));
  }

  /* Exact, case-insensitive directory match only.
     There used to be a numeric-prefix fallback here ("01_" matching anything
     starting 01_). Searching the job folder is fine, but the walk also tests
     the project's own folder first - and 01_PREMIERE starts with "01_", so
     looking for 01_ASSETS matched a folder inside 01_PREMIERE and built the
     whole VO tree in the wrong place. Prefix guessing has no business
     resolving a path we are about to write takes into. */
  function findChild(parent, want) {
    var entries, i, full;
    try { entries = fs.readdirSync(parent); } catch (e) { return ""; }
    var lw = String(want).toLowerCase();
    for (i = 0; i < entries.length; i++) {
      if (String(entries[i]).toLowerCase() !== lw) continue;
      full = norm(parent) + "/" + entries[i];
      if (isDir(full)) return full;
    }
    return "";
  }

  function savedDir() { try { return window.localStorage.getItem(LS_DIR) || ""; } catch (e) { return ""; } }
  function setSavedDir(p) { try { window.localStorage.setItem(LS_DIR, p || ""); } catch (e) {} }

  /* Walk up from the project file to the job folder, then down into
     01_ASSETS > 02_Audio > 01_VO. Every level is created if missing rather
     than treated as a failure - the template is the target, so building it is
     the right answer when part of it is absent.

     "Auto" means exactly this walk. It must never end in a folder prompt:
     a dialog after the take is recorded is how a take gets lost. */
  /* Hard guard. Every "should not create" bug so far came from a resolve path
     quietly reaching a create call. Rather than rely on flags being threaded
     correctly through every branch, creation is refused outright unless a
     write is actually in progress - so a display or resolve path physically
     cannot make a folder, however it got here. */
  var WRITING = false;

  function findChildOrMake(parent, want) {
    if (!WRITING) return findChild(parent, want);
    var hit = findChild(parent, want);
    if (hit) return hit;
    var made = norm(parent) + "/" + want;
    return mkdirp(made) ? made : "";
  }

  function autoVoDir(projectPath, create) {
    var mk = (create === true);
    var dir = dirOf(projectPath), guard = 0, assets = "", job = "";

    /* Walk up from the project file looking for a sibling 01_ASSETS. In the
       Harbor template the project sits in 01_PREMIERE, so the match is found
       one level up at the job root - not in the project's own folder. */
    while (dir && guard < 8) {
      guard++;
      if (baseName(dir).toLowerCase() === "01_assets") { assets = dir; break; }
      var hit = findChild(dir, "01_ASSETS");
      if (hit) { assets = hit; job = dir; break; }
      var up = dirOf(dir);
      if (up === dir) break;
      dir = up;
    }

    /* Nothing found anywhere up the tree. Creating 01_ASSETS beside the
       project would bury it inside 01_PREMIERE, so step up one level first
       when the project is sitting in a numbered template subfolder. */
    if (!assets) {
      job = dirOf(projectPath);
      var leaf = baseName(job).toLowerCase();
      if (leaf.indexOf("premiere") !== -1 || leaf.indexOf("_edit") !== -1 || leaf.indexOf("project") !== -1) {
        var parent = dirOf(job);
        if (parent && parent !== job) job = parent;
      }
      /* Resolving only - report the path we would build without building it. */
      if (!mk) return norm(job) + "/01_ASSETS/02_Audio/01_VO";
      assets = findChildOrMake(job, "01_ASSETS");
      if (!assets) return "";
    }

    if (!mk) {
      var a2 = findChild(assets, "02_Audio");
      if (!a2) return norm(assets) + "/02_Audio/01_VO";
      var v2 = findChild(a2, "01_VO");
      return v2 ? v2 : (norm(a2) + "/01_VO");
    }

    var audio = findChildOrMake(assets, "02_Audio");
    if (!audio) return "";
    var vo = findChildOrMake(audio, "01_VO");
    return vo || "";
  }

  function resolveVoDir(cb, create) {
    var saved = savedDir();
    if (saved && isDir(saved)) return cb({ ok: true, dir: saved, remembered: true });

    hostCall("DH_projectPath", {}, function (pr) {
      if (!pr || !pr.ok || !pr.path) {
        return cb({ ok: false, needsBrowse: true,
          error: (pr && pr.error) || "The project has not been saved, so there is no job folder to build from." });
      }
      var vo = autoVoDir(pr.path, create === true);
      if (!vo) return cb({ ok: false, needsBrowse: true,
        error: "Could not create the VO folder near " + pr.path });
      cb({ ok: true, dir: vo, remembered: false, project: pr.path });
    });
  }

  /* VO_MMDD_001.wav, continuing past whatever is already in the folder so a
     second take on the same day never lands on the first.
     Parsed by hand rather than with a RegExp: the escaping here has bitten
     once already, and string slicing cannot be got wrong the same way. */
  function nextName(dir, stamp) {
    var entries = [], i, n, name, lower, max = 0;
    try { entries = fs.readdirSync(dir); } catch (e) { entries = []; }

    var prefix = ("VO_" + stamp + "_").toLowerCase();
    for (i = 0; i < entries.length; i++) {
      name = String(entries[i]);
      lower = name.toLowerCase();
      if (lower.indexOf(prefix) !== 0) continue;
      if (lower.substring(lower.length - 4) !== ".wav") continue;

      n = parseInt(lower.substring(prefix.length, lower.length - 4), 10);
      if (!isNaN(n) && n > max) max = n;
    }
    return "VO_" + stamp + "_" + pad(max + 1, 3) + ".wav";
  }

  /* Last line of defence: if the name is somehow still taken, step forward
     rather than overwriting a take that already exists. */
  function uniquePath(dir, name) {
    var full = norm(dir) + "/" + name;
    var stem = name.substring(0, name.length - 4);
    var n = 1;
    while (n < 1000) {
      var exists = false;
      try { fs.statSync(full); exists = true; } catch (e) { exists = false; }
      if (!exists) return full;
      full = norm(dir) + "/" + stem + "_" + pad(n, 2) + ".wav";
      n++;
    }
    return full;
  }

  /* ---- finish ----
     Order matters: the WAV is encoded and written BEFORE anything that can
     fail. An earlier build resolved the destination first and prompted on
     failure, which meant a refused dialog destroyed a finished take. Now the
     audio is on disk within milliseconds of Stop - if the destination cannot
     be resolved it lands in a fallback folder and the log says where. The
     take is never the thing that gets lost. */
  function fallbackDir() {
    var candidates = [], i;
    try { if (process && process.env && process.env.HOME) candidates.push(norm(process.env.HOME) + "/Documents/STN_VO"); } catch (e) {}
    try { if (require("os") && require("os").tmpdir) candidates.push(norm(require("os").tmpdir()) + "/STN_VO"); } catch (e2) {}
    candidates.push("/tmp/STN_VO");
    for (i = 0; i < candidates.length; i++) if (mkdirp(candidates[i])) return candidates[i];
    return "";
  }

  function writeWav(dir, samples) {
    var stamp = mmdd();
    var outDir = norm(dir) + "/" + stamp;
    if (!mkdirp(outDir)) return { ok: false, error: "Could not create " + outDir };

    var data = resample(samples, srcRate, TARGET_RATE);
    var wav = encodeWav(data, TARGET_RATE);
    var full = uniquePath(outDir, nextName(outDir, stamp));

    try {
      var bytes = new Uint8Array(wav);
      var buf = (typeof Buffer.from === "function") ? Buffer.from(bytes) : new Buffer(bytes);
      fs.writeFileSync(full, buf);
    } catch (e) { return { ok: false, error: "Could not write the file: " + String(e) }; }

    return { ok: true, file: full, name: baseName(full), stamp: stamp, seconds: data.length / TARGET_RATE };
  }

  function finish(samples, place, cb) {
    if (!NODE_OK) return cb({ ok: false, error: "Node is unavailable in this panel." });
    if (!samples || !samples.length) return cb({ ok: false, error: "Nothing was captured." });

    /* create=true: this is the write path, so the tree is built here rather
       than when the panel merely displays the destination. */
    WRITING = true;
    resolveVoDir(function (dr) {
      var dir = dr.ok ? dr.dir : "";
      var stranded = false, why = "";

      if (!dir) {
        dir = fallbackDir();
        stranded = true;
        why = dr.error || "The VO folder could not be resolved.";
        if (!dir) { WRITING = false; return cb({ ok: false, error: why + " No fallback folder could be created either - the take could not be saved." }); }
      }

      var w = writeWav(dir, samples);

      /* Destination write failed outright - try the fallback before giving up,
         so a full or read-only volume still does not cost the take. */
      if (!w.ok && !stranded) {
        var fb = fallbackDir();
        if (fb) {
          w = writeWav(fb, samples);
          if (w.ok) { stranded = true; why = "Could not write to " + dir; }
        }
      }
      if (!w.ok) { WRITING = false; return cb({ ok: false, error: w.error }); }

      if (stranded) {
        /* Saved, but not where it belongs. Do not import - the editor should
           move it deliberately rather than have a stray path in the project. */
        WRITING = false;
        return cb({ ok: true, file: w.file, name: w.name, seconds: w.seconds,
                    stranded: true, why: why });
      }

      hostCall("DH_importVO", { path: w.file, binPath: activeBinPath(w.stamp), track: -1, place: (place !== false) }, function (ir) {
        WRITING = false;
        cb({ ok: true, file: w.file, name: w.name, seconds: w.seconds, place: ir });
      });
    }, true);
  }

  return {
    nodeOK: function () { return NODE_OK; },
    listInputs: listInputs, diagnose: diagnose,
    arm: arm, disarm: disarm, isArmed: function () { return armed; },
    isRecording: function () { return recording; },
    startMeter: startMeter, stopMeter: stopMeter, hasStream: hasStream,
    startRecording: startRecording, stopRecording: stopRecording,
    finish: finish,
    resolveVoDir: resolveVoDir, setSavedDir: setSavedDir, savedDir: savedDir,
    rate: function () { return srcRate; },
    /* Evaluated per call - a panel left open past midnight would otherwise
       report yesterday's folder. */
    binLabel: function () { return activeBinPath(mmdd()).join(" \u203A "); },
    savedBinPath: savedBinPath, setSavedBinPath: setSavedBinPath,
    activeBinPath: activeBinPath, binTree: binTree
  };
})();


/* ===================== Audio page wiring ===================== */
(function wireAudioPage() {

  function A(id) { return document.getElementById(id); }

  /* Distinct from the module's norm() - this one also trims a trailing
     slash so the MMDD segment cannot double up. */
  function tidyPath(p) { return String(p || "").replace(/\\/g, "/").replace(/\/+$/, ""); }

  /* A zero-width space after every "/" gives the browser a preferred break
     point, so a long LucidLink path wraps at folder boundaries rather than
     mid-name or running past the panel. Display only - the stored path keeps
     its real characters. */
  function breakable(p) { return String(p).replace(/\//g, "/\u200B"); }
  function alog(msg, cls) {
    var el = A("audLog"); if (!el) return;
    var d = document.createElement("div");
    if (cls) d.className = cls;
    d.textContent = msg;
    el.appendChild(d); el.scrollTop = el.scrollHeight;
  }
  function setState(t) { var el = A("audState"); if (el) el.textContent = t; }

  var clipHold = 0, peakHold = -100, peakHoldAt = 0;

  function fmtTime(s) {
    var m = Math.floor(s / 60), r = Math.floor(s % 60);
    return (m < 10 ? "0" : "") + m + ":" + (r < 10 ? "0" : "") + r;
  }

  /* -60..0 dBFS across the bar. Below -60 there is nothing worth showing. */
  function dbToPct(db) {
    if (db <= -60) return 0;
    if (db >= 0) return 100;
    return ((db + 60) / 60) * 100;
  }

  function onLevel(l) {
    var bar = A("audBar"), pk = A("audPeak"), tm = A("audTime"), num = A("audDb");
    var now = new Date().getTime();

    if (bar) {
      var pct = dbToPct(l.rmsDb);
      bar.style.width = pct.toFixed(1) + "%";
      bar.className = "aud-bar" + (l.peakDb > -3 ? " hot" : (l.peakDb > -12 ? " warm" : ""));
    }

    if (l.peakDb > peakHold || now - peakHoldAt > 1200) { peakHold = l.peakDb; peakHoldAt = now; }
    if (pk) pk.style.left = dbToPct(peakHold).toFixed(1) + "%";
    if (num) num.textContent = (l.peakDb <= -60) ? "-\u221E" : l.peakDb.toFixed(1) + " dB";

    if (l.peakDb > -0.5) { clipHold = now; }
    var clip = A("audClip");
    if (clip) clip.className = "aud-clip" + ((now - clipHold < 1500) ? " on" : "");

    if (tm) tm.textContent = fmtTime(l.elapsed);
  }

  /* Input on/off. Off fully releases the MediaStream tracks - not just the
     meter - because macOS keeps the menu-bar recording indicator lit for as
     long as any track is live, even a silent one. Nothing is held while off. */
  function inputOn() {
    try {
      var v = window.localStorage.getItem("dh_audioOn");
      return (v === null) ? true : (v === "1");
    } catch (e) { return true; }
  }
  function setInputOn(v) {
    try { window.localStorage.setItem("dh_audioOn", v ? "1" : "0"); } catch (e) {}
  }

  function clearMeter() {
    var bar = A("audBar"), pk = A("audPeak"), num = A("audDb"), tm = A("audTime"), clip = A("audClip");
    if (bar) { bar.style.width = "0%"; bar.className = "aud-bar"; }
    if (pk) pk.style.left = "0%";
    if (num) num.textContent = "-\u221E";
    if (tm) tm.textContent = "00:00";
    if (clip) clip.className = "aud-clip";
    peakHold = -100; peakHoldAt = 0; clipHold = 0;
  }

  function paintToggle() {
    var btn = A("audToggle");
    if (!btn) return;
    var on = inputOn();
    btn.textContent = on ? "On" : "Off";
    btn.className = "mini" + (on ? " aud-on" : " aud-off");
    btn.title = on ? "Input is live - click to release the microphone" : "Input is off - click to open the microphone";

    var rec = A("audRec");
    if (rec) rec.disabled = !on || !DeckhandAudio.isArmed();
    var sel = A("audInput");
    if (sel) sel.disabled = !on;
  }

  function turnOff() {
    if (DeckhandAudio.isRecording()) {
      alog("Stop the recording before switching the input off.", "warn");
      return;
    }
    setInputOn(false);
    DeckhandAudio.disarm();
    clearMeter();
    paintToggle();
    setState("Input off");
    alog("Input released \u2014 the microphone is no longer held.", "");
  }

  function turnOn() {
    setInputOn(true);
    paintToggle();
    loadDevices(true);
  }

  /* ---- manual bin picker ----
     A drill-down list, not a hover cascade. Two reasons the cascade was wrong:
     each level needs its own scroll box for a deep project, and a scrolling
     parent clips absolutely-positioned children - so sub-levels got trapped
     inside their parent. And flyouts need horizontal room the panel does not
     have at ~300px.

     So: one list at a time. Tap a row to select that bin, tap its caret to
     descend into it. A breadcrumb walks back up. */
  var binStack = [];      /* [{name, nodes}] - path currently being browsed */
  var binRoot  = null;    /* cached tree for this open session */

  function mmddNow() {
    var d = new Date();
    function p2(n) { var t = String(n); return t.length < 2 ? "0" + t : t; }
    return p2(d.getMonth() + 1) + p2(d.getDate());
  }

  function showBinDest() {
    var el = A("audBinDir");
    if (!el) return;
    var manual = DeckhandAudio.savedBinPath();
    el.textContent = DeckhandAudio.activeBinPath(mmddNow()).join(" \u203A ") + (manual ? "" : "   (auto)");
  }

  /* The menu is appended to <body>, not to the section. The fieldset uses
     backdrop-filter, which makes it a containing block for positioned
     descendants - so a menu inside it can never escape the section bounds no
     matter what overflow says. Positioning it against the trigger's viewport
     rect sidesteps every ancestor. */
  var binMenuEl = null;

  function menuEl() {
    if (binMenuEl && binMenuEl.parentNode) return binMenuEl;
    binMenuEl = document.createElement("div");
    binMenuEl.className = "aud-menu";
    binMenuEl.id = "audBinMenu";
    document.body.appendChild(binMenuEl);
    return binMenuEl;
  }

  function menuOpen() {
    return !!(binMenuEl && binMenuEl.className.indexOf("open") !== -1);
  }

  function placeMenu() {
    var btn = A("audBinBtn"), m = menuEl();
    if (!btn) return;
    var r = btn.getBoundingClientRect();
    var vh = window.innerHeight || document.documentElement.clientHeight;
    m.style.left = Math.round(r.left) + "px";
    m.style.width = Math.round(r.width) + "px";

    /* Flip above the trigger when there is more room up than down. */
    var below = vh - r.bottom;
    if (below < 150 && r.top > below) {
      m.style.top = "auto";
      m.style.bottom = Math.round(vh - r.top + 4) + "px";
      m.style.maxHeight = Math.round(r.top - 12) + "px";
    } else {
      m.style.bottom = "auto";
      m.style.top = Math.round(r.bottom + 4) + "px";
      m.style.maxHeight = Math.round(below - 12) + "px";
    }
  }

  function closeBinMenu() {
    if (binMenuEl) { binMenuEl.innerHTML = ""; binMenuEl.className = "aud-menu"; }
    var btn = A("audBinBtn");
    if (btn) btn.className = "aud-select";
    binStack = [];
  }

  function currentNodes() {
    if (!binStack.length) return binRoot || [];
    return binStack[binStack.length - 1].nodes || [];
  }
  function currentPath() {
    var out = [], i;
    for (i = 0; i < binStack.length; i++) out.push(binStack[i].name);
    return out;
  }

  function chooseBin(parts) {
    if (!parts.length) return;
    DeckhandAudio.setSavedBinPath(parts);
    closeBinMenu();
    showBinDest();
    alog("Project destination set to " + parts.join(" \u203A "), "ok");
  }

  /* Premiere hands bins back in project-panel order, which is whatever the
     editor last dragged things into. Sort by name so 01_/02_/03_ read in
     order at every level.

     localeCompare with numeric collation keeps 2 before 10 - a plain string
     sort would put "10_" between "01_" and "02_". Falls back to a manual
     numeric-prefix compare on builds where the options argument is ignored. */
  function sortBins(nodes) {
    if (!nodes || !nodes.length) return nodes || [];
    var i;
    for (i = 0; i < nodes.length; i++) {
      if (nodes[i].children && nodes[i].children.length) nodes[i].children = sortBins(nodes[i].children);
    }
    nodes.sort(function (a, b) {
      var an = String(a.name), bn = String(b.name);
      try {
        var r = an.localeCompare(bn, undefined, { numeric: true, sensitivity: "base" });
        if (r !== 0) return r;
      } catch (e) {}
      var al = an.toLowerCase(), bl = bn.toLowerCase();
      var am = /^(\d+)/.exec(al), bm = /^(\d+)/.exec(bl);
      if (am && bm) {
        var d = parseInt(am[1], 10) - parseInt(bm[1], 10);
        if (d !== 0) return d;
      }
      if (al < bl) return -1;
      if (al > bl) return 1;
      return 0;
    });
    return nodes;
  }

  function renderBinMenu() {
    var m = menuEl();
    m.innerHTML = "";
    m.className = "aud-menu open";
    placeMenu();

    var box = document.createElement("div");
    box.className = "aud-level";

    /* Breadcrumb: shows where we are and doubles as the way back up. */
    var crumb = document.createElement("div");
    crumb.className = "aud-crumb";
    if (binStack.length) {
      var back = document.createElement("button");
      back.type = "button";
      back.className = "aud-back";
      back.textContent = "\u2039";
      back.title = "Back";
      back.onclick = function (ev) { ev.stopPropagation(); binStack.pop(); renderBinMenu(); };
      crumb.appendChild(back);
    }
    var trail = document.createElement("span");
    trail.className = "aud-crumb-txt";
    trail.textContent = binStack.length ? currentPath().join(" \u203A ") : "Project root";
    crumb.appendChild(trail);
    box.appendChild(crumb);

    /* Selecting the bin we are currently inside. */
    if (binStack.length) {
      var useThis = document.createElement("div");
      useThis.className = "aud-item use-this";
      useThis.textContent = "Use " + binStack[binStack.length - 1].name;
      useThis.onclick = function (ev) { ev.stopPropagation(); chooseBin(currentPath()); };
      box.appendChild(useThis);
    }

    var nodes = currentNodes();
    if (!nodes.length) {
      var none = document.createElement("div");
      none.className = "aud-item empty";
      none.textContent = binStack.length ? "No sub-bins here." : "This project has no bins.";
      box.appendChild(none);
    }

    var i;
    for (i = 0; i < nodes.length; i++) {
      (function (node) {
        var row = document.createElement("div");
        row.className = "aud-item";

        var label = document.createElement("span");
        label.className = "aud-item-label";
        label.textContent = node.name;
        label.title = "Select " + node.name;
        label.onclick = function (ev) { ev.stopPropagation(); chooseBin(currentPath().concat([node.name])); };
        row.appendChild(label);

        if (node.children && node.children.length) {
          var into = document.createElement("button");
          into.type = "button";
          into.className = "aud-into";
          into.textContent = "\u203A";
          into.title = "Open " + node.name;
          into.onclick = function (ev) {
            ev.stopPropagation();
            binStack.push({ name: node.name, nodes: node.children });
            renderBinMenu();
          };
          row.appendChild(into);
        }

        box.appendChild(row);
      })(nodes[i]);
    }

    m.appendChild(box);
  }

  function openBinMenu() {
    if (menuOpen()) { closeBinMenu(); return; }
    var m = menuEl();
    var btn = A("audBinBtn");
    if (btn) btn.className = "aud-select open";

    m.innerHTML = "";
    m.className = "aud-menu open";
    placeMenu();
    var loading = document.createElement("div");
    loading.className = "aud-level";
    var msg = document.createElement("div");
    msg.className = "aud-item empty";
    msg.textContent = "reading project\u2026";
    loading.appendChild(msg);
    m.appendChild(loading);

    DeckhandAudio.binTree(function (r) {
      if (!menuOpen()) return;
      if (!r || !r.ok) {
        m.innerHTML = "";
        var box = document.createElement("div");
        box.className = "aud-level";
        var e = document.createElement("div");
        e.className = "aud-item empty";
        e.textContent = (r && r.error) ? r.error : "Could not read the project.";
        box.appendChild(e);
        m.appendChild(box);
        return;
      }
      binRoot = sortBins(r.bins || []);
      binStack = [];
      renderBinMenu();
    });
  }

  function loadDevices(auto) {
    var sel = A("audInput");
    if (!sel) return;
    DeckhandAudio.listInputs(function (r) {
      sel.innerHTML = "";
      var devs = r.devices || [];

      if (!devs.length) {
        var o = document.createElement("option");
        o.textContent = "No input available";
        sel.appendChild(o);
        alog(r.error || "No audio inputs were returned.", "err");
        alog("Click Diagnostics for the full picture.", "");
        return;
      }

      var saved = "";
      try { saved = window.localStorage.getItem("dh_audioDevice") || ""; } catch (e) {}
      var i, opt;
      for (i = 0; i < devs.length; i++) {
        opt = document.createElement("option");
        opt.value = devs[i].id;
        opt.textContent = devs[i].label;
        if (devs[i].id === saved) opt.selected = true;
        sel.appendChild(opt);
      }

      alog("Found " + devs.length + " input(s).", "ok");
      if (!r.unlocked) {
        alog("Device names are hidden until the microphone is granted. " + (r.error || ""), "warn");
      }
      /* Only auto-arm against a real device. With permission denied the ids
         come back empty and getUserMedia would just fail again noisily. */
      if (auto && r.unlocked && sel.value) openInput();
      else if (auto) alog("Grant microphone access, then hit Refresh.", "warn");
    });
  }

  function openInput() {
    if (!inputOn()) return;
    var sel = A("audInput");
    var id = sel && sel.value ? sel.value : "";
    try { window.localStorage.setItem("dh_audioDevice", id); } catch (e) {}

    setState("Opening input\u2026");
    DeckhandAudio.arm(id, function (r) {
      if (!r.ok) { setState("Input failed"); alog(r.error, "err"); return; }
      DeckhandAudio.startMeter(onLevel);
      setState("Ready");
      if (r.rate !== 48000) {
        alog("Device is running at " + r.rate + " Hz \u2014 recordings will be resampled to 48 kHz on write.", "warn");
      }
      paintToggle();
    });
  }

  function init() {
    if (!A("page-audio")) return;

    if (!DeckhandAudio.nodeOK()) { setState("Node unavailable"); return; }

    var rec = A("audRec");
    if (rec) rec.disabled = true;

    /* Diagnostics lives on the Developer page and logs into its own pane
       there, so a support check does not bury the take log on Audio. */
    var diag = A("audDiag");
    if (diag) diag.onclick = function () {
      var pane = A("audDiagLog");
      if (pane) pane.innerHTML = "";
      function dlog(msg) {
        if (!pane) { alog(msg, ""); return; }
        var d = document.createElement("div");
        d.textContent = msg;
        pane.appendChild(d);
        pane.scrollTop = pane.scrollHeight;
      }
      diag.disabled = true;
      dlog("\u2014 audio diagnostics \u2014");
      DeckhandAudio.diagnose(function (lines) {
        var i;
        for (i = 0; i < lines.length; i++) dlog(lines[i]);
        dlog("\u2014 end \u2014");
        diag.disabled = false;
      });
    };

    var refresh = A("audRefresh");
    if (refresh) refresh.onclick = function () {
      if (!inputOn()) { alog("Input is off \u2014 switch it on first.", "warn"); return; }
      loadDevices(true);
    };

    var toggle = A("audToggle");
    if (toggle) toggle.onclick = function () { if (inputOn()) turnOff(); else turnOn(); };

    var sel = A("audInput");
    if (sel) sel.addEventListener("change", openInput);

    if (rec) rec.onclick = function () {
      if (!DeckhandAudio.isRecording()) {
        DeckhandAudio.startRecording(function (r) {
          if (!r.ok) { alog(r.error, "err"); return; }
          rec.className = "aud-recbtn recording";
          rec.title = "Stop";
          setState("Recording\u2026");
        });
        return;
      }

      var samples = DeckhandAudio.stopRecording();
      rec.className = "aud-recbtn";
      rec.title = "Record";
      rec.disabled = true;
      setState("Writing\u2026");

      var wantPlace = true;
      var pc = A("audPlace");
      if (pc) wantPlace = !!pc.checked;

      DeckhandAudio.finish(samples, wantPlace, function (r) {
        rec.disabled = false;
        if (!r.ok) {
          setState("Failed");
          alog(breakable(r.error), "err");
          if (r.needsBrowse && typeof host === "function") {
            alog("Pick the 01_VO folder for this job.", "");
            host("DH_browse", { kind: "folder" }, function (b) {
              if (!b || !b.ok || !b.path) return;
              DeckhandAudio.setSavedDir(b.path);
              alog("VO folder set to " + breakable(b.path) + ". Record again to use it.", "ok");
            });
          }
          return;
        }
        setState("Ready");
        alog("Wrote " + r.name + "  (" + r.seconds.toFixed(1) + "s)", "ok");
        alog("   " + breakable(r.file), "");

        if (r.stranded) {
          alog("The take is safe but is NOT in the job folder: " + breakable(r.why), "warn");
          alog("Use Manual file location below, then move this file across.", "warn");
          return;
        }
        if (r.place && r.place.ok && r.place.placed === false) {
          alog("Imported to " + DeckhandAudio.binLabel() + ". Not placed \u2014 Place at Playhead is off.", "ok");
        } else if (r.place && r.place.ok) {
          alog("Placed on " + r.place.track + " at " + r.place.at + " in " + DeckhandAudio.binLabel() + ".", "ok");
        } else if (r.place) {
          alog("Wrote the file, but import/placement failed: " + (r.place.error || "unknown"), "warn");
        }
      });
    };

    var folder = A("audFolder");
    if (folder) folder.onclick = function () {
      if (typeof host !== "function") return;
      host("DH_browse", { kind: "folder" }, function (b) {
        if (!b || !b.ok || !b.path) return;
        DeckhandAudio.setSavedDir(b.path);
        alog("VO folder set to " + breakable(b.path), "ok");
        showDir();
      });
    };

    var binBtn = A("audBinBtn");
    if (binBtn) {
      binBtn.onclick = function (ev) { ev.stopPropagation(); openBinMenu(); };
      binBtn.addEventListener("keydown", function (ev) {
        if (ev.keyCode === 13 || ev.keyCode === 32) { ev.preventDefault(); openBinMenu(); }
      });
    }

    var binAuto = A("audBinAuto");
    if (binAuto) binAuto.onclick = function () {
      DeckhandAudio.setSavedBinPath(null);
      closeBinMenu();
      showBinDest();
      alog("Project destination back to 02_Audio \u203A 01_VO \u203A MMDD.", "");
    };

    /* Dismiss on an outside click or Escape, and keep the menu pinned to the
       trigger while the page scrolls or the panel is resized. */
    try {
      document.addEventListener("click", function (ev) {
        if (!menuOpen()) return;
        var pick = A("audBinPick"), n = ev.target;
        while (n) { if (n === pick || n === binMenuEl) return; n = n.parentNode; }
        closeBinMenu();
      });
      document.addEventListener("keydown", function (ev) {
        if (ev.keyCode === 27 && menuOpen()) closeBinMenu();
      });
      window.addEventListener("scroll", function () { if (menuOpen()) placeMenu(); }, true);
      window.addEventListener("resize", function () { if (menuOpen()) closeBinMenu(); });
    } catch (eD) {}

    var clear = A("audClearDir");
    if (clear) clear.onclick = function () {
      DeckhandAudio.setSavedDir("");
      alog("Reverted to finding 01_VO from the project location.", "");
      showDir();
    };

    var pc = A("audPlace");
    if (pc) {
      try {
        var saved = window.localStorage.getItem("dh_audioPlace");
        if (saved !== null) pc.checked = (saved === "1");
      } catch (e) {}
      pc.addEventListener("change", function () {
        try { window.localStorage.setItem("dh_audioPlace", pc.checked ? "1" : "0"); } catch (e2) {}
      });
    }

    showDir();
    showBinDest();
    paintToggle();

    if (inputOn()) {
      /* No Open button, so arm the selected input as soon as the device list
         resolves. */
      loadDevices(true);
      setState("Idle");
    } else {
      clearMeter();
      setState("Input off");
    }
  }

  function showDir() {
    var el = A("audDir");
    if (!el) return;
    /* The resolver returns the 01_VO folder, but takes are written one level
       deeper into MMDD. Show the folder the file actually lands in. */
    var saved = DeckhandAudio.savedDir();
    if (saved) { el.textContent = breakable(tidyPath(saved) + "/" + mmddNow()); return; }
    DeckhandAudio.resolveVoDir(function (r) {
      el.textContent = r.ok ? breakable(tidyPath(r.dir) + "/" + mmddNow())
                            : "\u2014 will be found from the project when you record \u2014";
    });
  }

  /* Releasing the device on unload matters: a held input can keep the Wave
     locked so nothing else on the machine can open it. */
  try { window.addEventListener("beforeunload", function () { DeckhandAudio.disarm(); }); } catch (e) {}
  try { window.addEventListener("load", init); } catch (e2) {}
})();
