/* STN - AE Helper — CEP (panel) side. (Built on Signal Assistant Editor / Deckhand.) */

var cs = new CSInterface();
var $ = function (id) { return document.getElementById(id); };

/* ---- Deckhand: dark / light color scheme ----
   Dark is the default (no data-theme). Light sets data-theme="light" on <html>,
   which swaps the CSS variables (lighter gray bg, black text). The choice is
   remembered in localStorage and re-applied on the next launch. */
(function wireTheme() {
  var KEY = "dh_theme";
  function saved() { try { return window.localStorage.getItem(KEY); } catch (e) { return null; } }
  function store(v) { try { window.localStorage.setItem(KEY, v); } catch (e) {} }
  function apply(mode) {
    var light = (mode === "light");
    if (light) document.documentElement.setAttribute("data-theme", "light");
    else document.documentElement.removeAttribute("data-theme");
    var btn = $("themeToggle");
    if (btn) {
      // Show the mode you'll switch TO.
      btn.textContent = light ? "🌙" : "☀️";
      btn.title = light ? "Switch to dark mode" : "Switch to light mode";
    }
  }
  apply(saved() === "light" ? "light" : "dark");
  var btn = $("themeToggle");
  if (btn) btn.onclick = function () {
    var next = (document.documentElement.getAttribute("data-theme") === "light") ? "dark" : "light";
    store(next);
    apply(next);
  };
})();

/* Claim keyboard events from the host application.
   Premiere consumes arrows, Enter, Tab, Delete and friends as its own editing
   shortcuts before CEP ever sees them, so text fields in the panel behave as
   if they were read-only for navigation: no caret movement, no field-to-field
   tabbing, no Enter. registerKeyEventsInterest tells Premiere to forward these
   to the panel while it has focus, which is what makes the Slate Reader fields
   (and every other input) behave like normal text fields. */
(function () {
  try {
    var codes = [
      9,        /* tab */
      13,       /* enter */
      27,       /* esc */
      32,       /* space */
      8, 46,    /* backspace, delete */
      35, 36,   /* end, home */
      37, 38, 39, 40  /* arrows */
    ];
    var interest = [], i;
    for (i = 0; i < codes.length; i++) {
      /* plain, and with each modifier, so shift+arrow selection and
         shift+tab reverse-tabbing survive the same trip */
      interest.push({ keyCode: codes[i] });
      interest.push({ keyCode: codes[i], shiftKey: true });
      interest.push({ keyCode: codes[i], ctrlKey: true });
      interest.push({ keyCode: codes[i], metaKey: true });
    }
    cs.registerKeyEventsInterest(JSON.stringify(interest));
  } catch (e) {}
})();

/* Force a fresh evaluation of the host script on every panel launch. The host
   is normally loaded once via the manifest ScriptPath into the *persistent*
   ExtendScript engine, so a panel reload keeps whatever (possibly stale or
   half-loaded) definitions the engine already had. Re-evaluating here makes the
   engine pick up the current deliver.jsx and defeats that whole class of
   stale-host bugs. */
(function loadHostFresh() {
  try {
    var p = cs.getSystemPath(SystemPath.EXTENSION) + "/host/deliver.jsx";
    var esc = p.replace(/\\/g, "\\\\").replace(/"/g, '\\"');
    cs.evalScript('$.evalFile("' + esc + '")');
  } catch (e) {}
})();

var EXT_PRESETS_DIR = cs.getSystemPath(SystemPath.EXTENSION) + "/Presets";
var lastPresets = [];

/* ---- page router ---- */
function showPage(id) {
  var pages = document.querySelectorAll(".page");
  for (var i = 0; i < pages.length; i++) pages[i].classList.remove("active");
  var el = document.getElementById(id);
  if (el) el.classList.add("active");
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
  // Refresh slate data from the active sequence when these pages open.
  if ((id === "page-slate" || id === "page-deliver") && typeof readSlateNow === "function") {
    readSlateNow(true);
  }
  if ((id === "page-slate" || id === "page-prep" || id === "page-deliver") &&
      typeof refreshSlateTargets === "function") {
    refreshSlateTargets();
  }
}
(function wireNav() {
  var navs = document.querySelectorAll("[data-goto]");
  for (var i = 0; i < navs.length; i++)
    navs[i].addEventListener("click", function () {
      var target = this.getAttribute("data-goto");
      // Clicking a nav PILL for the page you're already on returns to home.
      if (this.className && this.className.indexOf("pn") !== -1) {
        var host = this.parentNode;   // climb to the enclosing .page section
        while (host && !(host.className && (" " + host.className + " ").indexOf(" page ") !== -1)) host = host.parentNode;
        if (host && host.id === target) { showPage("page-home"); return; }
      }
      showPage(target);
    });
})();

/* ---- logs ---- */
function logTo(elId, msg, cls) {
  var el = $(elId); var line = document.createElement("div");
  if (cls) line.className = cls; line.textContent = msg;
  el.appendChild(line); el.scrollTop = el.scrollHeight;
}
function log(m, c)  { logTo("log", m, c); }
function dlog(m, c) { logTo("dlvLog", m, c); }

/* ---- host bridge ---- */
function host(fn, payload, cb) {
  var arg = encodeURIComponent(JSON.stringify(payload || {}));
  cs.evalScript(fn + '("' + arg + '")', function (res) {
    var parsed;
    try { parsed = JSON.parse(res); }
    catch (e) { parsed = { ok: false, error: "Bad host response: " + res }; }
    cb(parsed);
  });
}

/* ---- Sequence name: editable, prefilled, Enter finishes, shared by Prep + Deliver ---- */
var prepSeqDirty = false;
var dlvSeqDirty  = false;
var slateSeqDirty = false;
$("seqName").addEventListener("input",      function () { prepSeqDirty = true; });
$("dlvSeqName").addEventListener("input",   function () { dlvSeqDirty  = true; });
$("slateSeqName").addEventListener("input", function () { slateSeqDirty = true; });
function finishEdit(el) {
  el.addEventListener("keydown", function (e) {
    if (e.keyCode === 13 || e.key === "Enter") { e.preventDefault(); this.blur(); }
  });
}
finishEdit($("seqName"));
finishEdit($("dlvSeqName"));
finishEdit($("slateSeqName"));

var lastSlateSeq = null;   // active-sequence name at last slate read
function refreshSeqName() {
  host("DH_seqName", {}, function (r) {
    // If the host script isn't answering (stale/failed engine), don't wipe the
    // fields — leave a clear signal and skip this tick.
    if (!r || (r.ok === false && !("name" in r))) {
      if (!prepSeqDirty && $("seqName").value === "") $("seqName").placeholder = "(host not responding — restart Premiere)";
      return;
    }
    var n = (r && r.name) ? r.name : "";
    if (!prepSeqDirty)  $("seqName").value      = n;
    if (!dlvSeqDirty)   $("dlvSeqName").value    = n;
    if (!slateSeqDirty) $("slateSeqName").value  = n;
    if (typeof updateFileName === "function" &&
        typeof anyOverride === "function" && !anyOverride() && !fileNameDirty) {
      $("dlvFileName").value = $("dlvSeqName").value;
    }
    // Auto-read the slate MOGRT whenever the active sequence changes.
    if (n !== lastSlateSeq) {
      lastSlateSeq = n;
      if (typeof readSlateNow === "function") readSlateNow(true);
    }
  });
}
setInterval(refreshSeqName, 2000);

/* ---- Track Layout: keep the range selectors clamped to what's actually in the
   sequence. Collapse Video Tracks already shifts them precisely via
   shiftTrackSelectors, but tracks can also disappear from a manual delete in
   Premiere's own timeline — this catches that case (and acts as a safety net
   after Collapse too) by polling the real video-track count and pulling any
   selector, and its max, back down if it points past the top track. */
var trackRangeIds = ["clipsLow", "clipsHigh", "gfxLow", "gfxHigh", "burnLow", "burnHigh"];
function clampTrackRanges(n) {
  if (!n || n < 1) return;
  for (var i = 0; i < trackRangeIds.length; i++) {
    var el = $(trackRangeIds[i]);
    if (!el || el === document.activeElement) continue;   // don't fight a live edit
    el.max = n;
    var v = parseInt(el.value, 10) || 1;
    if (v > n) el.value = n;
  }
}
function refreshTrackCount() {
  host("DH_videoTrackCount", {}, function (r) {
    if (r && r.ok && r.tracks) clampTrackRanges(r.tracks);
  });
}
setInterval(refreshTrackCount, 2000);
refreshTrackCount();

/* ---- folder pickers ---- */
function browse(kind, targetId) {
  host("DH_browse", { kind: kind }, function (r) {
    if (r.ok && r.path) $(targetId).value = r.path;
  });
}
$("browseOut").onclick    = function () { browse("folder", "outFolder"); };
$("dlvBrowseOut").onclick = function () { browse("folder", "dlvOutFolder"); };

/* ---- preset dropdowns ---- */
function fillSelect(sel, presets) {
  var prev = sel.value; sel.innerHTML = "";
  var ph = document.createElement("option");
  ph.value = ""; ph.textContent = "— choose preset —"; sel.appendChild(ph);
  for (var i = 0; i < presets.length; i++) {
    var o = document.createElement("option");
    o.value = presets[i].path; o.textContent = presets[i].name;
    sel.appendChild(o);
  }
  if (prev) sel.value = prev;
}
function populatePresetMenus() {
  host("DH_listPresets", { dir: EXT_PRESETS_DIR }, function (r) {
    var presets = (r && r.presets) ? r.presets : [];
    lastPresets = presets;
    fillSelect($("presetReference"), presets);
    fillSelect($("presetClean"), presets);
    fillSelect($("presetBurn"), presets);
    fillSelect($("presetSubmaster"), presets);
    var segSel = document.querySelectorAll(".seg-preset");
    for (var i = 0; i < segSel.length; i++) fillSelect(segSel[i], presets);
    if (presets.length === 0) log("No presets found.", "warn");
    else log("Loaded " + presets.length + " bundled preset(s).", "ok");
  });
}
function browseIntoEl(sel) {
  host("DH_browse", { kind: "epr" }, function (r) {
    if (!r.ok || !r.path) return;
    var exists = false;
    for (var i = 0; i < sel.options.length; i++)
      if (sel.options[i].value === r.path) { exists = true; break; }
    if (!exists) {
      var o = document.createElement("option");
      o.value = r.path;
      o.textContent = r.path.split(/[\\\/]/).pop().replace(/\.epr$/i, "") + "  (manual)";
      sel.appendChild(o);
    }
    sel.value = r.path;
  });
}
$("browseReference").onclick = function () { browseIntoEl($("presetReference")); };
$("browseClean").onclick    = function () { browseIntoEl($("presetClean")); };
$("browseBurn").onclick     = function () { browseIntoEl($("presetBurn")); };
$("browseSubmaster").onclick = function () { browseIntoEl($("presetSubmaster")); };

/* ---- Color Submaster toggle (shows/hides sub-opts and preset row) ---- */
function syncColorSubmaster() {
  var on = $("colorSubmaster").checked;
  if (!on) { $("colorSubmaster2k").checked = false; $("colorSubmaster4k").checked = false; }
  $("colorSubmasterOpts").classList.toggle("disabled", !on);
  $("presetSubmasterRow").classList.toggle("disabled", !on);
  var small = document.querySelector('.go.color small');
  if (small) {
    var tok = "";
    if (on && $("colorSubmaster4k").checked)      tok = " · 4K Sub";
    else if (on && $("colorSubmaster2k").checked) tok = " · 2K Sub";
    else if (on)                                  tok = " · Sub";
    small.textContent = "ref · ref+TC · ref-clean" + tok + " · XML · EDLs";
  }
}
$("colorSubmaster").addEventListener("change", syncColorSubmaster);
$("colorSubmaster2k").addEventListener("change", function () {
  if ($("colorSubmaster2k").checked) $("colorSubmaster4k").checked = false;   // pick one
  syncColorSubmaster();
});
$("colorSubmaster4k").addEventListener("change", function () {
  if ($("colorSubmaster4k").checked) $("colorSubmaster2k").checked = false;
  syncColorSubmaster();
});
syncColorSubmaster();

/* ---- Finish collect tokens: shown only when the matching box is checked ---- */
function syncFinishGfx() {
  var small = document.querySelector('.go.finish small');
  if (small) {
    small.textContent = "ref · ref+TC · XML · EDLs" +
      ($("collectVideo").checked ? " · Video collect" : "") +
      ($("collectGfx").checked   ? " · GFX collect"   : "");
  }
}
$("collectVideo").addEventListener("change", syncFinishGfx);
$("collectGfx").addEventListener("change", syncFinishGfx);
syncFinishGfx();

/* Audio "Burn-in reference" toggles the Audio button between ref and ref+TC. */
function syncAudioBurn() {
  var small = document.querySelector('.go.audio small');
  if (small) small.textContent = ($("audioBurn").checked ? "ref+TC" : "ref") + " · OMF";
}
$("audioBurn").addEventListener("change", syncAudioBurn);
syncAudioBurn();

/* Deliver-segment browse + remove + gfx-range stepper (all delegated) */
$("dlvSegments").addEventListener("click", function (e) {
  var t = e.target;
  // ⋯ browse
  if (t.className && t.className.indexOf("seg-browse") !== -1) {
    var sel = t.parentNode.querySelector(".seg-preset");
    if (sel) browseIntoEl(sel);
  }
  // − remove
  if (t.className && t.className.indexOf("seg-remove") !== -1) {
    var fs = t.closest ? t.closest(".dlv-seg") : t.parentNode;
    if (fs && fs.getAttribute("data-fixed") !== "1") fs.parentNode.removeChild(fs);
  }
  // ▲▼ steppers inside Generic gfx range
  if (t.className && (t.className.indexOf("seg-vup") !== -1 || t.className.indexOf("seg-vdn") !== -1)) {
    var isUp = t.className.indexOf("seg-vup") !== -1;
    var delta = isUp ? 1 : -1;
    // find sibling input inside this vstep
    var vstep = t.parentNode.parentNode; // va -> vstep
    var inp = vstep.querySelector(".vv");
    if (inp) {
      var v = (parseInt(inp.value, 10) || 1) + delta;
      if (v < 1) v = 1;
      inp.value = v;
      // normalize low/high within this segment
      var wrap = vstep.parentNode; // rangerow
      var lo = wrap.querySelector(".seg-gfx-low");
      var hi = wrap.querySelector(".seg-gfx-high");
      if (lo && hi) {
        var loV = parseInt(lo.value, 10) || 1;
        var hiV = parseInt(hi.value, 10) || 1;
        if (inp === lo && loV > hiV) hi.value = loV;
        if (inp === hi && hiV < loV) lo.value = hiV;
      }
    }
  }
});

// Toggle gfx range enabled state inside Generic (delegated via change on checkboxes)
$("dlvSegments").addEventListener("change", function (e) {
  var t = e.target;
  if (t.className && t.className.indexOf("seg-gfx-on") !== -1) {
    var fs = t.closest ? t.closest(".dlv-seg") : t.parentNode.parentNode.parentNode;
    var rangerow = fs.querySelector(".seg-gfx-range");
    if (rangerow) rangerow.classList.toggle("disabled", !t.checked);
  }
  if (t.className && t.className.indexOf("seg-isci-on") !== -1) {
    var fs2 = t.closest ? t.closest(".dlv-seg") : t.parentNode.parentNode;
    var inp = fs2.querySelector(".seg-isci");
    if (inp) { inp.disabled = !t.checked; if (t.checked) inp.focus(); }
  }
});

/* ---- Add segment ("+") ---- */
function addSegment() {
  var fs = document.createElement("fieldset");
  fs.className = "dlv-seg";
  fs.setAttribute("data-seg", "Additional Delivery");
  fs.innerHTML =
    '<legend>Additional Delivery' +
    '&nbsp;&nbsp;&nbsp;<span class="seg-remove" title="Remove this segment">−</span>' +
    '</legend>' +
    '<label class="chk"><input type="checkbox" class="seg-slate" /> Slate</label>' +
    '<label class="chk"><input type="checkbox" class="seg-noslate" /> No slate</label>' +
    '<label>Export preset</label>' +
    '<div class="row"><select class="seg-preset"><option value="">— choose preset —</option></select>' +
    '<button class="mini seg-browse" title="Pick a .epr file manually">⋯</button></div>';
  $("dlvSegments").appendChild(fs);
  fillSelect(fs.querySelector(".seg-preset"), lastPresets);
}
$("addSeg").onclick = addSegment;

/* ---- Track-range steppers ---- */
function pairOf(id) {
  if (id.indexOf("gfx") === 0)   return ["gfxLow", "gfxHigh"];
  if (id.indexOf("clips") === 0) return ["clipsLow", "clipsHigh"];
  return ["burnLow", "burnHigh"];
}
function normalizeRange(lowId, highId, changedId) {
  var lo = parseInt($(lowId).value, 10) || 1;
  var hi = parseInt($(highId).value, 10) || 1;
  if (lo < 1) { lo = 1; $(lowId).value = 1; }
  if (hi < 1) { hi = 1; $(highId).value = 1; }
  if (changedId === lowId)  { if (lo > hi) $(highId).value = lo; }
  else                      { if (hi < lo) $(lowId).value = hi; }
}
function stepBy(id, delta) {
  var el = $(id), v = (parseInt(el.value, 10) || 1) + delta;
  if (v < 1) v = 1; el.value = v;
  var p = pairOf(id); normalizeRange(p[0], p[1], id);
}
(function wireSteppers() {
  var ups = document.querySelectorAll(".vup"), dns = document.querySelectorAll(".vdn"), vals = document.querySelectorAll(".vv");
  for (var i = 0; i < ups.length; i++) ups[i].addEventListener("click", function () { stepBy(this.getAttribute("data-t"), 1); });
  for (var j = 0; j < dns.length; j++) dns[j].addEventListener("click", function () { stepBy(this.getAttribute("data-t"), -1); });
  for (var k = 0; k < vals.length; k++) vals[k].addEventListener("change", function () { var p = pairOf(this.id); normalizeRange(p[0], p[1], this.id); });
})();
function syncRange(checkId, rowId) { $(rowId).classList.toggle("disabled", !$(checkId).checked); }
$("gfxOn").addEventListener("change", function () { syncRange("gfxOn", "gfxRange"); });
$("burnOn").addEventListener("change", function () { syncRange("burnOn", "burnRange"); });
$("clipsOn").addEventListener("change", function () { syncRange("clipsOn", "clipsRange"); });
syncRange("gfxOn", "gfxRange");
syncRange("burnOn", "burnRange");

/* ---- Collapse Video Tracks (destructive — two-click confirm) ---- */
var collapseArmed = false, collapseTimer = null;
function disarmCollapse() {
  collapseArmed = false;
  if (collapseTimer) { clearTimeout(collapseTimer); collapseTimer = null; }
  var b = $("collapseTracks");
  b.classList.remove("danger");
  b.textContent = "Collapse Video Tracks";
}
$("collapseTracks").onclick = function () {
  if (!collapseArmed) {
    collapseArmed = true;
    this.classList.add("danger");
    this.textContent = "WARNING!! THIS DESTROYS MULTI-LAYER COMPS!";
    collapseTimer = setTimeout(disarmCollapse, 6000);   // auto-disarm if not confirmed
    return;
  }
  disarmCollapse();
  var low = parseInt($("clipsLow").value, 10) || 1, high = parseInt($("clipsHigh").value, 10) || 1;
  if (high < low) { var tmp = low; low = high; high = tmp; }
  this.disabled = true;
  log("──────────────");
  log("Collapsing video clips V" + low + "–V" + high + " → V1…");
  refreshSlateTargets(function () {
    host("DH_collapseVideoTracks", { low: low, high: high }, function (r) {
      if (r && r.log) for (var i = 0; i < r.log.length; i++) log(r.log[i].msg, r.log[i].cls);
      if (r && r.ok && (r.total || 1) === 1) {
        log("✓ Collapse complete — " + (r.moved || 0) + " clip(s) → V1, " + (r.disabledRemoved || 0) +
            " disabled removed, " + ((r.removedTracks && r.removedTracks.length) || 0) + " empty track(s) deleted.", "ok");
        if (r.removedTracks && r.removedTracks.length) shiftTrackSelectors(r.removedTracks);
      } else {
        prepReport(r, "Collapse complete");
      }
      refreshTrackCount();
      $("collapseTracks").disabled = false;
    });
  });
};

/* After empty tracks are deleted, shift the burn/gfx V-numbers down by the count
   of removed tracks that sat below each value. */
function shiftTrackSelectors(removed) {
  function shift(id) {
    var el = $(id); if (!el) return;
    var v = parseInt(el.value, 10) || 1, below = 0;
    for (var i = 0; i < removed.length; i++) if (removed[i] < v) below++;
    var nv = Math.max(1, v - below);
    if (nv !== v) el.value = nv;
  }
  shift("burnLow"); shift("burnHigh"); shift("gfxLow"); shift("gfxHigh"); shift("clipsLow"); shift("clipsHigh");
}

/* ---- Convert variable speed \u2192 constant (scan + build, one action) ---- */
var buildCsArmed = false, buildCsTimer = null;
function disarmBuildCs() {
  buildCsArmed = false;
  if (buildCsTimer) { clearTimeout(buildCsTimer); buildCsTimer = null; }
  var b = $("convertVarSpeed");
  b.classList.remove("danger");
  b.textContent = "Convert Variable Speed Clips to Constant";
}
$("convertVarSpeed").onclick = function () {
  if (!buildCsArmed) {
    buildCsArmed = true;
    this.classList.add("danger");
    this.textContent = "CONFIRM \u2014 THIS ADDS CLIPS TO YOUR SEQUENCE";
    buildCsTimer = setTimeout(disarmBuildCs, 6000);
    return;
  }
  disarmBuildCs();
  this.disabled = true;
  log("\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
  log("Converting variable speed clips to constant\u2026");
  refreshSlateTargets(function () {
    host("DH_buildConstantSpeed", {}, function (r) {
      if (r && r.log) for (var i = 0; i < r.log.length; i++) log(r.log[i].msg, r.log[i].cls);
      if (r && r.ok && (r.total || 1) === 1) {
        log("\u2713 Done \u2014 " + (r.built || 0) + " copy/copies built, " + (r.failed || 0) + " skipped.", "ok");
      } else {
        prepReport(r, "Variable-speed conversion done");
      }
      $("convertVarSpeed").disabled = false;
    });
  });
};


/* Log-side counterpart to slateReport, for the Prep page's fan-out runs. */
function prepReport(r, label) {
  if (!r) { log("\u2717 No response.", "err"); return; }
  var total = r.total || 1, updated = r.updated || 0, i;
  if (total > 1) {
    if (!updated) { log("\u2717 " + label + ": no sequence completed \u2014 " + (r.error || "failed."), "err"); return; }
    if (r.failures && r.failures.length) {
      for (i = 0; i < r.failures.length; i++) {
        log("\u2717 " + r.failures[i].seq + ": " + r.failures[i].error, "err");
      }
      log("\u26A0 " + label + ": " + updated + "/" + total + " sequences completed.", "warn");
      return;
    }
    log("\u2713 " + label + " \u2014 " + updated + " sequences.", "ok");
    return;
  }
  if (r.ok) log("\u2713 " + label + ".", "ok");
  else log("\u2717 " + (r.error || "Failed."), "err");
}

/* ====================== PREP ====================== */
function prepConfig() {
  return {
    seqName: $("seqName").value.trim(), outFolder: $("outFolder").value.trim(),
    omfHandles: parseInt($("omfHandles").value, 10) || 0,
    audioBurn: $("audioBurn").checked,
    presetReference: $("presetReference").value.trim(),
    presetClean: $("presetClean").value.trim(), presetBurn: $("presetBurn").value.trim(),
    gfxOn: $("gfxOn").checked, gfxLow: parseInt($("gfxLow").value, 10) || 1, gfxHigh: parseInt($("gfxHigh").value, 10) || 1,
    burnOn: $("burnOn").checked, burnLow: parseInt($("burnLow").value, 10) || 1, burnHigh: parseInt($("burnHigh").value, 10) || 1,
    colorSubmaster:    $("colorSubmaster").checked,
    colorSubmaster2k:  $("colorSubmaster2k").checked,
    colorSubmaster4k:  $("colorSubmaster4k").checked,
    presetSubmaster:   $("presetSubmaster").value.trim(),
    clipsOn: $("clipsOn").checked, clipsLow: parseInt($("clipsLow").value, 10) || 1, clipsHigh: parseInt($("clipsHigh").value, 10) || 1,
    collectGfx:        $("collectGfx").checked,
    collectVideo:      $("collectVideo").checked,
    groupByDept:       $("groupByDept").checked
  };
}
function prepValidate(team, c) {
  if (!c.seqName) return "Open a sequence in Premiere first.";
  if (!c.outFolder) return "Pick an output folder first.";
  if (!c.presetReference) return "Pick the Reference preset (used by every prep export).";
  if ((team === "color" || team === "all") && !c.presetClean)
    return "Pick the clean reference preset (used by the Color clean reference).";
  if (team !== "audio" && c.burnOn && !c.presetBurn) return "Pick the burn-in reference preset (or uncheck TC burn-ins).";
  if (team === "audio" && c.audioBurn && !c.presetBurn) return "Pick the Reference + Timecode burn-in preset for the audio burn-in reference.";
  return null;
}
function runPrep(team) {
  var c = prepConfig();
  var problem = prepValidate(team, c);
  if (problem) { log("✗ " + problem, "err"); return; }
  var buttons = document.querySelectorAll(".go[data-team]");
  for (var i = 0; i < buttons.length; i++) buttons[i].disabled = true;

  refreshSlateTargets(function () {
    var multi = slateTargetInfo.multi;
    log("──────────────");
    if (multi) {
      log("Prepping: " + team.toUpperCase() + "  ·  " + slateTargetInfo.count + " selected sequences");
      log("  " + slateTargetInfo.sequences.join(", "));
      log("  Layout: " + (c.groupByDept
            ? "grouped — <out>/<Department>/<sequence>_prep_<stamp>/"
            : "default — <out>/<sequence>/<run>/<Department>/"));
    } else {
      log("Prepping: " + team.toUpperCase() + "  ·  " + c.seqName);
    }
    host("DH_deliver", { team: team, config: c }, function (r) {
      if (r && r.log) for (var j = 0; j < r.log.length; j++) log(r.log[j].msg, r.log[j].cls);
      prepReport(r, "Prep " + team.toUpperCase() + " done — renders queued in Media Encoder");
      for (var k = 0; k < buttons.length; k++) buttons[k].disabled = false;
    });
  });
}
var prepBtns = document.querySelectorAll(".go[data-team]");
for (var pb = 0; pb < prepBtns.length; pb++)
  prepBtns[pb].onclick = function () { runPrep(this.getAttribute("data-team")); };

/* ====================== DELIVER ====================== */
function collectSegments() {
  var out = [], segs = document.querySelectorAll(".dlv-seg");
  for (var i = 0; i < segs.length; i++) {
    var fs = segs[i];
    var gfxOnEl  = fs.querySelector(".seg-gfx-on");
    var gfxLoEl  = fs.querySelector(".seg-gfx-low");
    var gfxHiEl  = fs.querySelector(".seg-gfx-high");
    var isciOnEl = fs.querySelector(".seg-isci-on");
    var isciEl   = fs.querySelector(".seg-isci");
    var nm = fs.getAttribute("data-seg");
    // Decide the filename suffix here, where the segment identity is unambiguous,
    // and send it to the host so it never has to infer it from the name.
    var sfx = (nm === "Specd Master") ? "_Spec"
            : (nm === "Generic")      ? "_Generic" : "";
    out.push({
      name:    nm,
      suffix:  sfx,
      slate:   fs.querySelector(".seg-slate").checked,
      noslate: fs.querySelector(".seg-noslate").checked,
      preset:  fs.querySelector(".seg-preset").value.trim(),
      gfxOn:   gfxOnEl  ? gfxOnEl.checked                   : false,
      gfxLow:  gfxLoEl  ? (parseInt(gfxLoEl.value, 10) || 1) : 1,
      gfxHigh: gfxHiEl  ? (parseInt(gfxHiEl.value, 10) || 1) : 1,
      isciOn:  (isciOnEl && !slateTargetInfo.multi) ? isciOnEl.checked : false,
      isci:    (isciEl   && !slateTargetInfo.multi) ? isciEl.value.trim() : ""
    });
  }
  return out;
}
function runDeliver() {
  var outFolder = $("dlvOutFolder").value.trim();
  var seqName = $("dlvSeqName").value.trim();
  if (!seqName) { dlog("✗ Open a sequence in Premiere first.", "err"); return; }
  if (!outFolder) { dlog("✗ Pick an output folder first.", "err"); return; }
  var segments = collectSegments(), any = false;
  for (var i = 0; i < segments.length; i++) if (segments[i].slate || segments[i].noslate) any = true;
  if (!any) { dlog("✗ Check Slate or No slate on at least one segment.", "err"); return; }
  updateFileName();                       // refresh override from current slate values
  var fileName = $("dlvFileName").value.trim() || seqName;
  // No-slate variant ignores the AD-ID override; if AD-ID was the only field,
  // fall back to the full name so we never end up with an empty filename.
  var fileNameNoSlate = fileName;
  if (anyOverride()) {
    var ns = buildOverrideName(true);
    if (ns) fileNameNoSlate = ns;
  }

  // Ordered list of ticked override fields. Across a selection the host rebuilds
  // the filename per sequence from this spec plus that sequence's own slate.
  var fnoFields = [];
  for (var f = 0; f < FNO.length; f++) if ($(FNO[f].id).checked) fnoFields.push(FNO[f].field);

  var adIdEl = slateInput("AD-ID");
  var adId = adIdEl ? adIdEl.value.trim() : "";

  $("dlvRun").disabled = true;

  refreshSlateTargets(function () {
    var multi = slateTargetInfo.multi;
    dlog("──────────────");
    if (multi) {
      dlog("Delivering: " + slateTargetInfo.count + " selected sequences");
      dlog("  " + slateTargetInfo.sequences.join(", "));
      dlog("  Naming: " + (fnoFields.length
            ? ("override [" + fnoFields.join(" + ") + "] read from each sequence's slate")
            : (fileNameDirty ? "custom filename applied to every sequence"
                             : "each sequence's own name")));
      dlog("  Layout: " + ($("dlvGroupByDept").checked
            ? "grouped — <out>/<Deliverable>/<sequence>_deliver_<stamp>/"
            : "default — <out>/<sequence>_deliver_<stamp>/<Deliverable>/"));
    } else {
      dlog("Delivering: " + fileName);
    }
    host("DH_runDeliver3", { config: {
      outFolder: outFolder, seqName: seqName,
      fileName: fileName, fileNameNoSlate: fileNameNoSlate,
      fnoFields: fnoFields, fileNameDirty: fileNameDirty,
      adId: adId, groupByDept: $("dlvGroupByDept").checked, segments: segments
    } }, function (r) {
      if (r && r.log) for (var j = 0; j < r.log.length; j++) dlog(r.log[j].msg, r.log[j].cls);
      dlvReport(r, "Delivery done — renders queued in Media Encoder");
      $("dlvRun").disabled = false;
    });
  });
}

/* Log-side reporter for the Deliver page's fan-out. */
function dlvReport(r, label) {
  if (!r) { dlog("\u2717 No response.", "err"); return; }
  var total = r.total || 1, updated = r.updated || 0, i;
  if (total > 1) {
    if (!updated) { dlog("\u2717 " + label + ": no sequence completed \u2014 " + (r.error || "failed."), "err"); return; }
    if (r.failures && r.failures.length) {
      for (i = 0; i < r.failures.length; i++) dlog("\u2717 " + r.failures[i].seq + ": " + r.failures[i].error, "err");
      dlog("\u26A0 " + label + ": " + updated + "/" + total + " sequences completed.", "warn");
      return;
    }
    dlog("\u2713 " + label + " \u2014 " + updated + " sequences.", "ok");
    return;
  }
  if (r.ok) dlog("\u2713 " + label + ".", "ok");
  else dlog("\u2717 " + (r.error || "Failed."), "err");
}

$("dlvRun").onclick = runDeliver;

/* ====================== EDIT ====================== */
function elog(m, c) { logTo("editLog", m, c); }
$("dupSeq").onclick = function () {
  $("dupSeq").disabled = true;
  elog("──────────────");
  elog("Duplicating selected sequence…");
  host("DH_dupSequence", {}, function (r) {
    if (r.log) for (var i = 0; i < r.log.length; i++) elog(r.log[i].msg, r.log[i].cls);
    if (r.ok) elog("✓ " + r.oldName + "  →  " + r.newName, "ok");
    else      elog("✗ " + (r.error || "Failed."), "err");
    $("dupSeq").disabled = false;
  });
};

/* ---- Edit clip tools ---- */
function edRunBtn(hostFn, payload, label, b) {
  b.disabled = true;
  elog("──────────────");
  elog(label + "…");
  host(hostFn, payload || {}, function (r) {
    if (r && r.log) for (var i = 0; i < r.log.length; i++) elog(r.log[i].msg, r.log[i].cls);
    if (r && r.ok) elog("✓ " + (r.message || (label + " done.")), "ok");
    else elog("✗ " + ((r && r.error) || "Failed."), "err");
    b.disabled = false;
  });
}

/* ---- Effects section: unified, rearrangeable button list ----
   Built-ins + user-added effects render into #edFxItems as draggable rows.
   Order persists in localStorage (dh_fxOrder); custom names in dh_customFx. */
var CFX_KEY = "dh_customFx";
var FXORD_KEY = "dh_fxOrder";
var FXHIDE_KEY = "dh_fxHidden";
var FX_ANCHOR_ID = "adj";   // new effects are inserted directly above this row
var cfxAllEffects = null; // cached list from host

var FX_BUILTINS = [
  { id: "warp",    buttons: [{ label: "Warp Stabilizer", fn: "DH_addEffect_warp" }] },
  { id: "lumetri", buttons: [{ label: "Lumetri Color",  named: "Lumetri Color" }] },
  { id: "gauss",   buttons: [{ label: "Gaussian Blur",  named: "Gaussian Blur" }] },
  { id: "dshadow", buttons: [{ label: "Drop Shadow",    named: "Drop Shadow" }] },
  { id: "adj",     buttons: [{ label: "Fitted Adjustment Layer", fn: "DH_fittedAdjustmentLayer" },
                             { label: "with Transform", fn: "DH_fittedAdjustmentLayerTransform", logLabel: "Fitted Adjustment Layer + Transform" }] },
  { id: "matte",   buttons: [{ label: "Fitted Black Video", fn: "DH_fittedBlackMatte" },
                             { label: "Fitted White Color Matte", fn: "DH_fittedWhiteMatte" }] },
  { id: "flip",    buttons: [{ label: "Flip Horizontal", fn: "DH_addEffect_flipH" },
                             { label: "Flip Vertical",   fn: "DH_addEffect_flipV" }] },
  { id: "key",     buttons: [{ label: "Ultra Key", named: "Ultra Key" },
                             { label: "Luma Key",  named: "Luma Key" }] }
];

function lsGetJSON(key) {
  var raw = null;
  try { raw = window.localStorage.getItem(key); } catch (e) {}
  if (!raw) return null;
  try { return JSON.parse(raw); } catch (e2) { return null; }
}
function lsSetJSON(key, val) {
  try { window.localStorage.setItem(key, JSON.stringify(val)); } catch (e) {}
}
function cfxLoad() { var a = lsGetJSON(CFX_KEY); return (a && a.length) ? a : []; }
function cfxSave(list) { lsSetJSON(CFX_KEY, list); }
function fxHiddenLoad() { var a = lsGetJSON(FXHIDE_KEY); return (a && a.length) ? a : []; }
function fxHiddenSave(list) { lsSetJSON(FXHIDE_KEY, list); }
function fxIsHidden(id) {
  var h = fxHiddenLoad();
  for (var i = 0; i < h.length; i++) if (h[i] === id) return true;
  return false;
}
function fxHide(id) {
  var h = fxHiddenLoad();
  for (var i = 0; i < h.length; i++) if (h[i] === id) return;
  h.push(id);
  fxHiddenSave(h);
}

/* Build every available unit (built-in + custom), regardless of hidden state. */
function fxAllUnits() {
  var units = [], i;
  for (i = 0; i < FX_BUILTINS.length; i++) units.push(FX_BUILTINS[i]);
  var custom = cfxLoad();
  for (i = 0; i < custom.length; i++) {
    var nm = String(custom[i]);
    units.push({ id: "cfx:" + nm, buttons: [{ label: nm, named: nm }], custom: true, name: nm });
  }
  return units;
}

/* Resolve the display order: saved ids first (if still valid), then any new units
   (inserted above the anchor row). Hidden rows are omitted. */
function fxUnitList() {
  var units = fxAllUnits(), i;
  var byId = {}, visible = [];
  for (i = 0; i < units.length; i++) {
    byId[units[i].id] = units[i];
    if (!fxIsHidden(units[i].id)) visible.push(units[i]);
  }
  var saved = lsGetJSON(FXORD_KEY);
  if (!saved || !saved.length) return visible;

  var ordered = [], seen = {};
  for (i = 0; i < saved.length; i++) {
    var id = String(saved[i]);
    if (byId[id] && !seen[id] && !fxIsHidden(id)) { ordered.push(byId[id]); seen[id] = true; }
  }
  // Units not in the saved order are new — drop them in above the anchor row.
  var fresh = [];
  for (i = 0; i < visible.length; i++) if (!seen[visible[i].id]) fresh.push(visible[i]);
  if (!fresh.length) return ordered;

  var anchor = -1;
  for (i = 0; i < ordered.length; i++) if (ordered[i].id === FX_ANCHOR_ID) { anchor = i; break; }
  if (anchor === -1) {
    for (i = 0; i < fresh.length; i++) ordered.push(fresh[i]);
    return ordered;
  }
  var out = [];
  for (i = 0; i < anchor; i++) out.push(ordered[i]);
  for (i = 0; i < fresh.length; i++) out.push(fresh[i]);
  for (i = anchor; i < ordered.length; i++) out.push(ordered[i]);
  return out;
}
function fxSaveOrderFromDOM() {
  var box = $("edFxItems");
  if (!box) return;
  var ids = [], kids = box.children;
  for (var i = 0; i < kids.length; i++) {
    var id = kids[i].getAttribute("data-fxid");
    if (id) ids.push(id);
  }
  lsSetJSON(FXORD_KEY, ids);
}

var fxDragEl = null;
var fxHoldTimer = null;
function fxClearHold() {
  if (fxHoldTimer) { window.clearTimeout(fxHoldTimer); fxHoldTimer = null; }
}
function fxDisarmAll() {
  var box = $("edFxItems");
  if (!box) return;
  var kids = box.children;
  for (var i = 0; i < kids.length; i++) {
    if (kids[i].className && String(kids[i].className).indexOf("armed") !== -1) kids[i].className = "fx-item";
  }
}
/* Click anywhere outside an armed row disarms it. */
document.addEventListener("mousedown", function (ev) {
  var t = ev.target;
  while (t && t !== document) {
    if (t.className && String(t.className).indexOf("fx-item") !== -1) return;
    t = t.parentNode;
  }
  fxDisarmAll();
}, true);

function fxRender() {
  var box = $("edFxItems");
  if (!box) return;
  box.innerHTML = "";
  var units = fxUnitList();
  for (var i = 0; i < units.length; i++) {
    (function (u) {
      var row = document.createElement("div");
      row.className = "fx-item";
      row.setAttribute("data-fxid", u.id);

      var grip = document.createElement("span");
      grip.className = "fx-grip";
      grip.title = "Drag to rearrange · click and hold to remove";
      grip.appendChild(document.createTextNode("\u283F"));
      grip.setAttribute("draggable", "true");
      grip.ondragstart = function (ev) {
        fxClearHold();
        fxDisarmAll();
        fxDragEl = row;
        row.className = "fx-item dragging";
        try { ev.dataTransfer.effectAllowed = "move"; ev.dataTransfer.setData("text/plain", u.id); } catch (e) {}
        try { ev.dataTransfer.setDragImage(row, 20, 14); } catch (e2) {}
      };
      grip.ondragend = function () {
        fxDragEl = null;
        row.className = "fx-item";
        fxSaveOrderFromDOM();
      };
      grip.onmousedown = function (ev) {
        if (ev && ev.stopPropagation) ev.stopPropagation();
        fxClearHold();
        fxHoldTimer = window.setTimeout(function () {
          fxHoldTimer = null;
          fxDisarmAll();
          row.className = "fx-item armed";
        }, 450);
      };
      grip.onmouseup = fxClearHold;
      grip.onmouseleave = fxClearHold;
      row.appendChild(grip);

      var fxDeleteRow = function () {
        if (u.custom) {
          // Custom rows live in the saved list — removing them there is enough.
          // Do NOT also fxHide(): a stale "cfx:" hidden entry blocks re-adding
          // the same effect from the picker later.
          var cur = cfxLoad(), out = [];
          for (var j = 0; j < cur.length; j++) if (cur[j] !== u.name) out.push(cur[j]);
          cfxSave(out);
        } else {
          fxHide(u.id);   // built-in rows are hidden (restorable), not deleted
        }
        fxRender();
        fxSaveOrderFromDOM();
        elog("✓ Removed effect row: " + u.buttons[0].label, "ok");
      };

      var btnWrap = document.createElement("div");
      btnWrap.className = "fx-btns";
      for (var b = 0; b < u.buttons.length; b++) {
        (function (spec) {
          var btn = document.createElement("button");
          btn.type = "button";
          btn.className = "go all";
          var lblSpan = document.createElement("span");
          lblSpan.className = "fx-lbl";
          lblSpan.appendChild(document.createTextNode(spec.label));
          btn.appendChild(lblSpan);
          btn.onclick = function (ev) {
            if (String(row.className).indexOf("armed") !== -1) {
              if (ev && ev.stopPropagation) ev.stopPropagation();
              fxDeleteRow();
              return;
            }
            var lbl = spec.logLabel || spec.label;
            if (spec.named) edRunBtn("DH_addEffectNamed", { name: spec.named }, lbl, btn);
            else edRunBtn(spec.fn, { ext: cs.getSystemPath(SystemPath.EXTENSION) }, lbl, btn);
          };
          btnWrap.appendChild(btn);
        })(u.buttons[b]);
      }
      row.appendChild(btnWrap);

      box.appendChild(row);
    })(units[i]);
  }
  fxRenderRestore();
}

/* Offer a one-click restore when built-in rows have been removed. */
function fxRenderRestore() {
  var box = $("edFxItems");
  if (!box) return;
  var hidden = fxHiddenLoad(), builtinHidden = 0, i, j;
  for (i = 0; i < hidden.length; i++) {
    if (String(hidden[i]).indexOf("cfx:") !== 0) builtinHidden++;
  }
  if (!builtinHidden) return;
  var link = document.createElement("button");
  link.type = "button";
  link.className = "fx-restore";
  link.appendChild(document.createTextNode("Restore " + builtinHidden + " removed default row(s)"));
  link.onclick = function () {
    var keep = [], h = fxHiddenLoad();
    for (var k = 0; k < h.length; k++) if (String(h[k]).indexOf("cfx:") === 0) keep.push(h[k]);
    fxHiddenSave(keep);
    fxRender();
    fxSaveOrderFromDOM();
  };
  box.appendChild(link);
}

/* Container-level drag routing: move the dragged row before/after hovered row. */
(function () {
  var box = $("edFxItems");
  if (!box) return;
  box.ondragover = function (ev) {
    if (!fxDragEl) return;
    if (ev.preventDefault) ev.preventDefault();
    try { ev.dataTransfer.dropEffect = "move"; } catch (e) {}
    var t = ev.target;
    while (t && t !== box && !(t.getAttribute && t.getAttribute("data-fxid"))) t = t.parentNode;
    if (!t || t === box || t === fxDragEl) return;
    var rect = t.getBoundingClientRect();
    var before = (ev.clientY - rect.top) < rect.height / 2;
    if (before) box.insertBefore(fxDragEl, t);
    else box.insertBefore(fxDragEl, t.nextSibling);
  };
  box.ondrop = function (ev) {
    if (ev.preventDefault) ev.preventDefault();
    fxSaveOrderFromDOM();
  };
})();

function cfxFilterList() {
  var listEl = $("fxList");
  if (!listEl) return;
  var q = ($("fxSearch").value || "").toLowerCase();
  var have = {}, saved = cfxLoad();
  for (var s = 0; s < saved.length; s++) have[saved[s]] = true;
  listEl.innerHTML = "";
  if (!cfxAllEffects || !cfxAllEffects.length) {
    var d = document.createElement("div");
    d.className = "modal-empty";
    d.appendChild(document.createTextNode("No effects found."));
    listEl.appendChild(d);
    return;
  }
  var shown = 0;
  for (var i = 0; i < cfxAllEffects.length; i++) {
    var name = cfxAllEffects[i];
    if (q && name.toLowerCase().indexOf(q) === -1) continue;
    (function (nm) {
      var it = document.createElement("button");
      it.type = "button";
      it.className = "modal-item" + (have[nm] ? " added" : "");
      it.appendChild(document.createTextNode(nm));
      it.onclick = function () {
        // Re-adding a previously deleted row: deleting put "cfx:<name>" in the
        // hidden list AND removed it from saved. If only the hidden entry
        // remains (stale), clear it — otherwise the row can never come back.
        var hid = fxHiddenLoad(), keep = [], wasHidden = false;
        for (var h = 0; h < hid.length; h++) {
          if (String(hid[h]) === "cfx:" + nm) { wasHidden = true; continue; }
          keep.push(hid[h]);
        }
        if (wasHidden) fxHiddenSave(keep);

        var cur = cfxLoad(), dup = false;
        for (var j = 0; j < cur.length; j++) if (cur[j] === nm) { dup = true; break; }
        if (!dup) { cur.push(nm); cfxSave(cur); }
        fxRender();
        fxSaveOrderFromDOM();
        cfxModalHide();
        elog("✓ Added effect button: " + nm, "ok");
      };
      listEl.appendChild(it);
    })(name);
    shown++;
  }
  if (!shown) {
    var e = document.createElement("div");
    e.className = "modal-empty";
    e.appendChild(document.createTextNode("No match for \u201C" + q + "\u201D."));
    listEl.appendChild(e);
  }
}
function cfxModalShow() {
  $("fxModal").style.display = "flex";
  $("fxSearch").value = "";
  if (cfxAllEffects) { cfxFilterList(); try { $("fxSearch").focus(); } catch (ef) {} return; }
  var listEl = $("fxList");
  listEl.innerHTML = "";
  var ld = document.createElement("div");
  ld.className = "modal-empty";
  ld.appendChild(document.createTextNode("Loading effects\u2026"));
  listEl.appendChild(ld);
  host("DH_listVideoEffects", {}, function (r) {
    if (r && r.ok && r.effects && r.effects.length) {
      cfxAllEffects = r.effects;
      cfxFilterList();
      try { $("fxSearch").focus(); } catch (ef2) {}
    } else {
      listEl.innerHTML = "";
      var err = document.createElement("div");
      err.className = "modal-empty";
      err.appendChild(document.createTextNode("✗ " + ((r && r.error) || "Could not load effects.")));
      listEl.appendChild(err);
    }
  });
}
function cfxModalHide() { $("fxModal").style.display = "none"; }

$("edFxAdd").onclick = function (ev) {
  if (ev && ev.stopPropagation) ev.stopPropagation();
  cfxModalShow();
};
$("fxModalClose").onclick = cfxModalHide;
$("fxModal").onclick = function (ev) { if (ev && ev.target === this) cfxModalHide(); };
$("fxSearch").oninput = cfxFilterList;
fxRender();

/* Transitions — split buttons: left half → clip's in point, right half → out point. */
/* ---- Transitions: duration = selected fraction × sequence timebase ---- */
var trFps = 0;

function trFrames() {
  var secs = Number($("trDurSel").value) || 0.5;
  if (!trFps) return 0;
  var f = Math.round(secs * trFps);
  return f < 1 ? 1 : f;
}
function trDurUpdate() {
  var el = $("trDurCalc");
  if (!el) return;
  if (!trFps) { el.innerHTML = "— open a sequence"; return; }
  var f = trFrames();
  el.innerHTML = "= " + f + " fr @ " + (Math.round(trFps * 1000) / 1000) + " fps";
}
function trFpsRefresh() {
  host("DH_seqFrameRate", {}, function (r) {
    trFps = (r && r.ok && r.fps) ? Number(r.fps) : 0;
    trDurUpdate();
  });
}
$("trDurSel").onchange = trDurUpdate;
$("trDurSel").onfocus = trFpsRefresh;   // re-read in case the active sequence changed
trFpsRefresh();

$("trGrid").addEventListener("click", function (e) {
  var t = e.target;
  while (t && t !== this && !(t.className && String(t.className).indexOf("trhalf") !== -1)) t = t.parentNode;
  if (!t || t === this) return;
  var name = t.getAttribute("data-tr"), edge = t.getAttribute("data-edge");
  if (!name) return;
  t.disabled = true;
  var secs = Number($("trDurSel").value) || 0.5;
  var label = name + " → " + (edge === "in" ? "in point" : "out point");
  elog("──────────────"); elog(label + "…");
  host("DH_addTransition", { name: name, edge: edge, seconds: secs }, function (r) {
    if (r && r.log) for (var i = 0; i < r.log.length; i++) elog(r.log[i].msg, r.log[i].cls);
    if (r && r.ok) elog("✓ " + (r.message || (label + " applied.")), "ok");
    else elog("✗ " + ((r && r.error) || "Failed."), "err");
    t.disabled = false;
    trFpsRefresh();
  });
});

/* ---- Social Guides ----
   Guides ship inside the extension in Guides/ (subfolders become headings;
   a leading number like "01 " sets the order and is hidden). Projects that
   still have the old 06_Tools ▸ Overlays ▸ SOCIAL_GUIDES… bin are listed too. */
var sgSelected = null;   // { kind: "file", path, w, h } or { kind: "proj", ref }
var SG_DIR = cs.getSystemPath(SystemPath.EXTENSION) + "/Guides";

function sgNodeRequire() {
  try { if (window.cep_node && typeof window.cep_node.require === "function") return window.cep_node.require; } catch (e) {}
  try { if (typeof require === "function") return require; } catch (e2) {}
  return null;
}
function sgLabel(name) { return String(name).replace(/\.[^.]+$/, "").replace(/^\d+[\s._-]+/, ""); }
function sgPngSize(fs, path) {
  try {
    var B = (typeof Buffer !== "undefined") ? Buffer : sgNodeRequire()("buffer").Buffer;
    var fd = fs.openSync(path, "r"), b = B.alloc(24);
    fs.readSync(fd, b, 0, 24, 0); fs.closeSync(fd);
    if (b.readUInt32BE(12) !== 0x49484452) return null;      // "IHDR"
    return { w: b.readUInt32BE(16), h: b.readUInt32BE(20) };
  } catch (e) { return null; }
}
/* [{ label, files: [{ label, path, w, h }] }] from Guides/ (top-level files go first). */
function sgReadFolder() {
  var req = sgNodeRequire(); if (!req) return [];
  var fs = req("fs"), pth = req("path"), groups = [];
  function files(dir) {
    var out = [];
    try {
      fs.readdirSync(dir).sort().forEach(function (n) {
        if (!/\.(png|jpe?g|tiff?|psd)$/i.test(n) || n.charAt(0) === ".") return;
        var full = pth.join(dir, n), sz = /\.png$/i.test(n) ? sgPngSize(fs, full) : null;
        out.push({ label: sgLabel(n), path: full, w: sz ? sz.w : 0, h: sz ? sz.h : 0, mock: /mock-?up/i.test(full) });
      });
    } catch (e) {}
    return out;
  }
  try {
    var top = files(SG_DIR);
    if (top.length) groups.push({ label: "", files: top });
    fs.readdirSync(SG_DIR).sort().forEach(function (n) {
      var full = pth.join(SG_DIR, n);
      try { if (n.charAt(0) !== "." && fs.statSync(full).isDirectory()) { var f = files(full); if (f.length) groups.push({ label: sgLabel(n), files: f }); } } catch (e) {}
    });
  } catch (e2) {}
  return groups;
}

var sgItems = [];        // index → selection object
function sgLoadList(cb) {
  var list = $("sgDDList"), html = "";
  sgItems = [];
  var groups = sgReadFolder();
  for (var g = 0; g < groups.length; g++) {
    if (groups[g].label) html += '<div class="dd-sep">--- ' + escapeHtml(groups[g].label) + ' ---</div>';
    for (var i = 0; i < groups[g].files.length; i++) {
      var f = groups[g].files[i];
      sgItems.push({ kind: "file", path: f.path, w: f.w, h: f.h, mock: f.mock });
      html += '<div class="dd-item" data-i="' + (sgItems.length - 1) + '">' + escapeHtml(f.label) + '</div>';
    }
  }
  list.innerHTML = html || '<div class="dd-empty">(no guides found)</div>';
  // Legacy: guides kept in the project's own bin.
  host("DH_listSocialGuides", {}, function (r) {
    if (r && r.ok && r.entries && r.entries.length) {
      var extra = '<div class="dd-sep">--- From this project ---</div>';
      for (var k = 0; k < r.entries.length; k++) {
        var e = r.entries[k];
        if (e.type === "sep") { extra += '<div class="dd-sep">' + escapeHtml(e.label) + '</div>'; continue; }
        sgItems.push({ kind: "proj", ref: e.ref });
        extra += '<div class="dd-item" data-i="' + (sgItems.length - 1) + '">' + escapeHtml(e.label) + '</div>';
      }
      if (!html) list.innerHTML = "";
      list.insertAdjacentHTML("beforeend", extra);
    }
    if (cb) cb(true);
  });
}

$("sgDDToggle").onclick = function (e) {
  e.stopPropagation();
  var willOpen = !$("sgDD").classList.contains("open");
  if (willOpen) sgLoadList();          // refresh each time it opens
  $("sgDD").classList.toggle("open");
};
document.addEventListener("click", function () { $("sgDD").classList.remove("open"); });
$("sgDDList").addEventListener("click", function (e) {
  var t = e.target;
  if (!t.className || t.className.indexOf("dd-item") === -1) return;
  sgSelected = sgItems[parseInt(t.getAttribute("data-i"), 10)] || null;
  $("sgDDToggle").textContent = t.textContent;
  $("sgDD").classList.remove("open");
});

$("sgAdd").onclick = function () {
  if (!sgSelected) { elog("Pick a social guide first.", "warn"); return; }
  var btn = this; btn.disabled = true;
  elog("──────────────");
  elog("Adding social guide…");
  var fn = sgSelected.kind === "file" ? "DH_addSocialGuideFile" : "DH_addSocialGuide";
  // UI mockups (any path containing "mockup") go on at 100%; safe-zone guides at 50%.
  var payload = sgSelected.kind === "file" ? { path: sgSelected.path, w: sgSelected.w, h: sgSelected.h, opacity: sgSelected.mock ? 100 : 50 } : { ref: sgSelected.ref };
  host(fn, payload, function (r) {
    btn.disabled = false;
    if (r && r.log) for (var i = 0; i < r.log.length; i++) elog(r.log[i].msg, r.log[i].cls);
    if (r && r.ok) elog("✓ " + (r.message || "Guide added."), "ok");
    else elog("✗ " + ((r && r.error) || "Failed."), "err");
  });
};

sgLoadList();

/* ---- Frame.io Notes: parse comments txt -> checklist + sequence markers ----
   Entry lines look like either of:
     [01:00:03:05 - 01:00:03:05] - Note text
     01:00:07:01 - Note text
   Header lines ("003 - Name - 11:08AM July 14, 2026") and the filename/export
   header carry no TC in SMPTE form and are skipped.

   Notes are stored per sequenceID in localStorage (dh_fioNotes), so each
   sequence keeps its own list. The section polls the active sequence and
   swaps its checklist to match — switch sequences and the notes follow;
   switch back and the old list (including checked-off state) returns. */
var FIO_KEY = "dh_fioNotes";
var FIO_LINE = /^\[?(\d{2}:\d{2}:\d{2}[:;]\d{2})(?:\s*-\s*\d{2}:\d{2}:\d{2}[:;]\d{2})?\]?\s*-\s*(.+)$/;

var fioSeqId = null;      // sequenceID currently shown
var fioSeqName = "";
var fioEntries = [];      // [{ tc, note, done }]
var fioFileName = "";

function fioStoreAll() { var o = lsGetJSON(FIO_KEY); return o ? o : {}; }
function fioStoreSave() {
  if (!fioSeqId) return;
  var all = fioStoreAll();
  if (fioEntries.length) all[fioSeqId] = { file: fioFileName, entries: fioEntries };
  else delete all[fioSeqId];
  lsSetJSON(FIO_KEY, all);
}
function fioStoreLoad(seqId) {
  var rec = fioStoreAll()[seqId];
  if (rec && rec.entries && rec.entries.length) {
    fioEntries = rec.entries;
    fioFileName = rec.file || "";
  } else {
    fioEntries = [];
    fioFileName = "";
  }
}

function fioParse(text) {
  var out = [];
  var lines = String(text).split(/\r\n|\r|\n/);
  for (var i = 0; i < lines.length; i++) {
    var line = lines[i].replace(/^\s+|\s+$/g, "");
    if (!line) continue;
    var m = line.match(FIO_LINE);
    if (m) out.push({ tc: m[1], note: m[2].replace(/^\s+|\s+$/g, ""), done: false });
  }
  return out;
}

function fioRender() {
  var list = $("fioList");
  var meta = $("fioMeta");
  list.innerHTML = "";

  if (!fioSeqId) {
    meta.style.display = "block";
    meta.textContent = "No active sequence.";
    $("fioLoad").disabled = true;
    $("fioMark").disabled = true;
    $("fioClear").disabled = true;
    list.classList.remove("on");
    return;
  }
  $("fioLoad").disabled = false;

  if (!fioEntries.length) {
    meta.style.display = "block";
    meta.textContent = "\u201C" + fioSeqName + "\u201D \u2014 no notes loaded.";
    $("fioMark").disabled = true;
    $("fioClear").disabled = true;
    list.classList.remove("on");
    return;
  }

  var doneN = 0;
  for (var i = 0; i < fioEntries.length; i++) if (fioEntries[i].done) doneN++;
  meta.style.display = "block";
  meta.textContent = (fioFileName ? fioFileName + " \u2014 " : "") +
                     doneN + " / " + fioEntries.length + " done \u2014 \u201C" + fioSeqName + "\u201D";
  $("fioMark").disabled = false;
  $("fioClear").disabled = false;

  for (var j = 0; j < fioEntries.length; j++) {
    (function (ent) {
      var row = document.createElement("div");
      row.className = "fio-row" + (ent.done ? " done" : "");
      var chk = document.createElement("input");
      chk.type = "checkbox";
      chk.checked = !!ent.done;
      var tc = document.createElement("span");
      tc.className = "fio-tc"; tc.textContent = ent.tc;
      var note = document.createElement("span");
      note.className = "fio-note"; note.textContent = ent.note;
      chk.addEventListener("click", function (e) {
        e.stopPropagation();
        ent.done = chk.checked;
        row.className = "fio-row" + (ent.done ? " done" : "");
        fioStoreSave();
        fioRender();
      });
      row.addEventListener("click", function () {
        host("DH_fioJump", { tc: ent.tc }, function (r) {
          if (!(r && r.ok)) elog("\u2717 Jump failed: " + ((r && r.error) || ent.tc), "err");
        });
      });
      row.appendChild(chk); row.appendChild(tc); row.appendChild(note);
      list.appendChild(row);
    })(fioEntries[j]);
  }
  list.classList.add("on");
}

/* Poll the host: when the active sequence changes, save nothing (rows already
   persist on every edit) and swap in that sequence's stored notes. */
function fioSyncSeq() {
  host("DH_activeSeqId", {}, function (r) {
    var id = (r && r.ok && r.id) ? r.id : null;
    var nm = (r && r.name) ? r.name : "";
    if (id === fioSeqId) {
      if (nm !== fioSeqName && id) { fioSeqName = nm; fioRender(); }
      return;
    }
    fioSeqId = id;
    fioSeqName = nm;
    if (id) fioStoreLoad(id); else { fioEntries = []; fioFileName = ""; }
    fioRender();
  });
}

$("fioLoad").onclick = function () { $("fioFile").value = ""; $("fioFile").click(); };
$("fioFile").addEventListener("change", function () {
  var f = this.files && this.files[0];
  if (!f) return;
  if (!fioSeqId) { elog("\u2717 No active sequence \u2014 open one first.", "err"); return; }
  var reader = new FileReader();
  reader.onload = function () {
    var parsed = fioParse(reader.result);
    if (!parsed.length) {
      elog("\u26A0 No timecoded notes found in " + f.name + ".", "warn");
      return;
    }
    fioEntries = parsed;
    fioFileName = f.name;
    fioStoreSave();
    fioRender();
    elog("\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
    elog("\u2713 Loaded " + parsed.length + " note(s) from " + f.name +
         " onto \u201C" + fioSeqName + "\u201D.", "ok");
  };
  reader.onerror = function () { elog("\u2717 Could not read " + f.name + ".", "err"); };
  reader.readAsText(f);
});

$("fioMark").onclick = function () {
  if (!fioEntries.length) return;
  var btn = this; btn.disabled = true;
  elog("\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
  elog("Placing " + fioEntries.length + " marker(s)\u2026");
  host("DH_fioMarkers", { entries: fioEntries }, function (r) {
    btn.disabled = false;
    if (r && r.log) for (var i = 0; i < r.log.length; i++) elog(r.log[i].msg, r.log[i].cls);
    if (r && r.ok) {
      elog("\u2713 " + r.placed + " of " + r.total + " marker(s) added.", "ok");
      if (r.results) for (var j = 0; j < r.results.length; j++) {
        if (!r.results[j].ok) elog("\u26A0 " + r.results[j].tc + " \u2014 outside sequence, skipped.", "warn");
      }
    } else {
      elog("\u2717 " + ((r && r.error) || "Failed."), "err");
    }
  });
};

/* Clears the loaded file + checklist for THIS sequence only. Markers already
   placed in Premiere are untouched \u2014 remove those in the timeline. */
$("fioClear").onclick = function () {
  if (!fioEntries.length) return;
  var n = fioEntries.length;
  fioEntries = [];
  fioFileName = "";
  fioStoreSave();
  fioRender();
  elog("\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
  elog("\u2713 Cleared " + n + " note(s) from \u201C" + fioSeqName +
       "\u201D. Markers already placed remain in the timeline.", "ok");
};

fioSyncSeq();
setInterval(fioSyncSeq, 1500);

/* ---- Developer: Command ID Explorer ---- */
function devLog(m, c) { logTo("devLog", m, c); }
function cmdCurrent() { return parseInt($("cmdId").value, 10) || 0; }
$("cmdPrev").onclick = function () { $("cmdId").value = cmdCurrent() - 1; };
$("cmdNext").onclick = function () { $("cmdId").value = cmdCurrent() + 1; };
$("cmdExec").onclick = function () {
  var id = cmdCurrent(), btn = this;
  btn.disabled = true;
  host("DH_execCommand", { id: id }, function (r) {
    btn.disabled = false;
    if (!r) { devLog(id + " → (no response)", "err"); return; }
    if (r.error) devLog(id + " → ✗ " + r.error, "err");
    else devLog(id + " → " + (r.result || "executed (watch Premiere)"), "ok");
    if (r.note) devLog("   " + r.note, "");
  });
};

/* ---- Developer: QE Explorer ---- */
$("qeInspect").onclick = function () {
  var expr = $("qeExpr").value.trim() || "qe.project", btn = this;
  btn.disabled = true;
  devLog("── QE: " + expr);
  host("DH_qeInspect", { expr: expr }, function (r) {
    btn.disabled = false;
    if (!r || !r.ok) { devLog("✗ " + ((r && r.error) || "failed"), "err"); return; }
    if (typeof r.value !== "undefined") devLog("= " + r.value + "  (" + r.type + ")", "ok");
    if (r.properties && r.properties.length) {
      devLog("properties (" + r.properties.length + "):");
      for (var i = 0; i < r.properties.length; i++) devLog("  · " + r.properties[i]);
    }
    if (r.methods && r.methods.length) {
      devLog("methods (" + r.methods.length + "):");
      devLog("  " + r.methods.join(", "));
    }
    if (typeof r.value === "undefined" && (!r.methods || !r.methods.length) && (!r.properties || !r.properties.length))
      devLog("(no methods/properties exposed)", "");
  });
};

/* ---- Developer: DOM Inspector ---- */
var lastDom = null;
function domFetch(label, cb) {
  host("DH_domState", {}, function (r) {
    if (!r || !r.ok) { devLog("✗ " + label + " failed", "err"); return; }
    cb(r);
  });
}
$("domInspect").onclick = function () {
  domFetch("inspect", function (r) {
    devLog("── DOM state:");
    for (var i = 0; i < r.lines.length; i++) devLog("  " + r.lines[i]);
  });
};
$("domSnap").onclick = function () {
  domFetch("snapshot", function (r) {
    lastDom = r.state;
    var pc = 0, p = r.state.props || {};
    for (var k in p) if (p.hasOwnProperty(k)) pc++;
    devLog("── Snapshot captured (" + pc + " properties" + (r.state.sel && r.state.sel.length ? " on " + r.state.sel[0] : "") + ").", "ok");
    if (!pc) devLog("   Select a clip in Premiere first, then Snapshot.", "warn");
  });
};
$("domCompare").onclick = function () {
  if (!lastDom) { devLog("Take a snapshot first.", "warn"); return; }
  domFetch("compare", function (r) {
    var changes = domDiffProps(lastDom, r.state);
    var struct = domDiff(lastDom, r.state);  // sequence/track/item level
    devLog("── Changed Properties");
    if (!changes.length && !struct.length) { devLog("  (no changes detected)", "warn"); return; }
    for (var i = 0; i < changes.length; i++) {
      devLog(changes[i].key);
      devLog("  " + changes[i].before);
      devLog("  ↓");
      devLog("  " + changes[i].after, "ok");
      devLog("----------------");
    }
    if (struct.length) {
      devLog("── Structural");
      for (var j = 0; j < struct.length; j++) devLog("  " + struct[j]);
    }
    // roll the baseline forward so successive changes chain (A→B→C)
    lastDom = r.state;
  });
};
/* Compare two clip property maps → [{key, before, after}] for each changed key,
   including keys that appeared or disappeared (added/removed components/params). */
function domDiffProps(b, a) {
  var bp = (b && b.props) || {}, ap = (a && a.props) || {}, out = [], seen = {};
  var k;
  for (k in bp) if (bp.hasOwnProperty(k)) {
    seen[k] = 1;
    var av = ap.hasOwnProperty(k) ? ap[k] : "(removed)";
    if (String(bp[k]) !== String(av)) out.push({ key: k, before: bp[k], after: av });
  }
  for (k in ap) if (ap.hasOwnProperty(k) && !seen[k]) {
    out.push({ key: k, before: "(absent)", after: ap[k] });
  }
  return out;
}
function domDiff(b, a) {
  var d = [];
  if (b.seq !== a.seq) d.push("active sequence: " + b.seq + " → " + a.seq);
  if (b.v !== a.v)     d.push("video tracks: " + b.v + " → " + a.v);
  if (b.a !== a.a)     d.push("audio tracks: " + b.a + " → " + a.a);
  if (b.items !== a.items) d.push("project items: " + b.items + " → " + a.items);
  var bs = (b.sel || []).join(" | "), as = (a.sel || []).join(" | ");
  if (bs !== as) d.push("selection: [" + bs + "] → [" + as + "]");
  return d;
}

/* ---- Developer: Activity Watcher ---- */
var watchTimer = null, watchPrev = null;
function watchSign(n) { return n > 0 ? "+" + n : "" + n; }
function watchDiff(b, a) {
  var d = [];
  if (b.seq !== a.seq) d.push("active sequence → " + (a.seq || "(none)"));
  if (b.vt !== a.vt) d.push("video tracks " + b.vt + " → " + a.vt);
  if (b.at !== a.at) d.push("audio tracks " + b.at + " → " + a.at);
  if (b.vclips !== a.vclips) d.push("video clips " + b.vclips + " → " + a.vclips + " (" + watchSign(a.vclips - b.vclips) + ")");
  if (b.aclips !== a.aclips) d.push("audio clips " + b.aclips + " → " + a.aclips + " (" + watchSign(a.aclips - b.aclips) + ")");
  if (b.items !== a.items) d.push("project items " + b.items + " → " + a.items + " (" + watchSign(a.items - b.items) + ")");
  var bs = (b.sel || []).join(" | "), as = (a.sel || []).join(" | ");
  if (bs !== as) d.push("selection → [" + (a.sel || []).join(", ") + "]");
  return d;
}
/* ---- Developer: panel & sequence metrics ----
   The panel's own size only exists on the client side (ExtendScript has no
   view of the CEP window), so geometry is read here and the sequence half is
   fetched from the host. The live readout is throttled with requestAnimation
   -Frame so dragging the panel edge doesn't thrash layout. */
(function () {
  var live = $("metricsLive");
  if (!live) return;
  var pending = false;

  function dims() {
    return {
      w: window.innerWidth,
      h: window.innerHeight,
      bw: document.body ? document.body.clientWidth : 0,
      bh: document.body ? document.body.clientHeight : 0,
      dpr: window.devicePixelRatio || 1
    };
  }

  function paint() {
    pending = false;
    var d = dims();
    live.textContent = d.w + " \u00d7 " + d.h + " css px    body " + d.bw + " \u00d7 " + d.bh +
                       "    dpr " + d.dpr;
  }

  function onResize() {
    if (pending) return;
    pending = true;
    if (window.requestAnimationFrame) window.requestAnimationFrame(paint);
    else setTimeout(paint, 16);
  }

  window.addEventListener("resize", onResize);
  paint();

  $("metricsReport").onclick = function () {
    var d = dims();
    devLog("\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
    devLog("\u2500\u2500 Panel", "ok");
    devLog("   window: " + d.w + " \u00d7 " + d.h + " css px");
    devLog("   body:   " + d.bw + " \u00d7 " + d.bh);
    devLog("   devicePixelRatio: " + d.dpr +
           "   \u2192 device px: " + Math.round(d.w * d.dpr) + " \u00d7 " + Math.round(d.h * d.dpr));
    devLog("   screen: " + screen.width + " \u00d7 " + screen.height +
           "   avail " + screen.availWidth + " \u00d7 " + screen.availHeight);
    devLog("   scrollbar gutter: " + (d.w - d.bw) + "px");

    try {
      var env = JSON.parse(cs.getHostEnvironment());
      devLog("\u2500\u2500 Host", "ok");
      devLog("   app: " + env.appName + " " + env.appVersion + "   locale: " + env.appLocale);
      if (env.appSkinInfo && env.appSkinInfo.appBarBackgroundColor) {
        var c = env.appSkinInfo.appBarBackgroundColor.color;
        devLog("   UI theme rgb: " + Math.round(c.red) + "," + Math.round(c.green) + "," + Math.round(c.blue));
      }
      if (env.appSkinInfo && env.appSkinInfo.baseFontSize) {
        devLog("   base font: " + env.appSkinInfo.baseFontFamily + " " + env.appSkinInfo.baseFontSize + "px");
      }
    } catch (e) { devLog("   (host environment unavailable)", "warn"); }

    host("DH_sequenceInfo", {}, function (r) {
      if (r && r.log) for (var i = 0; i < r.log.length; i++) devLog(r.log[i].msg, r.log[i].cls);
      if (!r || !r.ok) devLog("\u2717 " + ((r && r.error) || "Sequence report failed."), "err");
    });
  };
})();

$("watchToggle").onclick = function () {
  if (watchTimer) {
    clearInterval(watchTimer); watchTimer = null; watchPrev = null;
    this.textContent = "Start watching";
    devLog("── watcher stopped.");
    return;
  }
  this.textContent = "Stop watching";
  devLog("── watching (poll ~1s). Do something in Premiere…");
  host("DH_watchState", {}, function (r) { if (r && r.ok) watchPrev = r.state; });
  watchTimer = setInterval(function () {
    host("DH_watchState", {}, function (r) {
      if (!r || !r.ok) return;
      if (watchPrev) { var d = watchDiff(watchPrev, r.state); for (var i = 0; i < d.length; i++) devLog("• " + d[i], "ok"); }
      watchPrev = r.state;
    });
  }, 1000);
};

/* ---- Filename override (Deliver page) ---- */
var FNO = [
  { field: "AD-ID",    id: "fnoAdid" },
  { field: "CLIENT",   id: "fnoClient" },
  { field: "TITLE",    id: "fnoTitle" },
  { field: "SEQ NAME", id: "fnoSeqName", source: "seq" },
  { field: "DURATION", id: "fnoDuration" }
];
var fileNameDirty = false;   // user typed a custom name
function anyOverride() {
  for (var i = 0; i < FNO.length; i++) if ($(FNO[i].id).checked) return true;
  return false;
}
function fnoClean(s) {
  // Strip characters that don't belong in a filename: colon (DURATION),
  // straight quotes (TITLE), and other illegal path characters — plus the
  // typographic/smart quote characters a TITLE field commonly carries
  // (curly single/double quotes, low/high quotes, guillemets, backtick).
  return String(s)
    .replace(/[:"'\/\\|?*<>]/g, "")
    .replace(/[\u2018\u2019\u201A\u201B\u201C\u201D\u201E\u201F\u2039\u203A\u00AB\u00BB`]/g, "")
    .replace(/\s+/g, " ").trim();
}
function buildOverrideName(excludeAdId) {
  var parts = [];
  for (var i = 0; i < FNO.length; i++) {
    if (!$(FNO[i].id).checked) continue;
    if (excludeAdId && FNO[i].field === "AD-ID") continue;   // No-slate drops AD-ID
    var v;
    if (FNO[i].source === "seq") {                           // SEQ NAME: from Output section
      v = fnoClean($("dlvSeqName").value);
    } else {
      var inp = (typeof slateInput === "function") ? slateInput(FNO[i].field) : null;
      v = inp ? fnoClean(inp.value) : "";
    }
    if (v) parts.push(v);
  }
  return parts.join("_");
}
function updateFileName() {
  if (anyOverride()) {
    $("dlvFileName").value = buildOverrideName();
    fileNameDirty = false;          // override drives the value
  } else if (!fileNameDirty) {
    $("dlvFileName").value = $("dlvSeqName").value;
  }
}
(function wireFilenameOverride() {
  for (var i = 0; i < FNO.length; i++)
    $(FNO[i].id).addEventListener("change", updateFileName);
  $("dlvSeqName").addEventListener("input", updateFileName);   // SEQ NAME override tracks this
  $("dlvFileName").addEventListener("input", function () {
    if (!anyOverride()) fileNameDirty = true;
  });
})();

/* ---- init ---- */
log("Ready. Open the sequence you want to prep, then choose a team.", "ok");
populatePresetMenus();
refreshSeqName();

/* ====================== SLATE ====================== */
var SLATE_REQUEST_FIELDS = ["AGENCY", "CLIENT", "TITLE", "AD-ID", "AUDIO", "DURATION", "DATE", "FORMAT", "COPYRIGHT"];   // Signal Slate MOGRT, in its order

function slateStatus(msg, cls) {
  var el = $("slateStatus");
  el.textContent = msg;
  el.style.color = cls === "err" ? "#e06c6c" : cls === "ok" ? "#7fd18a" : "";
}
function escapeHtml(s) {
  return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

/* Build the fixed field rows: label · value · Set · on/off toggle.
   The DATE row also gets a shortened input + a TODAY checkbox. */
(function buildSlateFields() {
  var wrap = $("slateFields");
  var html = "";
  for (var i = 0; i < SLATE_REQUEST_FIELDS.length; i++) {
    var f = SLATE_REQUEST_FIELDS[i];
    var isDate = (f === "DATE");
    var valCell = isDate
      ? '<span class="slate-val date-cell"><input type="text" class="slate-val-input date-input" data-field="DATE" />' +
          '<label class="today-chk"><input type="checkbox" id="slateToday" checked /> TODAY</label></span>'
      : '<input type="text" class="slate-val" data-field="' + escapeHtml(f) + '" />';
    html += '<div class="slate-row" data-field="' + escapeHtml(f) + '">' +
      '<label class="slate-lbl">' + escapeHtml(f) + '</label>' +
      valCell +
      '<button class="mini slate-set" tabindex="-1" data-field="' + escapeHtml(f) + '">Set</button>' +
      '<label class="slate-toggle" title="Field on/off in the MOGRT">' +
        '<input type="checkbox" class="slate-tog" tabindex="-1" data-field="' + escapeHtml(f) + '" checked />' +
        '<span class="tog-track"><span class="tog-knob"></span></span>' +
      '</label>' +
      '</div>';
  }
  wrap.innerHTML = html;
})();

/* M/D/YY for today — single-digit month/day are NOT zero-padded. */
function todayMMDDYY() {
  var d = new Date();
  return (d.getMonth() + 1) + "/" + d.getDate() + "/" + String(d.getFullYear()).slice(-2);
}
/* When TODAY is checked, force the DATE field to today's date and lock it. */
function applyTodayDate() {
  var on = $("slateToday") && $("slateToday").checked;
  var el = slateInput("DATE");
  if (!el) return;
  if (on) { el.value = todayMMDDYY(); el.readOnly = true; el.classList.add("locked"); }
  else { el.readOnly = false; el.classList.remove("locked"); }
}
if ($("slateToday")) $("slateToday").addEventListener("change", function () {
  applyTodayDate();
  if (typeof updateFileName === "function") updateFileName();
});
applyTodayDate();   // TODAY defaults checked — populate the date immediately

function slateInput(field) {
  var inputs = document.querySelectorAll('#slateFields input[type="text"][data-field]');
  for (var i = 0; i < inputs.length; i++)
    if (inputs[i].getAttribute("data-field") === field) return inputs[i];
  return null;
}
function slateRowEl(field) {
  var rows = document.querySelectorAll("#slateFields .slate-row");
  for (var i = 0; i < rows.length; i++)
    if (rows[i].getAttribute("data-field") === field) return rows[i];
  return null;
}
function slateTog(field) {
  var togs = document.querySelectorAll("#slateFields .slate-tog");
  for (var i = 0; i < togs.length; i++)
    if (togs[i].getAttribute("data-field") === field) return togs[i];
  return null;
}
/* Apply on/off to a row: off rows dim their label, but the text field stays
   fully editable and the toggle stays interactive. */
function applyRowToggle(field, on) {
  var row = slateRowEl(field), tog = slateTog(field);
  if (tog) { tog.checked = !!on; tog.disabled = false; }
  if (row) row.className = "slate-row" + (on ? "" : " off");
}

/* ---- Multi-sequence targets ----------------------------------------------
   Writes go to the active sequence, unless 2+ sequences are selected in the
   Project panel \u2014 then they go to all of them. Reads always come from the
   active sequence, so the Slate Reader fields stay the source of truth that
   gets pushed out. ---------------------------------------------------------- */
var slateTargetInfo = { multi: false, count: 1, sequences: [] };

function paintTargetBanner(elId, verb) {
  var el = $(elId);
  if (!el) return;
  if (slateTargetInfo.multi) {
    el.style.display = "";
    el.className = "hint slate-targets multi";
    el.textContent = "\u26A1 " + slateTargetInfo.count + " sequences selected in Project \u2014 " + verb;
    el.title = slateTargetInfo.sequences.join("\n");
  } else {
    el.style.display = "none";
    el.textContent = "";
    el.title = "";
  }
}

function slateTargetBanner() {
  paintTargetBanner("slateTargets", "Set writes to all of them.");
  paintTargetBanner("prepTargets", "Prep runs on all of them.");
  paintTargetBanner("dlvTargets", "Deliver runs on all of them \u2014 filenames rebuilt per sequence.");
  applyIsciLock();
}

/* AD-ID override is a single literal value, so it cannot span a selection.
   Grey it out (and clear it) whenever 2+ sequences are targeted. */
function applyIsciLock() {
  var multi = slateTargetInfo.multi;
  var wraps = document.querySelectorAll(".isci-wrap");
  for (var i = 0; i < wraps.length; i++) {
    var w = wraps[i];
    var on = w.querySelector(".seg-isci-on");
    var txt = w.querySelector(".seg-isci");
    if (on) {
      if (multi && on.checked) on.checked = false;
      on.disabled = multi;
    }
    if (txt) {
      if (multi) txt.value = "";
      txt.disabled = multi || !(on && on.checked);
    }
    w.className = multi ? "isci-wrap locked" : "isci-wrap";
    w.title = multi ? "Unavailable while multiple sequences are selected \u2014 an AD-ID override applies to one spot only." : "";
  }
}

function refreshSlateTargets(cb) {
  host("DH_getSlateTargets", {}, function (r) {
    if (r && r.ok) slateTargetInfo = { multi: !!r.multi, count: r.count || 0, sequences: r.sequences || [] };
    else slateTargetInfo = { multi: false, count: 1, sequences: [] };
    slateTargetBanner();
    if (cb) cb();
  });
}

/* Shared result formatter for the fan-out writers. */
function slateReport(r, label) {
  if (!r) { slateStatus("\u2717 No response.", "err"); return; }
  var total = r.total || 1, updated = r.updated || 0, i;
  if (total > 1) {
    if (!updated) { slateStatus("\u2717 " + label + ": no sequence updated \u2014 " + (r.error || "failed."), "err"); return; }
    if (r.failures && r.failures.length) {
      var names = [];
      for (i = 0; i < r.failures.length; i++) names.push(r.failures[i].seq);
      slateStatus("\u26A0 " + label + ": " + updated + "/" + total + " sequences \u2014 skipped " + names.join(", "), "warn");
      return;
    }
    slateStatus("\u2713 " + label + " \u2192 " + updated + " sequences.", "ok");
    return;
  }
  if (r.ok) slateStatus("\u2713 " + label + ".", "ok");
  else slateStatus("\u2717 " + (r.error || "Failed."), "err");
}

/* Poll while the Slate page is showing so the banner tracks Project-panel
   selection without the user having to click into the panel first. */
(function () {
  window.setInterval(function () {
    var ids = ["page-slate", "page-prep", "page-deliver"], vis = false;
    for (var v = 0; v < ids.length; v++) {
      var pg = $(ids[v]);
      if (pg && pg.offsetParent !== null) { vis = true; break; }
    }
    if (!vis) return;
    refreshSlateTargets();
  }, 1500);
})();

/* On/off switches only show for slates that have "<field> ON/OFF" controls
   (the legacy Harbor slate); the Signal Slate has none. */
function setSlateToggles(show) {
  var fs = $("slateFields").parentNode;
  if (fs) fs.classList.toggle("no-toggles", !show);
}

/* Reads the slate MOGRT from the active sequence and populates the fields and
   their on/off toggles. Auto-called when the active sequence changes and on
   entering Slate/Deliver. */
function readSlateNow(silent) {
  if (!silent) slateStatus("Reading…");
  host("DH_readSlate", {}, function (r) {
    if (!r || !r.ok) {
      if (!silent) slateStatus("✗ " + ((r && r.error) || "Failed."), "err");
      if (typeof updateFileName === "function") updateFileName();
      return;
    }
    if (!r.found) {
      for (var j = 0; j < SLATE_REQUEST_FIELDS.length; j++) {
        var e2 = slateInput(SLATE_REQUEST_FIELDS[j]); if (e2) e2.value = "";
        applyRowToggle(SLATE_REQUEST_FIELDS[j], true);   // default on
      }
      setSlateToggles(false);
      slateStatus("No slate in this sequence — use Insert Signal Slate.", "");
      if (typeof updateFileName === "function") updateFileName();
      return;
    }
    var fields = r.fields || {}, toggles = r.toggles || {};
    var anyTog = false;
    for (var tk in toggles) if (toggles[tk] && toggles[tk].present) anyTog = true;
    setSlateToggles(anyTog);
    for (var i = 0; i < SLATE_REQUEST_FIELDS.length; i++) {
      var f = SLATE_REQUEST_FIELDS[i];
      var el = slateInput(f);
      if (el) el.value = fields[f] || "";
      var tg = toggles[f] || { present: false, on: true };
      applyRowToggle(f, tg.present ? tg.on : true);   // reflect MOGRT, else default on
    }
    var matched = 0;
    for (var k in fields) if (fields[k]) matched++;
    slateStatus("✓ Read from: " + (r.clipName || "MOGRT") + "  ·  " + matched + "/" + SLATE_REQUEST_FIELDS.length + " fields matched.", "ok");
    applyTodayDate();
    if (typeof updateFileName === "function") updateFileName();
  });
}

/* One path for setting a field, shared by the Set button and the Enter key. */
function slateSetField(field) {
  if (!field) return;
  var input = slateInput(field);
  var val = input ? input.value : "";
  slateStatus("Setting " + field + "…");
  refreshSlateTargets(function () {
    host("DH_setSlateField", { field: field, value: val }, function (r) {
      slateReport(r, field + " updated in MOGRT");
    });
  });
}

/* Set buttons (delegated). */
$("slateFields").addEventListener("click", function (e) {
  var t = e.target;
  if (!t.className || t.className.indexOf("slate-set") === -1) return;
  slateSetField(t.getAttribute("data-field"));
});

/* Enter inside a field sets that field to the MOGRT. preventDefault keeps the
   panel from treating it as a form submit; the caret stays put so the value
   can be adjusted and re-sent. */
$("slateFields").addEventListener("keydown", function (e) {
  if (e.keyCode !== 13 && e.key !== "Enter") return;
  var t = e.target;
  if (!t || t.tagName !== "INPUT" || t.type !== "text") return;
  var field = t.getAttribute("data-field");
  if (!field) return;
  e.preventDefault();
  slateSetField(field);
});

/* "All" — set every field to its MOGRT field at once. */
$("slateSetAll").onclick = function () {
  var btn = this;
  btn.disabled = true;

  refreshSlateTargets(function () {
    var multi = slateTargetInfo.multi;
    var total = multi ? slateTargetInfo.count : 1;

    /* Sequential, not parallel: each call may open a sequence to reach its
       MOGRT, and overlapping evalScripts fight over the active sequence. */
    var i = 0, fieldsFailed = 0, seqFail = {}, seqNames = [];

    function step() {
      if (i >= SLATE_REQUEST_FIELDS.length) { finish(); return; }
      var f = SLATE_REQUEST_FIELDS[i++];
      var el = slateInput(f);
      slateStatus("Setting " + f + "… (" + i + "/" + SLATE_REQUEST_FIELDS.length + ")");
      host("DH_setSlateField", { field: f, value: el ? el.value : "" }, function (r) {
        if (!r || !r.updated) fieldsFailed++;
        if (r && r.failures) {
          for (var k = 0; k < r.failures.length; k++) {
            var nm = r.failures[k].seq;
            if (!seqFail[nm]) { seqFail[nm] = 0; seqNames.push(nm); }
            seqFail[nm]++;
          }
        }
        step();
      });
    }

    function finish() {
      btn.disabled = false;
      var scope = multi ? (" across " + total + " sequences") : "";
      if (fieldsFailed) {
        slateStatus("\u26A0 Set all: " + fieldsFailed + " field(s) had no matching MOGRT param" + scope + ".", "warn");
      } else if (seqNames.length) {
        slateStatus("\u26A0 Set all: partial \u2014 issues in " + seqNames.join(", "), "warn");
      } else {
        slateStatus("\u2713 All fields written to the MOGRT" + scope + ".", "ok");
      }
    }

    step();
  });
};

/* Per-row on/off toggle (delegated). Optimistically dims, then confirms. */
$("slateFields").addEventListener("change", function (e) {
  var t = e.target;
  if (!t.className || t.className.indexOf("slate-tog") === -1) return;
  var field = t.getAttribute("data-field");
  var on = t.checked;
  applyRowToggle(field, on);
  slateStatus((on ? "Enabling " : "Disabling ") + field + "…");
  refreshSlateTargets(function () {
    host("DH_setSlateToggle", { field: field, on: on }, function (r) {
      if (!r || !r.updated) applyRowToggle(field, !on);   // revert on total failure
      slateReport(r, field + (on ? " on" : " off") + " in MOGRT");
    });
  });
});

/* ============================ Slate Mapper ============================ */
/* Excel template I/O. Node is enabled in the manifest, so we use require() for
   SheetJS (a <script> tag would attach to module.exports, not window) and Node's
   fs for the bytes; file pickers come from the ExtendScript host. */
var XLSX = (function () {
  var paths = [];
  try {
    var root = cs.getSystemPath(SystemPath.EXTENSION);   // same call used for Presets
    if (root) paths.push(root + "/client/xlsx.full.min.js", root + "/xlsx.full.min.js");
  } catch (e) {}
  paths.push("./xlsx.full.min.js", "./client/xlsx.full.min.js", "xlsx.full.min.js");
  for (var i = 0; i < paths.length; i++) {
    try { var m = require(paths[i]); if (m && m.utils) return m; } catch (e) {}
  }
  return (typeof window !== "undefined" && window.XLSX) || null;   // <script> fallback
})();
var fsNode = (function () { try { return require("fs"); } catch (e) { return null; } })();

var mapRows = [];   // imported rows, each an object keyed by the column headers

function mapStatus(msg, cls) {
  var el = $("mapStatus"); if (!el) return;
  el.textContent = msg;
  el.style.color = cls === "err" ? "#e06c6c" : cls === "ok" ? "#7fd18a" : "";
}
function cepEnc() { return (window.cep && window.cep.encoding && window.cep.encoding.Base64) || "Base64"; }
function writeBytes(path, b64) {
  if (fsNode) { fsNode.writeFileSync(path, Buffer.from(b64, "base64")); return; }
  if (window.cep && window.cep.fs) { var r = window.cep.fs.writeFile(path, b64, cepEnc()); if (r && r.err) throw "cep.fs err " + r.err; return; }
  throw "No file API available.";
}
function readWorkbook(path) {
  if (fsNode) return XLSX.read(fsNode.readFileSync(path), { type: "buffer" });
  if (window.cep && window.cep.fs) {
    var r = window.cep.fs.readFile(path, cepEnc());
    if (!r || r.err) throw "cep.fs read err " + (r && r.err);
    return XLSX.read(r.data, { type: "base64" });
  }
  throw "No file API available.";
}

function mapExportTemplate() {
  if (!XLSX) { mapStatus("✗ Spreadsheet library not loaded.", "err"); return; }
  // Default name STN_Slate_Template_0001, _0002, … — the number goes up after each export.
  var n = 1;
  try { n = parseInt(localStorage.getItem("stnSlateTemplateNum"), 10) || 1; } catch (eN) {}
  var name = "STN_Slate_Template_" + ("000" + n).slice(-4) + ".xlsx";
  host("DH_saveDialog", { name: name }, function (r) {
    if (!r || !r.ok || !r.path) { mapStatus("Export cancelled."); return; }
    try {
      var ws = XLSX.utils.aoa_to_sheet([SLATE_REQUEST_FIELDS]);   // header row, in MOGRT order
      var wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Slate");
      writeBytes(r.path, XLSX.write(wb, { bookType: "xlsx", type: "base64" }));
      mapStatus("✓ Template saved: " + r.path, "ok");
      try { localStorage.setItem("stnSlateTemplateNum", String(n + 1)); } catch (eS) {}
    } catch (e) { mapStatus("✗ " + e, "err"); }
  });
}

function mapImportTemplate() {
  if (!XLSX) { mapStatus("✗ Spreadsheet library not loaded.", "err"); return; }
  host("DH_openDialog", {}, function (r) {
    if (!r || !r.ok || !r.path) { mapStatus("Import cancelled."); return; }
    try {
      var wb = readWorkbook(r.path);
      var ws = wb.Sheets[wb.SheetNames[0]];
      mapRows = XLSX.utils.sheet_to_json(ws, { defval: "" });   // keyed by header text
      populateMapSelect(mapRows);
      mapStatus("✓ Imported " + mapRows.length + " spot(s) from " + r.path.split(/[\\/]/).pop(), "ok");
    } catch (e) { mapStatus("✗ " + e, "err"); mapRows = []; populateMapSelect([]); }
  });
}

function populateMapSelect(rows) {
  var toggle = $("mapDDToggle"), list = $("mapDDList");
  if (!rows || !rows.length) {
    toggle.textContent = "— import a template first —";
    list.innerHTML = '<div class="dd-empty">No rows.</div>';
    return;
  }
  toggle.textContent = "— select a spot —";
  var html = "";
  for (var i = 0; i < rows.length; i++) {
    var ad = rows[i]["AD-ID"] != null ? String(rows[i]["AD-ID"]) : "";
    var ti = rows[i]["TITLE"] != null ? String(rows[i]["TITLE"]) : "";
    var du = rows[i]["DURATION"] != null ? String(rows[i]["DURATION"]) : "";
    var label = (ad || ti || du) ? (ad + " " + ti + " " + du) : ("Row " + (i + 1));
    html += '<div class="dd-item" data-idx="' + i + '">' + escapeHtml(label) + "</div>";
  }
  list.innerHTML = html;
}

/* Custom dropdown (native <select> popups can fail to open in CEP after a
   file dialog). Toggle open on the button; close on outside click or pick. */
$("mapDDToggle").addEventListener("click", function (e) {
  e.stopPropagation();
  $("mapDD").classList.toggle("open");
});
document.addEventListener("click", function () { $("mapDD").classList.remove("open"); });
$("mapDDList").addEventListener("click", function (e) {
  var t = e.target;
  if (!t.className || t.className.indexOf("dd-item") === -1) return;
  var row = mapRows[Number(t.getAttribute("data-idx"))];
  $("mapDD").classList.remove("open");
  if (!row) return;
  $("mapDDToggle").textContent = t.textContent;
  for (var i = 0; i < SLATE_REQUEST_FIELDS.length; i++) {
    var f = SLATE_REQUEST_FIELDS[i], el = slateInput(f);
    if (el) el.value = (row[f] != null) ? String(row[f]) : "";
  }
  if (typeof applyTodayDate === "function") applyTodayDate();   // TODAY wins over mapper data
  if (typeof updateFileName === "function") updateFileName();
  mapStatus('Loaded "' + (row["AD-ID"] || "") + "_" + (row["TITLE"] || "") + '" into the reader fields — use each row\'s Set to write to the MOGRT.', "");
});

function mapDateMMDD() {
  var d = new Date();
  return ("0" + (d.getMonth() + 1)).slice(-2) + ("0" + d.getDate()).slice(-2);
}

$("mapExport").onclick = mapExportTemplate;
$("mapImport").onclick = mapImportTemplate;
if (!XLSX) mapStatus("⚠ Spreadsheet engine not found — Export/Import disabled.", "err");
/* ---- Deckhand: collapsible sections (click legend) ---- */
(function () {
  var legends = document.querySelectorAll('fieldset > legend');
  for (var i = 0; i < legends.length; i++) {
    legends[i].addEventListener('click', function () {
      // A drag just finished on this legend — swallow the click so the
      // section doesn't collapse as a side effect of being reordered.
      if (this.getAttribute('data-dragged') === '1') {
        this.removeAttribute('data-dragged');
        return;
      }
      this.parentNode.classList.toggle('collapsed');
    });
  }
})();

/* ---- Deckhand: manually sortable sections (drag a section title) ----
   Applies to the Resources and Edit pages. Order persists per page in
   localStorage, keyed by the section's legend text. */
(function () {
  var PAGES = ["page-resources", "page-edit"];
  var secDragEl = null;

  function secKey(pageId) { return "dh_secOrder_" + pageId; }

  function secLabel(fs) {
    var lg = null, kids = fs.childNodes, i;
    for (i = 0; i < kids.length; i++) {
      if (kids[i].nodeName && String(kids[i].nodeName).toLowerCase() === "legend") { lg = kids[i]; break; }
    }
    if (!lg) return "";
    var txt = "", n = lg.childNodes;
    for (i = 0; i < n.length; i++) {
      if (n[i].nodeType === 3) txt += n[i].nodeValue;   // text nodes only — skips the "+" button
    }
    return txt.replace(/^\s+|\s+$/g, "");
  }

  function secFieldsets(wrap) {
    var out = [], kids = wrap.children;
    for (var i = 0; i < kids.length; i++) {
      if (String(kids[i].nodeName).toLowerCase() === "fieldset") out.push(kids[i]);
    }
    return out;
  }

  function secSaveOrder(pageId, wrap) {
    var fs = secFieldsets(wrap), ids = [];
    for (var i = 0; i < fs.length; i++) {
      var id = fs[i].getAttribute("data-secid");
      if (id) ids.push(id);
    }
    try { window.localStorage.setItem(secKey(pageId), JSON.stringify(ids)); } catch (e) {}
  }

  function secApplyOrder(pageId, wrap) {
    var raw = null, saved = null;
    try { raw = window.localStorage.getItem(secKey(pageId)); } catch (e) {}
    if (!raw) return;
    try { saved = JSON.parse(raw); } catch (e2) { return; }
    if (!saved || !saved.length) return;

    // Snapshot the source order BEFORE any reordering, so sections missing from
    // the saved list (e.g. a category added in a later build) can be slotted back
    // in at their authored position instead of being dumped at the end.
    var fs = secFieldsets(wrap), byId = {}, srcIdx = {}, i;
    for (i = 0; i < fs.length; i++) {
      var sid0 = fs[i].getAttribute("data-secid");
      byId[sid0] = fs[i];
      srcIdx[sid0] = i;
    }

    // Build the final order: walk the saved list, but before each saved section
    // emit any unsaved section whose source position precedes it and hasn't been
    // placed yet. Leftover unsaved sections go at the end, in source order.
    var placed = {}, order = [];
    function isSaved(id) { for (var k = 0; k < saved.length; k++) if (String(saved[k]) === id) return true; return false; }

    for (i = 0; i < saved.length; i++) {
      var savedId = String(saved[i]);
      if (!byId[savedId]) continue;                 // saved section no longer exists
      var savedSrc = srcIdx[savedId];
      // Emit unsaved sections authored before this saved one.
      for (var s = 0; s < fs.length; s++) {
        var uid = fs[s].getAttribute("data-secid");
        if (placed[uid] || isSaved(uid)) continue;
        if (srcIdx[uid] < savedSrc) { order.push(uid); placed[uid] = true; }
      }
      order.push(savedId); placed[savedId] = true;
    }
    // Any remaining unsaved sections, in source order.
    for (i = 0; i < fs.length; i++) {
      var rid = fs[i].getAttribute("data-secid");
      if (!placed[rid]) { order.push(rid); placed[rid] = true; }
    }

    var anchor = fs.length ? fs[fs.length - 1].nextSibling : null;
    for (i = 0; i < order.length; i++) {
      var el = byId[order[i]];
      if (el) wrap.insertBefore(el, anchor);
    }
  }

  function secInit(pageId) {
    var page = $(pageId);
    if (!page) return;
    var wrap = page.getElementsByTagName("div")[0];
    while (wrap && String(wrap.className).indexOf("wrap") === -1) wrap = wrap.nextSibling;
    if (!wrap) return;

    var fs = secFieldsets(wrap), i;
    for (i = 0; i < fs.length; i++) {
      (function (sec) {
        var lg = sec.getElementsByTagName("legend")[0];
        if (!lg) return;
        sec.setAttribute("data-secid", secLabel(sec) || ("sec" + i));
        lg.className = (lg.className ? lg.className + " " : "") + "sec-drag";
        lg.setAttribute("draggable", "true");

        lg.ondragstart = function (ev) {
          secDragEl = sec;
          sec.className = (sec.className ? sec.className + " " : "") + "sec-dragging";
          try { ev.dataTransfer.effectAllowed = "move"; ev.dataTransfer.setData("text/plain", sec.getAttribute("data-secid")); } catch (e) {}
          try { ev.dataTransfer.setDragImage(sec, 24, 14); } catch (e2) {}
        };
        lg.ondragend = function () {
          secDragEl = null;
          sec.className = String(sec.className).replace(/\s*sec-dragging/, "");
          lg.setAttribute("data-dragged", "1");   // suppress the trailing collapse click
          secSaveOrder(pageId, wrap);
        };
      })(fs[i]);
    }

    wrap.ondragover = function (ev) {
      if (!secDragEl) return;
      if (ev.preventDefault) ev.preventDefault();
      try { ev.dataTransfer.dropEffect = "move"; } catch (e) {}
      var t = ev.target;
      while (t && t !== wrap && String(t.nodeName).toLowerCase() !== "fieldset") t = t.parentNode;
      if (!t || t === wrap || t === secDragEl) return;
      if (t.parentNode !== wrap) return;   // ignore nested fieldsets (e.g. Deliver segments)
      var rect = t.getBoundingClientRect();
      var before = (ev.clientY - rect.top) < rect.height / 2;
      if (before) wrap.insertBefore(secDragEl, t);
      else wrap.insertBefore(secDragEl, t.nextSibling);
    };
    wrap.ondrop = function (ev) {
      if (ev.preventDefault) ev.preventDefault();
      secSaveOrder(pageId, wrap);
    };

    secApplyOrder(pageId, wrap);
  }

  for (var p = 0; p < PAGES.length; p++) secInit(PAGES[p]);
})();

/* ---- Deckhand: float open dropdowns above all glass panels ----
   Glass sections (backdrop-filter) create stacking/containing contexts that
   clip .dd-list. On open, reparent the list to <body> as position:fixed,
   anchored to its toggle; restore it on close. No existing handlers change —
   listeners travel with the node. */
(function () {
  var dds = document.querySelectorAll(".dd");
  function floatList(dd) {
    var list = dd.querySelector(".dd-list");
    var toggle = dd.querySelector(".dd-toggle");
    if (!list || !toggle || list._floating) return;
    var r = toggle.getBoundingClientRect();
    list._home = dd;
    list._floating = true;
    list.classList.add("dd-float");
    list.style.left = r.left + "px";
    list.style.top = (r.bottom + 4) + "px";
    list.style.width = r.width + "px";
    var room = window.innerHeight - r.bottom - 12;
    list.style.maxHeight = Math.max(80, Math.min(280, room)) + "px";
    document.body.appendChild(list);
  }
  function unfloatList(dd) {
    var list = document.querySelector(".dd-list.dd-float");
    if (!list || list._home !== dd) return;
    list.classList.remove("dd-float");
    list.style.left = list.style.top = list.style.width = list.style.maxHeight = "";
    list._floating = false;
    dd.appendChild(list);
    list._home = null;
  }
  function watch(dd) {
    var obs = new MutationObserver(function () {
      if (dd.classList.contains("open")) floatList(dd);
      else unfloatList(dd);
    });
    obs.observe(dd, { attributes: true, attributeFilter: ["class"] });
  }
  for (var i = 0; i < dds.length; i++) watch(dds[i]);
  window.__ddWatch = watch;
  window.addEventListener("resize", function () {
    var open = document.querySelector(".dd.open");
    if (open) { unfloatList(open); floatList(open); }
  });
})();

/* ---- Deckhand: unified top bar (back + title + sub inline with page nav) ---- */
(function () {
  var pages = document.querySelectorAll(".page .wrap");
  for (var i = 0; i < pages.length; i++) {
    var wrap = pages[i];
    var pn = wrap.querySelector(".pagenav");
    var nav = wrap.querySelector(".nav");
    if (!pn || !nav) continue;
    var sub = nav.nextElementSibling;
    if (sub && (" " + sub.className + " ").indexOf(" sub ") === -1) sub = null;
    var bar = document.createElement("div");
    bar.className = "topbar";
    var left = document.createElement("div");
    left.className = "topbar-left";
    wrap.insertBefore(bar, wrap.firstChild);
    left.appendChild(nav);
    if (sub) left.appendChild(sub);
    bar.appendChild(left);
    bar.appendChild(pn);
  }
})();

/* ---- Deckhand: style native <select>s to read like the glass dropdowns ----
   IMPORTANT: the previous approach hid each <select> behind a mirror element and
   drove it via selectedIndex + synthetic change events. That corrupted the preset
   value plumbing (fillSelect/browseIntoEl set sel.value directly, prep/deliver read
   sel.value), so XML/EDL/video stopped exporting. This version leaves every real
   <select> in place and untouched — CSS alone gives it the matching glass look. */
(function () {
  var sels = document.querySelectorAll("select");
  for (var i = 0; i < sels.length; i++) {
    if (sels[i].className.indexOf("dd-styled") === -1) sels[i].className += " dd-styled";
  }
})();

/* ---- Resources: user-managed link rows ----
   Mirrors the Edit > Effects pattern: a "+" button on each category legend adds
   a link, the drag handle rearranges, and click-and-hold arms a row for removal.
   Defaults are hidden (restorable) rather than deleted; custom links are dropped
   from the saved list. Storage: dh_resCustom / dh_resHidden / dh_resOrder_<cat>. */
(function () {
  var RES_CUSTOM_KEY = "dh_resCustom";
  var RES_HIDE_KEY   = "dh_resHidden";
  var RES_ORD_PREFIX = "dh_resOrder_";
  var resModalCat = "";

  var RES_DEFAULTS = [
    { cat: "AI", links: [
      { name: "Runway", url: "https://runwayml.com", host: "runwayml.com" },
      { name: "ElevenLabs", url: "https://elevenlabs.io/", host: "elevenlabs.io" },
      { name: "LALAL.AI", url: "https://www.lalal.ai", host: "lalal.ai" },
      { name: "Topaz Labs", url: "https://www.topazlabs.com/", host: "topazlabs.com" }
    ]},
    { cat: "Stock Imagery", links: [
      { name: "Getty Images", url: "https://www.gettyimages.com", host: "gettyimages.com" },
      { name: "Shutterstock", url: "https://www.shutterstock.com/", host: "shutterstock.com" },
      { name: "Filmsupply", url: "https://www.filmsupply.com", host: "filmsupply.com" },
      { name: "Stocksy", url: "https://www.stocksy.com", host: "stocksy.com" },
      { name: "Pexels", url: "https://www.pexels.com/", host: "pexels.com" },
      { name: "RAW.film", url: "https://raw.film/", host: "raw.film" }
    ]},
    { cat: "Stock Music", links: [
      { name: "Asche & Spencer", url: "https://www.ascheandspencer.com", host: "ascheandspencer.com" },
      { name: "APM Music", url: "https://www.apmmusic.com/", host: "apmmusic.com" },
      { name: "Megatrax", url: "https://www.megatrax.com", host: "megatrax.com" },
      { name: "Marmoset", url: "https://www.marmosetmusic.com", host: "marmosetmusic.com" },
      { name: "Extreme Music", url: "https://www.extrememusic.com/", host: "extrememusic.com" },
      { name: "License Lab", url: "https://licenselab.com/", host: "licenselab.com" },
      { name: "Epidemic Sound", url: "https://www.epidemicsound.com", host: "epidemicsound.com" },
      { name: "PremiumBeat", url: "https://www.premiumbeat.com", host: "premiumbeat.com" }
    ]}
  ];

  function resDefaultsFor(cat) {
    for (var i = 0; i < RES_DEFAULTS.length; i++) if (RES_DEFAULTS[i].cat === cat) return RES_DEFAULTS[i].links;
    return [];
  }
  function resCustomAll() { var o = lsGetJSON(RES_CUSTOM_KEY); return o ? o : {}; }
  function resCustomFor(cat) { var o = resCustomAll(); var a = o[cat]; return (a && a.length) ? a : []; }
  function resCustomSet(cat, list) { var o = resCustomAll(); o[cat] = list; lsSetJSON(RES_CUSTOM_KEY, o); }
  function resHiddenLoad() { var a = lsGetJSON(RES_HIDE_KEY); return (a && a.length) ? a : []; }
  function resHiddenSave(list) { lsSetJSON(RES_HIDE_KEY, list); }
  function resId(cat, url) { return cat + "::" + url; }
  function resIsHidden(id) {
    var h = resHiddenLoad();
    for (var i = 0; i < h.length; i++) if (h[i] === id) return true;
    return false;
  }
  function resHide(id) {
    var h = resHiddenLoad();
    for (var i = 0; i < h.length; i++) if (h[i] === id) return;
    h.push(id);
    resHiddenSave(h);
  }
  function resUnhide(id) {
    var h = resHiddenLoad(), keep = [], found = false;
    for (var i = 0; i < h.length; i++) {
      if (h[i] === id) { found = true; continue; }
      keep.push(h[i]);
    }
    if (found) resHiddenSave(keep);
  }

  /* Normalize whatever the user typed into a fetchable URL + a favicon host. */
  function resNormalizeUrl(raw) {
    var u = String(raw || "").replace(/^\s+|\s+$/g, "");
    if (!u) return "";
    if (!/^https?:\/\//i.test(u)) u = "https://" + u;
    return u;
  }
  function resHostOf(url) {
    var m = String(url || "").match(/^https?:\/\/([^\/\?#]+)/i);
    if (!m) return "";
    return String(m[1]).replace(/^www\./i, "");
  }

  function resAllUnits(cat) {
    var units = [], defs = resDefaultsFor(cat), i;
    for (i = 0; i < defs.length; i++) {
      units.push({ id: resId(cat, defs[i].url), name: defs[i].name, url: defs[i].url, host: defs[i].host, custom: false });
    }
    var cus = resCustomFor(cat);
    for (i = 0; i < cus.length; i++) {
      if (!cus[i] || !cus[i].url) continue;
      units.push({ id: resId(cat, cus[i].url), name: cus[i].name || cus[i].url, url: cus[i].url,
                   host: cus[i].host || resHostOf(cus[i].url), custom: true });
    }
    return units;
  }

  /* Saved order first (still-valid ids), then anything new appended. */
  function resUnitList(cat) {
    var units = resAllUnits(cat), byId = {}, visible = [], i;
    for (i = 0; i < units.length; i++) {
      byId[units[i].id] = units[i];
      if (!resIsHidden(units[i].id)) visible.push(units[i]);
    }
    var saved = lsGetJSON(RES_ORD_PREFIX + cat);
    if (!saved || !saved.length) return visible;

    var ordered = [], seen = {};
    for (i = 0; i < saved.length; i++) {
      var id = String(saved[i]);
      if (byId[id] && !seen[id] && !resIsHidden(id)) { ordered.push(byId[id]); seen[id] = true; }
    }
    for (i = 0; i < visible.length; i++) if (!seen[visible[i].id]) ordered.push(visible[i]);
    return ordered;
  }

  function resBox(cat) {
    var boxes = document.querySelectorAll(".reslinks");
    for (var i = 0; i < boxes.length; i++) {
      if (boxes[i].getAttribute("data-rescat") === cat) return boxes[i];
    }
    return null;
  }
  function resSaveOrderFromDOM(cat) {
    var box = resBox(cat);
    if (!box) return;
    var ids = [], kids = box.children;
    for (var i = 0; i < kids.length; i++) {
      var id = kids[i].getAttribute ? kids[i].getAttribute("data-resid") : null;
      if (id) ids.push(id);
    }
    lsSetJSON(RES_ORD_PREFIX + cat, ids);
  }

  function openExternal(url) {
    try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) {}
    try { if (cs && cs.openURLInDefaultBrowser) { cs.openURLInDefaultBrowser(url); return; } } catch (e2) {}
    try { window.open(url, "_blank"); } catch (e3) {}
  }

  var resDragEl = null, resDragCat = "", resHoldTimer = null;
  function resClearHold() { if (resHoldTimer) { window.clearTimeout(resHoldTimer); resHoldTimer = null; } }
  function resDisarmAll() {
    var rows = document.querySelectorAll(".res-item");
    for (var i = 0; i < rows.length; i++) {
      if (String(rows[i].className).indexOf("armed") !== -1) rows[i].className = "res-item";
    }
  }
  document.addEventListener("mousedown", function (ev) {
    var t = ev.target;
    while (t && t !== document) {
      if (t.className && String(t.className).indexOf("res-item") !== -1) return;
      t = t.parentNode;
    }
    resDisarmAll();
  }, true);

  function resRender(cat) {
    var box = resBox(cat);
    if (!box) return;
    box.innerHTML = "";
    var units = resUnitList(cat), i;
    for (i = 0; i < units.length; i++) {
      (function (u) {
        var row = document.createElement("div");
        row.className = "res-item";
        row.setAttribute("data-resid", u.id);

        var grip = document.createElement("span");
        grip.className = "res-grip";
        grip.title = "Drag to rearrange \u00B7 click and hold to remove";
        grip.appendChild(document.createTextNode("\u283F"));
        grip.setAttribute("draggable", "true");
        grip.ondragstart = function (ev) {
          resClearHold();
          resDisarmAll();
          resDragEl = row;
          resDragCat = cat;
          row.className = "res-item dragging";
          try { ev.dataTransfer.effectAllowed = "move"; ev.dataTransfer.setData("text/plain", u.id); } catch (e) {}
          try { ev.dataTransfer.setDragImage(row, 20, 14); } catch (e2) {}
        };
        grip.ondragend = function () {
          resDragEl = null;
          row.className = "res-item";
          resSaveOrderFromDOM(cat);
        };
        grip.onmousedown = function (ev) {
          if (ev && ev.stopPropagation) ev.stopPropagation();
          resClearHold();
          resHoldTimer = window.setTimeout(function () {
            resHoldTimer = null;
            resDisarmAll();
            row.className = "res-item armed";
          }, 450);
        };
        grip.onmouseup = resClearHold;
        grip.onmouseleave = resClearHold;
        row.appendChild(grip);

        var a = document.createElement("a");
        a.className = "reslink";
        a.href = u.url;
        a.setAttribute("data-host", u.host || "");
        a.title = u.url;

        var ico = document.createElement("span");
        ico.className = "reslink-ico";
        a.appendChild(ico);
        var nm = document.createElement("span");
        nm.className = "reslink-name";
        nm.appendChild(document.createTextNode(u.name));
        a.appendChild(nm);

        if (u.host) {
          var img = document.createElement("img");
          img.alt = "";
          img.src = "https://www.google.com/s2/favicons?sz=64&domain=" + u.host;
          img.onerror = function () {
            ico.innerHTML = "";
            ico.appendChild(document.createTextNode(String(u.name || "?").charAt(0).toUpperCase()));
            ico.className = "reslink-ico mono";
          };
          ico.appendChild(img);
        } else {
          ico.appendChild(document.createTextNode(String(u.name || "?").charAt(0).toUpperCase()));
          ico.className = "reslink-ico mono";
        }

        a.onclick = function (ev) {
          if (ev && ev.preventDefault) ev.preventDefault();
          if (String(row.className).indexOf("armed") !== -1) {
            if (ev && ev.stopPropagation) ev.stopPropagation();
            if (u.custom) {
              var cur = resCustomFor(cat), out = [];
              for (var j = 0; j < cur.length; j++) if (cur[j] && cur[j].url !== u.url) out.push(cur[j]);
              resCustomSet(cat, out);
            } else {
              resHide(u.id);
            }
            resRender(cat);
            resSaveOrderFromDOM(cat);
            return false;
          }
          openExternal(u.url);
          return false;
        };
        row.appendChild(a);
        box.appendChild(row);
      })(units[i]);
    }

    if (!units.length) {
      var em = document.createElement("div");
      em.className = "res-empty";
      em.appendChild(document.createTextNode("No links yet \u2014 use + to add one."));
      box.appendChild(em);
    }
    resRenderRestore(cat);
  }

  /* One-click restore for removed defaults in this category. */
  function resRenderRestore(cat) {
    var box = resBox(cat);
    if (!box) return;
    var defs = resDefaultsFor(cat), hiddenIds = [], i;
    for (i = 0; i < defs.length; i++) {
      var id = resId(cat, defs[i].url);
      if (resIsHidden(id)) hiddenIds.push(id);
    }
    if (!hiddenIds.length) return;
    var link = document.createElement("button");
    link.type = "button";
    link.className = "res-restore";
    link.appendChild(document.createTextNode("Restore " + hiddenIds.length + " removed default link(s)"));
    link.onclick = function () {
      for (var k = 0; k < hiddenIds.length; k++) resUnhide(hiddenIds[k]);
      resRender(cat);
      resSaveOrderFromDOM(cat);
    };
    box.appendChild(link);
  }

  /* Container-level drag routing, scoped to the category being dragged. */
  function resWireDrag(cat) {
    var box = resBox(cat);
    if (!box) return;
    box.ondragover = function (ev) {
      if (!resDragEl || resDragCat !== cat) return;
      if (ev.preventDefault) ev.preventDefault();
      try { ev.dataTransfer.dropEffect = "move"; } catch (e) {}
      var t = ev.target;
      while (t && t !== box && !(t.getAttribute && t.getAttribute("data-resid"))) t = t.parentNode;
      if (!t || t === box || t === resDragEl) return;
      var rect = t.getBoundingClientRect();
      var before = (ev.clientY - rect.top) < rect.height / 2 ||
                   ((ev.clientY - rect.top) < rect.height && (ev.clientX - rect.left) < rect.width / 2);
      if (before) box.insertBefore(resDragEl, t);
      else box.insertBefore(resDragEl, t.nextSibling);
    };
    box.ondrop = function (ev) {
      if (ev.preventDefault) ev.preventDefault();
      resSaveOrderFromDOM(cat);
    };
  }

  /* ---- Add-link modal ---- */
  function resModalShow(cat) {
    resModalCat = cat;
    var t = $("resModalTitle");
    if (t) { t.innerHTML = ""; t.appendChild(document.createTextNode("Add Link \u2014 " + cat)); }
    $("resName").value = "";
    $("resUrl").value = "";
    var er = $("resErr");
    if (er) er.style.display = "none";
    $("resModal").style.display = "flex";
    try { $("resName").focus(); } catch (e) {}
  }
  function resModalHide() { $("resModal").style.display = "none"; }
  function resModalErr(msg) {
    var er = $("resErr");
    if (!er) return;
    er.innerHTML = "";
    er.appendChild(document.createTextNode(msg));
    er.style.display = "block";
  }
  function resModalCommit() {
    var cat = resModalCat;
    if (!cat) return;
    var name = String($("resName").value || "").replace(/^\s+|\s+$/g, "");
    var url = resNormalizeUrl($("resUrl").value);
    if (!url) { resModalErr("Enter a URL."); return; }
    var host = resHostOf(url);
    if (!host) { resModalErr("That URL doesn't look valid."); return; }
    if (!name) name = host;

    var id = resId(cat, url);
    resUnhide(id);   // clear any stale hidden entry so a re-add can come back

    var defs = resDefaultsFor(cat), i;
    for (i = 0; i < defs.length; i++) {
      if (defs[i].url === url) { resRender(cat); resSaveOrderFromDOM(cat); resModalHide(); return; }
    }
    var cur = resCustomFor(cat), dup = false;
    for (i = 0; i < cur.length; i++) if (cur[i] && cur[i].url === url) { dup = true; break; }
    if (!dup) {
      cur.push({ name: name, url: url, host: host });
      resCustomSet(cat, cur);
    }
    resRender(cat);
    resSaveOrderFromDOM(cat);
    resModalHide();
  }

  (function () {
    var adds = document.querySelectorAll(".legend-add");
    for (var i = 0; i < adds.length; i++) {
      (function (btn) {
        var cat = btn.getAttribute("data-rescat");
        if (!cat) return;
        btn.onclick = function (ev) {
          if (ev && ev.stopPropagation) ev.stopPropagation();
          resModalShow(cat);
        };
      })(adds[i]);
    }
  })();

  if ($("resModalClose")) $("resModalClose").onclick = resModalHide;
  if ($("resModal")) $("resModal").onclick = function (ev) { if (ev && ev.target === this) resModalHide(); };
  if ($("resAddGo")) $("resAddGo").onclick = resModalCommit;
  if ($("resUrl")) $("resUrl").onkeydown = function (ev) { if (ev && ev.keyCode === 13) resModalCommit(); };
  if ($("resName")) $("resName").onkeydown = function (ev) { if (ev && ev.keyCode === 13) { try { $("resUrl").focus(); } catch (e) {} } };

  for (var c = 0; c < RES_DEFAULTS.length; c++) {
    resRender(RES_DEFAULTS[c].cat);
    resWireDrag(RES_DEFAULTS[c].cat);
  }
})();

/* ---- Deckhand: update check (GitHub Releases) ----
   Runs on panel launch. Shows a glass banner when a newer build is published.
   The Developer page gets a live status line plus a Check now button. */
(function () {
  var UPD_LAST = "deckhand.upd.lastCheck";

  function fmtWhen(ms) {
    if (!ms) return "never";
    var d = new Date(ms);
    var h = d.getHours(), m = d.getMinutes(), ap = h >= 12 ? "PM" : "AM";
    h = h % 12; if (h === 0) h = 12;
    if (m < 10) m = "0" + m;
    return (d.getMonth() + 1) + "/" + d.getDate() + " " + h + ":" + m + " " + ap;
  }

  function setDevStatus(txt) {
    var el = $("updStatus");
    if (el) el.textContent = txt;
  }

  function statusLine(res) {
    var local = res.local || "?";
    var when = " · checked " + fmtWhen(lsGetNum(UPD_LAST));
    if (res.status === "update") return "v" + local + " installed — v" + res.version + " available" + when;
    if (res.status === "current") return "v" + local + " — up to date" + when;
    if (res.status === "offline") return "v" + local + " — could not reach GitHub" + when;
    return "v" + local + " — update check failed" + when;
  }

  function lsGetNum(k) {
    try { return parseInt(window.localStorage.getItem(k), 10) || 0; } catch (e) { return 0; }
  }
  function lsSetNum(k, v) {
    try { window.localStorage.setItem(k, String(v)); } catch (e) {}
  }

  function removeBanner() {
    var old = document.querySelector(".upd-banner");
    if (old && old.parentNode) old.parentNode.removeChild(old);
  }

  function showBanner(res) {
    removeBanner();
    var bar = document.createElement("div");
    bar.className = "upd-banner";

    var txt = document.createElement("div");
    txt.className = "upd-txt";
    var t = document.createElement("div");
    t.className = "upd-title";
    t.textContent = "STN - AE Helper " + res.version + " is available";
    txt.appendChild(t);
    if (res.notes) {
      var n = document.createElement("div");
      n.className = "upd-notes";
      n.textContent = res.notes;
      txt.appendChild(n);
    }

    var later = document.createElement("button");
    later.textContent = "Later";
    later.addEventListener("click", function () { removeBanner(); });

    var go = document.createElement("button");
    go.className = "primary";
    go.textContent = "Update";
    go.addEventListener("click", function () {
      bar.className = "upd-banner busy";
      t.textContent = "Downloading " + res.version + "\u2026";
      DeckhandUpdater.applyUpdate(res.version, function (err, info) {
        bar.className = "upd-banner";
        if (err) {
          t.textContent = "Update failed \u2014 " + err.message;
          go.textContent = "Retry";
          devLog("Update failed: " + err.message, "bad");
          return;
        }
        t.textContent = "Updated to " + res.version + " \u2014 close and reopen the panel";
        devLog("Updated to " + res.version + " at " + ((info && info.root) || "?"));
        var nn = bar.querySelector(".upd-notes");
        if (nn) nn.parentNode.removeChild(nn);
        if (go.parentNode) go.parentNode.removeChild(go);

        /* The new version is on disk, but CEP only loads it on a fresh panel
           launch — so offer to close Deckhand outright rather than just hide
           the banner. Reopening from the Extensions menu picks up the update. */
        later.textContent = "Close STN - AE Helper";
        later.className = "primary";
        later.title = "Closes the panel so it reloads with the new version when you reopen it";
        // Swap the earlier "Later" handler (removeBanner) for one that closes.
        var freshLater = later.cloneNode(true);
        later.parentNode.replaceChild(freshLater, later);
        freshLater.addEventListener("click", function () {
          try {
            cs.closeExtension();
          } catch (eC) {
            /* Some host/OS combinations refuse programmatic close; fall back to
               dismissing the banner so the button is never a dead end. */
            removeBanner();
            setDevStatus("Close STN - AE Helper manually to load v" + res.version + ".");
          }
        });

        setDevStatus("Updated to v" + res.version + " \u2014 reopen the panel");
      });
    });

    bar.appendChild(txt);
    bar.appendChild(later);
    bar.appendChild(go);
    document.body.appendChild(bar);
  }

  // Paint the home-screen version label red while an update is sitting on
  // GitHub, cleared once the check comes back current.
  function markVerUpdate(on) {
    var el = $("deckhandVersion");
    if (!el) return;
    el.className = el.className.replace(/ ?ver-update/g, "");
    if (on) el.className = (el.className ? el.className + " " : "") + "ver-update";
  }

  function runCheck(announce) {
    if (typeof DeckhandUpdater === "undefined") {
      setDevStatus("Updater unavailable \u2014 Node.js not enabled");
      return;
    }
    setDevStatus("Checking\u2026");
    DeckhandUpdater.checkForUpdate(function (res) {
      lsSetNum(UPD_LAST, new Date().getTime());
      setDevStatus(statusLine(res));
      if (res.status === "update") { markVerUpdate(true); showBanner(res); }
      else {
        if (res.status === "current") markVerUpdate(false);
        if (announce) devLog(statusLine(res));
      }
    });
  }

  // Header version label reads version.json, so it can never drift from the
  // build. It also doubles as a manual update check — clicking it pings GitHub
  // without needing the Developer page, so a full re-check is one tap from the
  // home screen.
  (function () {
    var el = $("deckhandVersion");
    if (!el) return;
    if (typeof DeckhandUpdater !== "undefined") {
      try { el.textContent = "v" + DeckhandUpdater.getLocalVersion(); } catch (e) {}
    }

    el.className = (el.className ? el.className + " " : "") + "ver-check";
    el.title = "Click to check for updates";

    var checking = false;
    el.addEventListener("click", function () {
      if (checking) return;
      if (typeof DeckhandUpdater === "undefined") {
        flashVer("Node.js off");
        return;
      }
      checking = true;
      var base = "v" + (function () {
        try { return DeckhandUpdater.getLocalVersion(); } catch (e) { return "?"; }
      })();
      el.textContent = "checking\u2026";
      el.className = el.className.replace(/ ver-flash/g, "") + " ver-busy";

      DeckhandUpdater.checkForUpdate(function (res) {
        lsSetNum(UPD_LAST, new Date().getTime());
        setDevStatus(statusLine(res));
        el.className = el.className.replace(/ ver-busy/g, "");
        checking = false;

        if (res.status === "update") {
          markVerUpdate(true);
          el.textContent = "v" + res.version + " ready";
          showBanner(res);
        } else if (res.status === "current") {
          markVerUpdate(false);
          flashVer("up to date");
          window.setTimeout(function () { el.textContent = base; }, 1600);
        } else {
          flashVer("check failed");
          window.setTimeout(function () { el.textContent = base; }, 1600);
        }
      });
    });

    function flashVer(msg) {
      el.textContent = msg;
      el.className = el.className.replace(/ ver-flash/g, "") + " ver-flash";
      window.setTimeout(function () {
        el.className = el.className.replace(/ ver-flash/g, "");
      }, 1600);
    }
  })();

  // Surface the folder the updater is writing to \u2014 first thing to check if an
  // update reports success but nothing changes.
  (function () {
    var el = $("updStatus");
    if (!el || typeof DeckhandUpdater === "undefined") return;
    try { el.title = "Extension folder: " + DeckhandUpdater.getExtensionRoot(); } catch (e) {}
  })();

  var btn = $("updCheck");
  if (btn) btn.addEventListener("click", function () { runCheck(true); });

  // Initial check, delayed so it never competes with panel startup work.
  window.setTimeout(function () { runCheck(false); }, 1500);
})();

/* ====================== VOICE OVER (ElevenLabs) ======================
   Network + disk work lives in vo.js (Node side). This block is UI only:
   it gathers settings, hands DeckhandVO a job, and passes the finished file
   path to the host for import and placement. Nothing here ever holds audio
   bytes longer than the write, and nothing about the key leaves the panel. */
(function voSection() {
  if (!$("voGen")) return;   // fieldset absent — nothing to wire

  var voVoices = [];
  var voTakes = [];
  var voBusy = false;
  var voCtx = null;   // { projectDir, projectName, audioTracks, playhead }

  function vlog(m, c) { logTo("editLog", m, c); }

  function setKeyHint(msg, cls) {
    var el = $("voKeyHint");
    if (!el) return;
    el.className = "hint" + (cls ? " " + cls : "");
    el.textContent = msg;
  }

  /* ---- office TLS interception: ElevenLabs unreachable behind the MITM proxy ---- */
  function isBlockedErr(e) {
    var m = String(e || "");
    return /self[- ]signed certificate/i.test(m) ||
           /unable to verify the first certificate/i.test(m) ||
           /UNABLE_TO_GET_ISSUER_CERT/i.test(m) ||
           /CERT_/i.test(m);
  }
  var voAutoCollapsed = false;
  function setVOBlocked(on) {
    var fs = $("fsVO");
    if (!fs) return;
    var has = fs.classList.contains("vo-blocked");
    if (on && !has) {
      fs.classList.add("vo-blocked");
      // Fold the section down to its title so a dead tool stops eating the page.
      if (!fs.classList.contains("collapsed")) {
        fs.classList.add("collapsed");
        voAutoCollapsed = true;
      }
    } else if (!on && has) {
      fs.classList.remove("vo-blocked");
      // Only reopen what we closed \u2014 leave a hand-collapsed section alone.
      if (voAutoCollapsed) { fs.classList.remove("collapsed"); voAutoCollapsed = false; }
    }
  }

  function syncEngine() {
    var fsv = $("fsVO");
    if (fsv) { if (DeckhandVO.engine() === "mac") fsv.classList.add("vo-mac"); else fsv.classList.remove("vo-mac"); }
  }

  var KEY_HINT_DEFAULT =
    "Optional — with no key, Voice Over uses the Mac's built-in voices. Stored on this Mac only.";

  /* ---- Node gate: without --enable-nodejs there is no TLS, so no ElevenLabs ---- */
  if (typeof DeckhandVO === "undefined" || !DeckhandVO.nodeAvailable()) {
    $("voGen").disabled = true;
    $("voGenOnly").disabled = true;
    $("voRefresh").disabled = true;
    $("voKeySave").disabled = true;
    setKeyHint("Node.js is not enabled for this panel — Voice Over is unavailable. Restart Premiere; if it persists, reinstall STN - AE Helper.", "err");
    return;
  }

  /* ---------- settings persistence ---------- */
  function readUI() {
    return {
      voiceId: $("voDDToggle").getAttribute("data-vid") || "",
      model: $("voModel").value,
      format: $("voFormat").value,
      stability: parseFloat($("voStability").value),
      similarity: parseFloat($("voSimilarity").value),
      style: parseFloat($("voStyle").value),
      speed: parseFloat($("voSpeed").value),
      track: parseInt($("voTrack").value, 10)
    };
  }
  function saveUI() { DeckhandVO.setSettings(readUI()); }

  function applySettings(s) {
    $("voModel").value = s.model || "eleven_multilingual_v2";
    $("voFormat").value = s.format || "wav";
    $("voStability").value = s.stability;
    $("voSimilarity").value = s.similarity;
    $("voStyle").value = s.style;
    $("voSpeed").value = s.speed;
    syncSliders();
  }

  /* ---------- sliders ---------- */
  function syncSliders() {
    $("voStabilityV").textContent  = parseFloat($("voStability").value).toFixed(2);
    $("voSimilarityV").textContent = parseFloat($("voSimilarity").value).toFixed(2);
    $("voStyleV").textContent      = parseFloat($("voStyle").value).toFixed(2);
    $("voSpeedV").textContent      = parseFloat($("voSpeed").value).toFixed(2);
  }
  var slIds = ["voStability", "voSimilarity", "voStyle", "voSpeed"];
  for (var si = 0; si < slIds.length; si++) {
    $(slIds[si]).addEventListener("input", function () { syncSliders(); saveUI(); });
  }

  /* ---------- API key ---------- */
  (function initKey() {
    var k = DeckhandVO.getKey();
    if (k) {
      $("voKey").value = k;
      setKeyHint("Key saved. " + DeckhandVO.maskKey(k), "ok");
    } else {
      setKeyHint(KEY_HINT_DEFAULT);
    }
  })();

  $("voKeySave").onclick = function () {
    var k = ($("voKey").value || "").replace(/^\s+|\s+$/g, "");
    if (!k) { setKeyHint("Paste a key first.", "err"); return; }
    DeckhandVO.setKey(k);
    setKeyHint("Key saved. " + DeckhandVO.maskKey(k), "ok");
    voVoices = [];
    syncEngine();
    loadVoices(true);
  };

  $("voKeyShow").onclick = function () {
    var f = $("voKey");
    var showing = f.type === "text";
    f.type = showing ? "password" : "text";
    this.className = "vo-mini" + (showing ? "" : " on");
  };

  $("voKeyClear").onclick = function () {
    DeckhandVO.clearKey();
    $("voKey").value = "";
    $("voKey").type = "password";
    $("voKeyShow").className = "vo-mini";
    voVoices = [];
    DeckhandVO.setCachedVoices([]);
    $("voDDToggle").removeAttribute("data-vid");
    $("voDDList").innerHTML = "";
    setKeyHint("Key forgotten — back to Mac voices.");
    syncEngine();
    loadVoices(true);
  };

  $("voKey").addEventListener("keydown", function (e) {
    if (e.keyCode === 13 || e.key === "Enter") { e.preventDefault(); $("voKeySave").click(); }
  });

  /* ---------- voice picker ---------- */
  function voiceById(id) {
    for (var i = 0; i < voVoices.length; i++) if (voVoices[i].id === id) return voVoices[i];
    return null;
  }

  function voiceLabel(v) {
    var bits = [];
    if (v.gender) bits.push(v.gender);
    if (v.accent) bits.push(v.accent);
    if (v.use) bits.push(v.use);
    return bits.join(" · ");
  }

  function renderVoices(selectId) {
    var list = $("voDDList"), html = "", i, v;
    if (!voVoices.length) {
      list.innerHTML = '<div class="dd-item" data-vid="">— no voices loaded —</div>';
      return;
    }
    for (i = 0; i < voVoices.length; i++) {
      v = voVoices[i];
      html += '<div class="dd-item" data-vid="' + escapeHtml(v.id) + '">' +
              escapeHtml(v.name) +
              (voiceLabel(v) ? '<span class="vo-vmeta">' + escapeHtml(voiceLabel(v)) + "</span>" : "") +
              "</div>";
    }
    list.innerHTML = html;

    var want = selectId || DeckhandVO.getSettings().voiceId;
    var chosen = voiceById(want) || voVoices[0];
    if (chosen) {
      $("voDDToggle").textContent = chosen.name;
      $("voDDToggle").setAttribute("data-vid", chosen.id);
      saveUI();
    }
  }

  function loadVoices(announce) {
    var btn = $("voRefresh");
    btn.className = "vo-mini spin";
    btn.disabled = true;
    DeckhandVO.fetchVoices(function (err, list) {
      btn.className = "vo-mini";
      btn.disabled = false;
      if (err) {
        setVOBlocked(isBlockedErr(err));
        setKeyHint(err, "err");
        if (announce) vlog("✗ Voices: " + err, "err");
        return;
      }
      setVOBlocked(false);
      voVoices = list;
      renderVoices();
      setKeyHint(list.length + " voices loaded.", "ok");
      if (announce) vlog("✓ Loaded " + list.length + (DeckhandVO.engine() === "mac" ? " Mac" : " ElevenLabs") + " voices.", "ok");
    });
  }

  $("voRefresh").onclick = function () { loadVoices(true); };

  function ddOpen() { return $("voDD").classList.contains("open"); }

  function openDD() {
    if (ddOpen()) return;
    $("voDD").classList.add("open");
    if (!voVoices.length) loadVoices(false);
    highlight(indexOfId($("voDDToggle").getAttribute("data-vid")));
  }
  function closeDD() {
    $("voDD").classList.remove("open");
    jumpBuf = "";
    $("voDDToggle").focus();
  }

  $("voDDToggle").onclick = function (e) {
    e.stopPropagation();
    if (ddOpen()) closeDD(); else openDD();
  };
  document.addEventListener("click", function () { $("voDD").classList.remove("open"); });
  $("voDDList").addEventListener("click", function (e) {
    var t = e.target;
    while (t && t !== this && (!t.className || t.className.indexOf("dd-item") === -1)) t = t.parentNode;
    if (!t || t === this) return;
    var vid = t.getAttribute("data-vid");
    if (!vid) return;
    chooseId(vid);
  });

  function chooseId(vid) {
    var v = voiceById(vid);
    $("voDDToggle").textContent = v ? v.name : "—";
    $("voDDToggle").setAttribute("data-vid", vid);
    closeDD();
    saveUI();
  }

  /* ---------- keyboard: type to jump ----------
     The open list is reparented to <body> by the float helper, so rows are
     addressed through the list's id rather than through the .dd wrapper.
     A short buffer means typing "gr" lands on Grace rather than jumping to
     G and then to R; it clears after a beat so the next keystroke starts a
     fresh search, which is how a native select behaves. */
  var jumpBuf = "";
  var jumpTimer = null;
  var hotIdx = -1;

  function rows() { return $("voDDList").querySelectorAll(".dd-item"); }

  function indexOfId(vid) {
    if (!vid) return -1;
    for (var i = 0; i < voVoices.length; i++) if (voVoices[i].id === vid) return i;
    return -1;
  }

  function highlight(i) {
    var r = rows(), k;
    for (k = 0; k < r.length; k++) r[k].className = "dd-item";
    hotIdx = -1;
    if (i < 0 || i >= r.length) return;
    hotIdx = i;
    r[i].className = "dd-item hot";
    /* scrollIntoView({block:"nearest"}) is unreliable inside the floated
       list, so the row is nudged into view by hand. */
    var list = $("voDDList");
    var top = r[i].offsetTop;
    var bottom = top + r[i].offsetHeight;
    if (top < list.scrollTop) list.scrollTop = top;
    else if (bottom > list.scrollTop + list.clientHeight)
      list.scrollTop = bottom - list.clientHeight;
  }

  /* First voice whose name begins with the buffer. Falls back to a substring
     match so typing "mor" still finds "Bill Morgan" when nothing starts with
     it — a plain prefix search feels broken on library voices with a first
     name in front. */
  function findMatch(buf) {
    var i, n;
    for (i = 0; i < voVoices.length; i++) {
      n = voVoices[i].name.toLowerCase();
      if (n.indexOf(buf) === 0) return i;
    }
    for (i = 0; i < voVoices.length; i++) {
      n = voVoices[i].name.toLowerCase();
      if (n.indexOf(buf) !== -1) return i;
    }
    return -1;
  }

  /* Repeating the same letter cycles through the voices starting with it,
     matching how a native pulldown behaves. */
  function cycleLetter(ch) {
    var start = hotIdx >= 0 ? hotIdx + 1 : 0;
    var i, k, n;
    for (k = 0; k < voVoices.length; k++) {
      i = (start + k) % voVoices.length;
      n = voVoices[i].name.toLowerCase();
      if (n.indexOf(ch) === 0) return i;
    }
    return -1;
  }

  function onKey(e) {
    if (!ddOpen() || !voVoices.length) return;
    var key = e.key;

    if (key === "Escape") { e.preventDefault(); closeDD(); return; }

    if (key === "Enter") {
      e.preventDefault();
      if (hotIdx >= 0 && voVoices[hotIdx]) chooseId(voVoices[hotIdx].id);
      return;
    }

    if (key === "ArrowDown" || key === "ArrowUp") {
      e.preventDefault();
      jumpBuf = "";
      var next = hotIdx + (key === "ArrowDown" ? 1 : -1);
      if (next < 0) next = 0;
      if (next >= voVoices.length) next = voVoices.length - 1;
      highlight(next);
      return;
    }

    if (key === "Home" || key === "End") {
      e.preventDefault();
      jumpBuf = "";
      highlight(key === "Home" ? 0 : voVoices.length - 1);
      return;
    }

    if (key === "Backspace") {
      e.preventDefault();
      jumpBuf = jumpBuf.slice(0, -1);
      if (jumpBuf) highlight(findMatch(jumpBuf));
      return;
    }

    /* Single printable characters only — modifier combos belong to Premiere. */
    if (!key || key.length !== 1 || e.ctrlKey || e.metaKey || e.altKey) return;

    e.preventDefault();
    var ch = key.toLowerCase();
    var idx;

    if (jumpBuf.length === 1 && jumpBuf === ch) {
      idx = cycleLetter(ch);
    } else {
      jumpBuf += ch;
      idx = findMatch(jumpBuf);
      if (idx < 0 && jumpBuf.length > 1) {
        /* The buffer no longer matches anything — treat this keystroke as the
           start of a new search rather than stranding the editor. */
        jumpBuf = ch;
        idx = findMatch(jumpBuf);
      }
    }
    if (idx >= 0) highlight(idx);

    if (jumpTimer) window.clearTimeout(jumpTimer);
    jumpTimer = window.setTimeout(function () { jumpBuf = ""; }, 900);
  }

  document.addEventListener("keydown", onKey, true);

  /* Opening from the keyboard, so the pulldown is reachable without a click. */
  $("voDDToggle").addEventListener("keydown", function (e) {
    if (ddOpen()) return;
    if (e.key === "Enter" || e.key === " " || e.key === "ArrowDown") {
      e.preventDefault();
      openDD();
    }
  });

  /* ---------- script box ---------- */
  function updateChars() {
    var n = DeckhandVO.charCount($("voScript").value);
    $("voChars").textContent = n + (n === 1 ? " character" : " characters") +
      (n > 4500 ? "  ⚠ long scripts may be truncated — split into takes" : "");
    $("voChars").className = "hint" + (n > 4500 ? " err" : "");
  }
  $("voScript").addEventListener("input", updateChars);
  updateChars();

  /* ---------- host context ---------- */
  function refreshCtx(cb) {
    host("DH_voContext", {}, function (r) {
      voCtx = (r && r.ok) ? r : null;
      if (voCtx) fillTracks(voCtx.audioTracks);
      if (cb) cb(voCtx);
    });
  }

  function fillTracks(n) {
    var sel = $("voTrack");
    var prev = sel.value;
    var html = '<option value="-1">first empty audio track</option>';
    for (var i = 0; i < n; i++) html += '<option value="' + i + '">A' + (i + 1) + "</option>";
    sel.innerHTML = html;
    sel.value = prev;
    if (!sel.value) sel.value = "-1";
  }
  $("voTrack").addEventListener("change", saveUI);
  $("voModel").addEventListener("change", saveUI);
  $("voFormat").addEventListener("change", saveUI);

  /* Refresh the track list whenever the Audio page comes forward — sequences
     change out from under the panel constantly.
     This used to watch page-edit, left over from when the VO tool lived on
     the Edit page: every visit to Edit fired DH_voContext, which resolved the
     VO folder and (before the resolver became read-only) created that day's
     MMDD folder as a side effect. */
  (function hookNav() {
    var navs = document.querySelectorAll('[data-goto="page-audio"]');
    for (var i = 0; i < navs.length; i++)
      navs[i].addEventListener("click", function () {
        window.setTimeout(function () { refreshCtx(null); }, 120);
      });
  })();

  /* ---------- takes list ---------- */
  function fmtDur(sec) {
    if (!sec) return "";
    var m = Math.floor(sec / 60), s = sec - m * 60;
    return (m ? m + ":" + (s < 10 ? "0" : "") + s.toFixed(1) : s.toFixed(1) + "s");
  }

  /* The takes list and its Place button are gone - the log already reports
     what was rendered and where it went, and a second Place path was only
     ever useful for re-placing an old take. voTakes is still kept so take
     numbering per voice keeps counting up within a session. */
  function renderTakes() {}

  /* ---------- placement ---------- */
  /* Both VO tools share the destinations set under Audio > Settings, so a
     generated read and a recorded read land in the same place. Falls back to
     the template path if the Audio module has not loaded for any reason. */
  function voStamp() {
    if (voCtx && voCtx.dateStamp) return String(voCtx.dateStamp);
    var d = new Date();
    function p2(n) { var t = String(n); return t.length < 2 ? "0" + t : t; }
    return p2(d.getMonth() + 1) + p2(d.getDate());
  }

  function voBinPath() {
    var stamp = voStamp();
    if (typeof DeckhandAudio !== "undefined" && DeckhandAudio.activeBinPath) {
      return DeckhandAudio.activeBinPath(stamp);
    }
    var parts = ["02_Audio", "01_VO"];
    if (stamp) parts.push(stamp);
    return parts;
  }

  /* Manual file location wins over the host-resolved folder. The host already
     appends MMDD when it resolves automatically, so a manual folder has to
     have MMDD appended here to match. */
  function voOutDir() {
    var manual = "";
    if (typeof DeckhandAudio !== "undefined" && DeckhandAudio.savedDir) {
      try { manual = DeckhandAudio.savedDir() || ""; } catch (e) { manual = ""; }
    }
    if (manual) return String(manual).replace(/\/+$/, "") + "/" + voStamp();
    return voCtx ? voCtx.voDir : "";
  }

  /* Generate Only: import the new file into the VO bin without touching the
     timeline, so it's ready to drag in. */
  function importTake(take) {
    vlog("Saved to " + voOutDir());
    host("DH_importVO",
      { path: take.path, place: false, binPath: voBinPath(), name: take.name },
      function (r) {
        if (r && r.log) for (var i = 0; i < r.log.length; i++) vlog(r.log[i].msg, r.log[i].cls);
        if (r && r.ok) vlog("✓ Added to the project" + (r.bin ? " in " + r.bin : "") + " (not placed on the timeline).", "ok");
        else vlog("✗ " + ((r && r.error) || "Couldn't add it to the project.") + " The file is still on disk.", "err");
      });
  }

  function placeTake(take) {
    var s = readUI();
    vlog("Placing " + take.name + "…");
    host("DH_importVO",
      { path: take.path, track: s.track,
        /* Mirrors the disk tree the host already writes to, and matches the
           Record tool: 02_Audio > 01_VO > MMDD. The stamp comes from
           DH_voContext so the bin cannot disagree with the folder the file
           was written into. Empty names are dropped rather than creating an
           unnamed bin. */
        binPath: voBinPath(),
        name: take.name },
      function (r) {
        if (r && r.log) for (var i = 0; i < r.log.length; i++) vlog(r.log[i].msg, r.log[i].cls);
        if (r && r.ok) {
          take.placed = true;
          renderTakes();
          vlog("✓ Placed on " + r.track + " at " + r.at + ".", "ok");
        } else {
          vlog("✗ " + ((r && r.error) || "Placement failed."), "err");
        }
      });
  }

  /* ---------- generate ---------- */
  function setBusy(b, label) {
    voBusy = b;
    $("voGen").disabled = b;
    $("voGenOnly").disabled = b;
    if (label) $("voGen").textContent = label;
    else $("voGen").textContent = "Generate & Place at Playhead";
  }

  function runGenerate(place) {
    if (voBusy) return;
    var s = readUI();
    var text = $("voScript").value;

    if (!s.voiceId) { vlog("✗ Pick a voice first.", "err"); return; }
    if (!DeckhandVO.charCount(text)) { vlog("✗ Paste a script first.", "err"); return; }

    setBusy(true, "Generating…");
    vlog("──────────────");
    vlog("Voice Over — generating…");

    refreshCtx(function (ctx) {
      if (!ctx) {
        setBusy(false);
        vlog("✗ No project open — STN - AE Helper needs somewhere to write the audio.", "err");
        return;
      }

      var v = voiceById(s.voiceId);
      var take = 1;
      for (var i = 0; i < voTakes.length; i++) if (voTakes[i].voiceId === s.voiceId) take++;

      DeckhandVO.generate({
        text: text,
        voiceId: s.voiceId,
        voiceName: v ? v.name : "",
        model: s.model,
        format: s.format,
        stability: s.stability,
        similarity: s.similarity,
        style: s.style,
        speed: s.speed,
        outDir: voOutDir(),
        take: take
      }, function (err, res) {
        setBusy(false);
        if (err) { setVOBlocked(isBlockedErr(err)); vlog("✗ " + err, "err"); return; }
        setVOBlocked(false);

        var rec = { name: res.name, path: res.path, seconds: res.seconds,
                    voiceId: s.voiceId, placed: false };
        voTakes.push(rec);
        renderTakes();

        vlog("✓ Rendered " + res.name + (res.seconds ? "  (" + fmtDur(res.seconds) + ")" : ""), "ok");
        if (ctx.voWhy) vlog("⚠ " + ctx.voWhy, "warn");
        if (place) placeTake(rec);
        else importTake(rec);
      });
    });
  }

  $("voGen").onclick = function () { runGenerate(true); };
  $("voGenOnly").onclick = function () { runGenerate(false); };

  /* ---------- boot ---------- */
  syncEngine();
  applySettings(DeckhandVO.getSettings());
  (function () {
    var cached = DeckhandVO.getCachedVoices();
    if (cached) { voVoices = cached; renderVoices(); }
    else { loadVoices(false); }
  })();
  window.setTimeout(function () { refreshCtx(null); }, 900);
})();

/* ---- Edit: open the job root in Finder ----
   Premiere's own Reveal in Finder stops at the folder holding the .prproj.
   The Harbor template is fixed, so the job root is two levels above that. */
(function wireOpenRoot() {
  var btn = $("edOpenRoot");
  if (!btn) return;
  btn.onclick = function () {
    btn.disabled = true;
    host("DH_openJobRoot", {}, function (r) {
      btn.disabled = false;
      if (!r || !r.ok) {
        logTo("editLog", (r && r.error) ? r.error : "Could not open the project folder.", "err");
        return;
      }
      logTo("editLog", "Opened " + r.path, "ok");
    });
  };
})();

/* ---- Edit: add tracks ---- */
$("edAddVideoTrack").onclick = function () { edRunBtn("DH_addVideoTrack", {}, "Add Video Track", this); };
$("edAddAudioTrack").onclick = function () { edRunBtn("DH_addAudioTrack", {}, "Add Audio Track", this); };

/* ---- Search page: STN Search Suite (hosted on GitHub Pages) ----
   The suite loads in a frame, so updates pushed to GitHub show up here
   automatically. The frame can't reach CEP itself, so it hands every link to
   this panel with postMessage ("stn-open") and we open it in the default
   browser. Handshake: the suite sends "stn-ready", we answer "stn-host".
   Only messages from the suite's own origin and frame are accepted, and only
   http(s) and claude:// links are opened. Loaded on first visit, not at launch. */
(function stnSearch() {
  var SUITE_URL = "https://signalthroughnoise.github.io/stn-search/";
  var SUITE_ORIGIN = new URL(SUITE_URL).origin;
  var frame = $("stnFrame"), fallback = $("stnFallback");
  if (!frame) return;
  var loaded = false, ready = false, timer = null;

  // Brief status line under the frame (also tells us which route was used).
  function toast(msg) {
    var el = $("stnToast");
    if (!el) return;
    el.textContent = msg;
    el.hidden = false;
    size();
    clearTimeout(toast._t);
    toast._t = setTimeout(function () { el.hidden = true; size(); }, 9000);
  }

  function copyText(text) {
    try {
      var ta = document.createElement("textarea");
      ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
      document.body.appendChild(ta); ta.select();
      var ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch (e) { return false; }
  }

  function nodeRequire() {
    try { if (window.cep_node && typeof window.cep_node.require === "function") return window.cep_node.require; } catch (e) {}
    try { if (typeof require === "function") return require; } catch (e2) {}
    return null;
  }

  function openExternal(url) {
    if (/^https?:/i.test(url)) {
      try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(url); return; } } catch (e) {}
      try { if (cs && cs.openURLInDefaultBrowser) { cs.openURLInDefaultBrowser(url); return; } } catch (e2) {}
      try { window.open(url, "_blank"); } catch (e3) {}
      return;
    }
    // claude:// links. CEP's opener only handles web addresses, so hand the
    // link to macOS via Node (like clicking it in any other app). Always copy
    // the prompt too, so it can be pasted if Claude doesn't open.
    var prompt = "";
    try { prompt = new URL(url).searchParams.get("q") || ""; } catch (eU) {}
    var copied = prompt ? copyText(prompt) : false;
    var tail = copied ? " Prompt also copied — paste it into Claude if needed." : "";
    var req = nodeRequire();
    if (req) {
      try {
        var cp = req("child_process");
        var cb = function (err) {
          if (err) toast("Couldn't open Claude (" + (err.code || err.message || "error") + ")." + tail);
        };
        if (navigator.platform.indexOf("Win") === 0) cp.execFile("cmd", ["/c", "start", "", url], cb);
        else cp.execFile("/usr/bin/open", [url], cb);
        toast("Opening Claude…" + tail);
        return;
      } catch (eN) {
        toast("Couldn't open Claude (Node: " + (eN.message || eN) + ")." + tail);
        return;
      }
    }
    try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) window.cep.util.openURLInDefaultBrowser(url); } catch (eC) {}
    toast("Couldn't open Claude from Premiere (no Node)." + tail);
  }

  function size() {
    var top = frame.getBoundingClientRect().top;
    frame.style.height = Math.max(320, window.innerHeight - top - 14) + "px";
  }

  function load() {
    ready = false;
    fallback.hidden = true;
    frame.src = "about:blank";
    frame.src = SUITE_URL;
    clearTimeout(timer);
    timer = setTimeout(function () { if (!ready) fallback.hidden = false; }, 12000);
    size();
  }

  window.addEventListener("message", function (ev) {
    if (ev.origin !== SUITE_ORIGIN || ev.source !== frame.contentWindow) return;
    var d = ev.data || {};
    if (d.type === "stn-ready") {
      ready = true;
      clearTimeout(timer);
      fallback.hidden = true;
      frame.contentWindow.postMessage({ type: "stn-host", host: "premiere" }, SUITE_ORIGIN);
    } else if (d.type === "stn-open" && typeof d.url === "string" && /^(https?:|claude:)/i.test(d.url)) {
      openExternal(d.url);
    }
  });

  var baseShowPage = showPage;
  showPage = function (id) {
    baseShowPage(id);
    if (id === "page-search") {
      if (!loaded) { loaded = true; load(); }
      setTimeout(size, 0);
    }
  };

  window.addEventListener("resize", size);
  $("stnRetry").addEventListener("click", load);
  $("stnOpen").addEventListener("click", function () { openExternal(SUITE_URL); });
})();

/* ---- Slate: insert the Signal Slate MOGRT shipped in Slate/ ---- */
var SLATE_DIR = cs.getSystemPath(SystemPath.EXTENSION) + "/Slate";   // host picks 16:9, 9:16 or square
$("slateInsert").onclick = function () {
  var btn = this; btn.disabled = true;
  slateStatus("Inserting slate…");
  host("DH_insertSlate", { dir: SLATE_DIR }, function (r) {
    btn.disabled = false;
    var warn = "";
    if (r && r.log) for (var i = 0; i < r.log.length; i++) if (r.log[i].cls === "warn") warn += " " + r.log[i].msg;
    if (r && r.ok) {
      slateStatus("✓ " + (r.message || "Slate inserted.") + warn, warn ? "" : "ok");
      setTimeout(function () { readSlateNow(true); }, 300);
    } else {
      slateStatus((r && r.exists ? "" : "✗ ") + ((r && r.error) || "Failed."), r && r.exists ? "" : "err");
    }
  });
};

/* "Clear All" — empties every field in the panel and writes the blanks to the
   slate in the sequence (same path as All). Turns TODAY off so Date clears too. */
$("slateClearAll").onclick = function () {
  var inputs = document.querySelectorAll('#slateFields input[type="text"][data-field]');
  for (var i = 0; i < inputs.length; i++) inputs[i].value = "";
  if ($("slateToday") && $("slateToday").checked) { $("slateToday").checked = false; applyTodayDate(); }
  if (typeof updateFileName === "function") updateFileName();
  $("slateSetAll").click();   // write the blanks to the MOGRT
};


/* ---- Prep: TC burn-in layer ---- */
(function () {
  function run(fn, payload, label, btn) {
    btn.disabled = true;
    log("──────────────");
    log(label + "…");
    host(fn, payload, function (r) {
      if (r && r.log) for (var i = 0; i < r.log.length; i++) log(r.log[i].msg, r.log[i].cls);
      if (r && r.ok) log("✓ " + (r.message || label + " done."), "ok");
      else log("✗ " + ((r && r.error) || "Failed."), "err");
      btn.disabled = false;
    });
  }
  if (!$("burninAdd")) return;
  $("burninAdd").onclick = function () {
    var t = parseInt($("burnLow").value, 10) || 5;
    run("DH_addBurninLayer", { track: t, ext: cs.getSystemPath(SystemPath.EXTENSION) }, "Adding burn-in layer on V" + t, this);
  };
  $("burninCapture").onclick = function () {
    run("DH_captureBurnin", {}, "Capturing burn-in settings", this);
  };
})();


/* ---- Prep: Pre-flight + Music & Stock report ---- */
(function () {
  if (!$("preflightRun")) return;
  function num(id, d) { var el = $(id); return el ? (parseInt(el.value, 10) || d) : d; }
  function chk(id) { var el = $(id); return el ? !!el.checked : true; }
  function layout() {
    function lohi(a, b) { var lo = num(a, 1), hi = num(b, 1); return lo <= hi ? [lo, hi] : [hi, lo]; }
    var c = lohi("clipsLow", "clipsHigh"), g = lohi("gfxLow", "gfxHigh"), b = lohi("burnLow", "burnHigh");
    return { clipsLow: c[0], clipsHigh: c[1], gfxLow: g[0], gfxHigh: g[1], burnLow: b[0], burnHigh: b[1] };
  }
  function done(btn) { btn.disabled = false; }

  $("preflightRun").onclick = function () {
    var btn = this; btn.disabled = true;
    log("──────────────");
    log("Pre-flight…");
    host("DH_preflight", { layout: layout(), clipsOn: chk("clipsOn"), gfxOn: chk("gfxOn"), burnOn: chk("burnOn") }, function (r) {
      done(btn);
      if (!r || !r.ok) { log("✗ " + ((r && r.error) || "Pre-flight failed."), "err"); return; }
      log(r.summary);
      for (var i = 0; i < r.issues.length; i++) {
        var it = r.issues[i], cls = it.sev === "err" ? "err" : "warn";
        log((it.sev === "err" ? "✗ " : "⚠ ") + it.what + " — " + it.where.length, cls);
        for (var j = 0; j < it.where.length && j < 8; j++) log("    " + it.where[j], "");
        if (it.where.length > 8) log("    …and " + (it.where.length - 8) + " more", "");
      }
      log("• " + r.note);
      if (!r.issues.length) log("✓ Pre-flight clean — ready to prep.", "ok");
      else log((r.errors ? "✗ " : "⚠ ") + r.errors + " problem(s), " + r.warnings + " warning(s).", r.errors ? "err" : "warn");
    });
  };

  $("msReport").onclick = function () {
    var btn = this; btn.disabled = true;
    log("──────────────");
    log("Music & stock report…");
    host("DH_musicStockReport", {}, function (r) {
      done(btn);
      if (!r || !r.ok) { log("✗ " + ((r && r.error) || "Report failed."), "err"); return; }
      var flagged = 0, i;
      log("Music — " + r.music.length + " use(s) of " + r.totals.length + " track(s):");
      for (i = 0; i < r.totals.length; i++) log("    " + r.totals[i].file + "  ·  " + r.totals[i].uses + "× · " + r.totals[i].sec + "s", "");
      for (i = 0; i < r.music.length; i++) if (r.music[i].flag) { flagged++; log("⚠ " + r.music[i].flag + "  " + r.music[i].track + " " + r.music[i].tin + "  " + r.music[i].file, "warn"); }
      log("Stock — " + r.stock.length + " clip(s):");
      for (i = 0; i < r.stock.length; i++) {
        var u = r.stock[i];
        if (u.flag) flagged++;
        log((u.flag ? "⚠ " + u.flag + "  " : "    ") + u.track + " " + u.tin + "  " + u.file, u.flag ? "warn" : "");
      }
      if (!r.music.length && !r.stock.length) log("• No music or stock found (matched by file path and name — see README for the patterns).");
      if (r.csv) log("✓ Saved " + r.csv, "ok");
      if (flagged) log("⚠ " + flagged + " item(s) flagged — clear or replace before delivery.", "warn");
      else if (r.music.length || r.stock.length) log("✓ Nothing flagged.", "ok");
    });
  };
})();
