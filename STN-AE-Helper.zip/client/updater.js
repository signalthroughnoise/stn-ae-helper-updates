/*
 * STN - AE Helper updater (from Deckhand). Checks github.com/signalthroughnoise/stn-ae-helper-updates.
 * Place this file in your extension's /js folder.
 * Runs on the panel (Chromium/Node) side. This is NOT ExtendScript.
 * You should never need to edit this file.
 */
var DeckhandUpdater = (function () {
  var fs = require("fs");
  var path = require("path");
  var os = require("os");
  var https = require("https");
  var cp = require("child_process");

  var VERSION_URL = "https://raw.githubusercontent.com/signalthroughnoise/stn-ae-helper-updates/main/version.json";
  var ZIP_URL = "https://raw.githubusercontent.com/signalthroughnoise/stn-ae-helper-updates/main/STN-AE-Helper.zip";
  // Authoritative "what's the newest build" source. Unlike raw.githubusercontent
  // (which caches the branch->commit mapping for ~5 min and ignores query strings,
  // so it kept serving an old version.json), this redirect flips to the new tag the
  // instant a release is published. We read the tag out of its Location header.
  var LATEST_URL = "https://github.com/signalthroughnoise/stn-ae-helper-updates/releases/latest";

  // Resolve the extension root reliably. CEP does not set __dirname the way plain
  // Node does, so ask the host first and only fall back to path guessing.
  var _extRoot = null;

  function looksLikeRoot(p) {
    try { return !!p && fs.existsSync(path.join(p, "CSXS", "manifest.xml")); }
    catch (e) { return false; }
  }

  function hostExtensionPath() {
    try {
      if (typeof CSInterface === "undefined") return null;
      var ci = new CSInterface();
      var p = ci.getSystemPath(SystemPath.EXTENSION);
      if (!p) return null;
      p = String(p).replace(/^file:\/\//, "");
      try { p = decodeURIComponent(p); } catch (e) {}
      return p;
    } catch (e2) { return null; }
  }

  function extRootPath() {
    if (_extRoot) return _extRoot;
    var tries = [];
    tries.push(hostExtensionPath());
    try { tries.push(path.resolve(__dirname, "..")); } catch (e) {}
    try { tries.push(__dirname); } catch (e2) {}
    try { tries.push(path.resolve(".")); } catch (e3) {}
    for (var i = 0; i < tries.length; i++) {
      if (looksLikeRoot(tries[i])) { _extRoot = tries[i]; return _extRoot; }
    }
    _extRoot = tries[0] || "";
    return _extRoot;
  }

  function localVerFile() { return path.join(extRootPath(), "version.json"); }

  function getLocalVersion() {
    try {
      return JSON.parse(fs.readFileSync(localVerFile(), "utf8")).version;
    } catch (e) {
      return "0.0.0";
    }
  }

  function isNewer(remote, local) {
    var r = String(remote).split(".");
    var l = String(local).split(".");
    for (var i = 0; i < 3; i++) {
      var rv = parseInt(r[i], 10) || 0;
      var lv = parseInt(l[i], 10) || 0;
      if (rv > lv) return true;
      if (rv < lv) return false;
    }
    return false;
  }

  function fetchText(url, cb, depth) {
    depth = depth || 0;
    if (depth > 5) return cb(new Error("Too many redirects"));
    // raw.githubusercontent is served through a CDN that caches for ~5 minutes.
    // Send no-cache headers so the version check always reflects the newest
    // release instead of a stale copy (which showed up as a false "up to date").
    var opts;
    try {
      opts = require("url").parse(url);
      opts.headers = { "Cache-Control": "no-cache", "Pragma": "no-cache" };
    } catch (e0) { opts = url; }
    https.get(opts, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return fetchText(res.headers.location, cb, depth + 1);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return cb(new Error("HTTP " + res.statusCode));
      }
      var body = "";
      res.setEncoding("utf8");
      res.on("data", function (d) { body += d; });
      res.on("end", function () { cb(null, body); });
    }).on("error", cb);
  }

  function fetchToFile(url, dest, cb, depth) {
    depth = depth || 0;
    if (depth > 5) return cb(new Error("Too many redirects"));
    https.get(url, function (res) {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        return fetchToFile(res.headers.location, dest, cb, depth + 1);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return cb(new Error("HTTP " + res.statusCode));
      }
      var out = fs.createWriteStream(dest);
      res.pipe(out);
      out.on("finish", function () { out.close(function () { cb(null); }); });
      out.on("error", cb);
    }).on("error", cb);
  }

  function copyDir(src, dst) {
    var items = fs.readdirSync(src);
    for (var i = 0; i < items.length; i++) {
      if (items[i] === "__MACOSX" || items[i] === ".DS_Store") continue;
      var s = path.join(src, items[i]);
      var d = path.join(dst, items[i]);
      if (fs.statSync(s).isDirectory()) {
        if (!fs.existsSync(d)) fs.mkdirSync(d);
        copyDir(s, d);
      } else {
        fs.writeFileSync(d, fs.readFileSync(s));
      }
    }
  }

  // Resolve the newest published release by reading the tag out of the
  // releases/latest redirect. Does NOT follow the redirect to the HTML page —
  // it just reads the Location header, so it's cheap, unauthenticated, and not
  // subject to the API rate limit or the raw CDN's stale ref cache.
  function fetchLatestVersion(cb) {
    function go(u, depth) {
      if (depth > 5) return cb(new Error("Too many redirects"));
      var opts;
      try {
        opts = require("url").parse(u);
        opts.headers = { "User-Agent": "Deckhand-Updater", "Cache-Control": "no-cache", "Pragma": "no-cache" };
      } catch (e0) { opts = u; }
      https.get(opts, function (res) {
        res.resume();
        var loc = res.headers.location;
        var m = loc && String(loc).match(/\/releases\/tag\/([^\/?#]+)/);
        if (m) {
          var v = m[1];
          try { v = decodeURIComponent(v); } catch (e1) {}
          return cb(null, v);
        }
        // Some hops redirect without the tag yet (e.g. protocol/host normalize) —
        // follow those, but a non-redirect here means we couldn't resolve it.
        if (res.statusCode >= 300 && res.statusCode < 400 && loc) return go(loc, depth + 1);
        return cb(new Error("Could not resolve latest release (HTTP " + res.statusCode + ")"));
      }).on("error", cb);
    }
    go(LATEST_URL, 0);
  }

  /* STN: no GitHub Releases. The repo's main branch holds version.json and
     STN-AE-Helper.zip; publishing an update = committing both. The raw CDN
     can lag a few minutes after a push — harmless for an update check. */
  function checkForUpdate(onResult) {
    var local = getLocalVersion();
    var url = VERSION_URL + (VERSION_URL.indexOf("?") >= 0 ? "&" : "?") + "t=" + Date.now();
    fetchText(url, function (err, body) {
      var j = null;
      try { j = JSON.parse(body); } catch (e) {}
      if (err || !j || !j.version) return onResult({ status: "offline", local: local });
      if (!isNewer(j.version, local)) return onResult({ status: "current", local: local });
      onResult({ status: "update", version: j.version, notes: j.notes || "", local: local });
    });
  }

  function applyUpdate(expectedVersion, cb) {
    if (typeof expectedVersion === "function") { cb = expectedVersion; expectedVersion = null; }

    var root = extRootPath();
    if (!looksLikeRoot(root)) {
      return cb(new Error("Could not locate the extension folder (looked at: " + root + ")"));
    }

    var tmp, zipPath, stage;
    try {
      tmp = fs.mkdtempSync(path.join(os.tmpdir(), "deckhand-"));
      zipPath = path.join(tmp, "Deckhand.zip");
      stage = path.join(tmp, "extract");
      fs.mkdirSync(stage);
    } catch (e) {
      return cb(e);
    }

    fetchToFile(ZIP_URL, zipPath, function (err) {
      if (err) return cb(err);
      try {
        cp.execSync('tar -xf "' + zipPath + '" -C "' + stage + '"');
        if (!fs.existsSync(path.join(stage, "CSXS", "manifest.xml"))) {
          return cb(new Error("Zip layout wrong: CSXS/manifest.xml not at top level of the zip"));
        }
        copyDir(stage, root);
      } catch (e2) {
        return cb(e2);
      }

      // Prove the write actually landed. Read version.json back off disk.
      var after;
      try {
        after = JSON.parse(fs.readFileSync(path.join(root, "version.json"), "utf8")).version;
      } catch (e3) {
        return cb(new Error("Wrote files but could not read version.json back from " + root));
      }
      if (expectedVersion && after !== expectedVersion) {
        return cb(new Error("Wrote to " + root + " but version reads " + after +
                            " instead of " + expectedVersion));
      }
      cb(null, { root: root, version: after });
    });
  }

  return {
    checkForUpdate: checkForUpdate,
    applyUpdate: applyUpdate,
    getLocalVersion: getLocalVersion,
    getExtensionRoot: extRootPath
  };
})();
