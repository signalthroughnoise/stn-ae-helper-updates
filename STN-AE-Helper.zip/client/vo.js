/*
 * STN VO — scratch voice over. Uses the Mac's built-in voices (free, offline,
 * no account) unless an ElevenLabs key has been saved on the Developer page.
 * Runs on the panel (Chromium/Node) side. This is NOT ExtendScript.
 *
 * All network traffic and disk writing happens here. ExtendScript's Socket
 * object cannot negotiate TLS, so it can never talk to api.elevenlabs.io
 * directly; the host side only ever receives a finished file path.
 */
var DeckhandVO = (function () {
  var fs, path, https;
  var NODE_OK = true;
  try {
    fs = require("fs");
    path = require("path");
    https = require("https");
  } catch (e) { NODE_OK = false; }

  var API_HOST = "api.elevenlabs.io";
  var KEY_LS = "dh_voApiKey";
  var VOICES_LS = "dh_voVoices";
  var SETTINGS_LS = "dh_voSettings";

  /* ---- key storage ----
     No key ships with the panel. A key copied over from an older build's
     storage (the former shared team key) is discarded on first read. */
  var DEFAULT_KEY = "";
  function isLegacyKey(k) { k = String(k || ""); return k.slice(0, 7) === "sk_4d68" && k.slice(-6) === "5b0280"; }

  function getKey() {
    try {
      var k = window.localStorage.getItem(KEY_LS) || "";
      if (isLegacyKey(k)) { window.localStorage.setItem(KEY_LS, ""); return ""; }
      return k;
    } catch (e) { return ""; }
  }
  function setKey(k) {
    try { window.localStorage.setItem(KEY_LS, String(k || "")); } catch (e) {}
  }
  function clearKey() {
    try { window.localStorage.setItem(KEY_LS, ""); } catch (e) {}
  }
  function resetKey() { clearKey(); return ""; }
  /* Which engine: ElevenLabs only when the user has saved their own key. */
  function engine() { return getKey() ? "elevenlabs" : "mac"; }
  function maskKey(k) {
    if (!k) return "";
    if (k.length <= 8) return "••••";
    return k.slice(0, 4) + "••••••••••••" + k.slice(-4);
  }

  /* ---- cached voice list ---- */
  function getCachedVoices() {
    try {
      var raw = window.localStorage.getItem(VOICES_LS + "_" + engine());
      if (!raw) return null;
      var v = JSON.parse(raw);
      return (v && v.length) ? v : null;
    } catch (e) { return null; }
  }
  function setCachedVoices(v) {
    try { window.localStorage.setItem(VOICES_LS + "_" + engine(), JSON.stringify(v || [])); } catch (e) {}
  }

  /* ---- persisted picker/slider state ---- */
  function getSettings() {
    var d = { voiceId: "", model: "eleven_multilingual_v2", stability: 0.5,
              similarity: 0.75, style: 0, speed: 1, track: -1, format: "wav" };
    try {
      var raw = window.localStorage.getItem(SETTINGS_LS);
      if (!raw) return d;
      var s = JSON.parse(raw), k;
      for (k in s) { if (s.hasOwnProperty(k)) d[k] = s[k]; }
      return d;
    } catch (e) { return d; }
  }
  function setSettings(s) {
    try { window.localStorage.setItem(SETTINGS_LS, JSON.stringify(s || {})); } catch (e) {}
  }

  /* ---- generic request helper ----
     binary=true collects Buffers; otherwise the body is parsed as JSON. */
  function request(opts, bodyStr, binary, cb) {
    if (!NODE_OK) { cb("Node.js is not enabled for this panel.", null); return; }
    var key = getKey();
    if (!key) { cb("No API key saved.", null); return; }

    var headers = { "xi-api-key": key };
    if (bodyStr) {
      headers["Content-Type"] = "application/json";
      headers["Content-Length"] = Buffer.byteLength(bodyStr);
    }
    if (binary) headers["Accept"] = "audio/*";

    var req;
    try {
      req = https.request({
        hostname: API_HOST,
        path: opts.path,
        method: opts.method || "GET",
        headers: headers,
        timeout: 120000
      }, function (res) {
        var chunks = [];
        res.on("data", function (c) { chunks.push(c); });
        res.on("end", function () {
          var buf = Buffer.concat(chunks);
          if (res.statusCode !== 200) {
            cb(friendlyError(res.statusCode, buf.toString("utf8")), null);
            return;
          }
          if (binary) { cb(null, buf); return; }
          try { cb(null, JSON.parse(buf.toString("utf8"))); }
          catch (e) { cb("Unreadable response from ElevenLabs.", null); }
        });
      });
    } catch (eR) { cb("Request failed: " + String(eR), null); return; }

    req.on("timeout", function () {
      try { req.destroy(); } catch (e) {}
      cb("Timed out waiting on ElevenLabs.", null);
    });
    req.on("error", function (e) {
      cb("Network error: " + String(e && e.message ? e.message : e), null);
    });
    if (bodyStr) req.write(bodyStr);
    req.end();
  }

  /* Turn the API's status codes into something an editor can act on. */
  function friendlyError(code, body) {
    var detail = "";
    try {
      var j = JSON.parse(body);
      if (j && j.detail) {
        detail = (typeof j.detail === "string") ? j.detail
               : (j.detail.message || j.detail.status || "");
      }
    } catch (e) {}
    if (code === 401) {
      if (/permission/i.test(detail) || /missing_permissions/i.test(String(body)))
        return "API key is missing a permission" + (detail ? " (" + detail + ")" : "") + " — in ElevenLabs, edit the key and allow Text to Speech and Voices: Read.";
      return "API key rejected" + (detail ? " (" + detail + ")" : "") + " — check the key was copied in full, with no spaces.";
    }
    if (code === 403) return "Key is valid but lacks access to that voice or model.";
    if (code === 422) return "ElevenLabs rejected the request" + (detail ? ": " + detail : ".");
    if (code === 429) return "Rate limited or out of credits — wait and retry.";
    if (code >= 500) return "ElevenLabs is having trouble (HTTP " + code + "). Try again shortly.";
    return "HTTP " + code + (detail ? ": " + detail : "");
  }

  /* ---- Mac voices (built-in `say`) ---- */
  var cp = null; try { cp = require("child_process"); } catch (eCp) {}
  function macVoices(cb) {
    if (!cp) { cb("Can't run the Mac speech engine from this panel.", null); return; }
    try { cp.execFile("/usr/bin/say", ["-v", "?"], { maxBuffer: 1024 * 1024 }, function (err, stdout) {
      if (err) { cb("Mac voices unavailable: " + (err.message || err), null); return; }
      var out = [], lines = String(stdout).split("\n");
      for (var i = 0; i < lines.length; i++) {
        var m = lines[i].match(/^(.+?)\s+([a-z]{2,3}_[A-Za-z0-9]{2,4})\s+#/);
        if (!m || m[2].indexOf("en_") !== 0) continue;   // English voices only
        var region = { en_US: "US", en_GB: "UK", en_AU: "Australia", en_IE: "Ireland", en_IN: "India", en_ZA: "South Africa", en_SC: "Scotland", en_NZ: "New Zealand" }[m[2]] || m[2];
        out.push({ id: m[1].replace(/\s+$/, ""), name: m[1].replace(/\s+$/, ""), category: "mac", accent: region, gender: "", use: "", preview: "" });
      }
      out.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1; });
      setCachedVoices(out);
      cb(null, out);
    }); } catch (eX) { cb("Mac voices unavailable: " + (eX && eX.message ? eX.message : eX), null); }
  }
  function macGenerate(opts, text, cb) {
    if (!cp) { cb("Can't run the Mac speech engine from this panel.", null); return; }
    var name = slug(text, 28) + "_" + slug(opts.voiceName || opts.voiceId, 14) + "_" + stamp() + (opts.take ? "_t" + opts.take : "");
    var dir, file, txt;
    try {
      dir = ensureDir(opts.outDir);
      file = path.join(dir, name + ".wav");
      txt = path.join(require("os").tmpdir(), "stn_vo_" + Date.now() + ".txt");
      fs.writeFileSync(txt, text, "utf8");
    } catch (eW) { cb("Could not write to disk: " + String(eW && eW.message ? eW.message : eW), null); return; }
    var rate = Math.round(175 * (Number(opts.speed) || 1));
    cp.execFile("/usr/bin/say", ["-v", opts.voiceId, "-r", String(rate), "-o", file,
      "--file-format=WAVE", "--data-format=LEI16@44100", "-f", txt], { timeout: 120000 }, function (err) {
      try { fs.unlinkSync(txt); } catch (eU) {}
      if (err) { cb("Mac voice failed: " + (err.message || err), null); return; }
      var size = 0; try { size = fs.statSync(file).size; } catch (eS) {}
      if (size < 100) { cb("Mac voice produced an empty file.", null); return; }
      cb(null, { path: file, bytes: size, seconds: (size - 44) / (44100 * 2), name: name });
    });
  }

  /* ---- voices ---- */
  function fetchVoices(cb) {
    if (engine() === "mac") { macVoices(cb); return; }
    request({ path: "/v1/voices", method: "GET" }, null, false, function (err, data) {
      if (err) { cb(err, null); return; }
      var out = [], i, v;
      var list = (data && data.voices) ? data.voices : [];
      for (i = 0; i < list.length; i++) {
        v = list[i];
        out.push({
          id: v.voice_id,
          name: v.name || "(unnamed)",
          category: v.category || "",
          accent: (v.labels && v.labels.accent) ? v.labels.accent : "",
          gender: (v.labels && v.labels.gender) ? v.labels.gender : "",
          use: (v.labels && v.labels.use_case) ? v.labels.use_case : "",
          preview: v.preview_url || ""
        });
      }
      out.sort(function (a, b) { return a.name.toLowerCase() < b.name.toLowerCase() ? -1 : 1; });
      setCachedVoices(out);
      cb(null, out);
    });
  }

  /* ---- WAV wrapper ----
     The pcm_44100 endpoint returns headerless signed 16-bit little-endian mono
     samples. Premiere will not import that, so a 44-byte canonical RIFF header
     goes on the front. Doing it here (rather than taking MP3) keeps the file
     conform-free, so it lands frame-accurate the moment it hits the timeline. */
  function wavHeader(dataLen, sampleRate, channels, bitsPerSample) {
    var byteRate = sampleRate * channels * bitsPerSample / 8;
    var blockAlign = channels * bitsPerSample / 8;
    var h = Buffer.alloc(44);
    h.write("RIFF", 0);
    h.writeUInt32LE(36 + dataLen, 4);
    h.write("WAVE", 8);
    h.write("fmt ", 12);
    h.writeUInt32LE(16, 16);          // PCM chunk size
    h.writeUInt16LE(1, 20);           // format = PCM
    h.writeUInt16LE(channels, 22);
    h.writeUInt32LE(sampleRate, 24);
    h.writeUInt32LE(byteRate, 28);
    h.writeUInt16LE(blockAlign, 32);
    h.writeUInt16LE(bitsPerSample, 34);
    h.write("data", 36);
    h.writeUInt32LE(dataLen, 40);
    return h;
  }

  /* ---- filename ---- */
  function slug(text, max) {
    var s = String(text || "VO").replace(/[\r\n]+/g, " ");
    s = s.replace(/[^A-Za-z0-9 ]+/g, "").replace(/\s+/g, "_");
    s = s.replace(/^_+|_+$/g, "");
    if (!s) s = "VO";
    if (s.length > max) s = s.slice(0, max).replace(/_+$/, "");
    return s;
  }
  function stamp() {
    var d = new Date();
    function p(n) { return (n < 10 ? "0" : "") + n; }
    return String(d.getFullYear()).slice(2) + p(d.getMonth() + 1) + p(d.getDate()) +
           "_" + p(d.getHours()) + p(d.getMinutes()) + p(d.getSeconds());
  }

  /* CEP ships an older Node on some Premiere builds, where mkdirSync has no
     recursive option — so walk the path and create each level by hand. */
  function ensureDir(dir) {
    if (fs.existsSync(dir)) return dir;
    var parts = path.normalize(dir).split(path.sep);
    var cur = parts[0] || path.sep;
    for (var i = 1; i < parts.length; i++) {
      cur = path.join(cur, parts[i]);
      if (!cur) continue;
      if (!fs.existsSync(cur)) {
        try { fs.mkdirSync(cur); } catch (e) {
          if (!fs.existsSync(cur)) throw e;
        }
      }
    }
    return dir;
  }

  /* ---- shared write step ----
     ElevenLabs returns either headerless PCM or a finished MP3, so the
     header/write/verify path is kept in one helper. */
  function writeAudio(buf, isWav, outDir, baseName, cb) {
    var dir, file, out, seconds;
    try {
      dir = ensureDir(outDir);
      file = path.join(dir, baseName + (isWav ? ".wav" : ".mp3"));

      if (isWav) {
        out = Buffer.concat([wavHeader(buf.length, 44100, 1, 16), buf]);
        seconds = buf.length / (44100 * 2);
      } else {
        out = buf;
        seconds = 0; // unknown until Premiere conforms it
      }
      fs.writeFileSync(file, out);

      // Confirm the bytes actually landed before handing the path to the host.
      if (!fs.existsSync(file) || fs.statSync(file).size < out.length) {
        cb("File did not write completely to " + dir, null);
        return;
      }
    } catch (eW) {
      cb("Could not write to disk: " + String(eW && eW.message ? eW.message : eW), null);
      return;
    }
    cb(null, { path: file, bytes: out.length, seconds: seconds, name: baseName });
  }

  /* ---- generate (text to speech) ----
     opts: { text, voiceId, model, stability, similarity, style, speed,
             format ("wav"|"mp3"), outDir, take }
     cb(err, { path, bytes, seconds, name }) */
  function generate(opts, cb) {
    if (!NODE_OK) { cb("Node.js is not enabled for this panel.", null); return; }

    var text = String(opts.text || "").replace(/^\s+|\s+$/g, "");
    if (!text) { cb("Nothing to read — paste a script first.", null); return; }
    if (!opts.voiceId) { cb("Pick a voice first.", null); return; }
    if (engine() === "mac") { macGenerate(opts, text, cb); return; }

    var isWav = (opts.format !== "mp3");
    var fmt = isWav ? "pcm_44100" : "mp3_44100_128";

    var vs = {
      stability: Number(opts.stability),
      similarity_boost: Number(opts.similarity)
    };
    if (opts.style !== undefined && Number(opts.style) > 0) vs.style = Number(opts.style);
    if (opts.speed !== undefined && Number(opts.speed) !== 1) vs.speed = Number(opts.speed);
    vs.use_speaker_boost = true;

    var body = JSON.stringify({
      text: text,
      model_id: opts.model || "eleven_multilingual_v2",
      voice_settings: vs
    });

    var reqPath = "/v1/text-to-speech/" + encodeURIComponent(opts.voiceId) +
                  "?output_format=" + fmt;

    request({ path: reqPath, method: "POST" }, body, true, function (err, buf) {
      if (err) { cb(err, null); return; }
      if (!buf || !buf.length) { cb("ElevenLabs returned an empty file.", null); return; }
      var name = slug(text, 28) + "_" + (opts.voiceName ? slug(opts.voiceName, 14) + "_" : "") +
                 stamp() + (opts.take ? "_t" + opts.take : "");
      writeAudio(buf, isWav, opts.outDir, name, cb);
    });
  }

  /* Character count drives the credit estimate shown under the script box. */
  function charCount(text) {
    return String(text || "").replace(/^\s+|\s+$/g, "").length;
  }

  return {
    nodeAvailable: function () { return NODE_OK; },
    getKey: getKey,
    engine: engine,
    resetKey: resetKey,
    defaultKey: DEFAULT_KEY,
    setKey: setKey,
    clearKey: clearKey,
    maskKey: maskKey,
    getCachedVoices: getCachedVoices,
    setCachedVoices: setCachedVoices,
    getSettings: getSettings,
    setSettings: setSettings,
    fetchVoices: fetchVoices,
    generate: generate,
    charCount: charCount
  };
})();
