/* STN Prep extras: TC Burn-in Layer + Pre-flight + Music & Stock.
   Kept in their own file so an error anywhere in main.js can never leave
   these buttons unwired. Uses main.js globals: $, log, host, cs. */
/* ---- Prep: TC burn-in layer ---- */
(function () {
  function run(fn, payload, label, btn) {
    btn.disabled = true;
    log("──────────────");
    log(label + "…");
    host(fn, payload, function (r) {
      if (r && r.log) for (var i = 0; i < r.log.length; i++) log(r.log[i].msg, r.log[i].cls);
      if (r && r.ok) log("✓ " + (r.message || label + " done."), "ok");
      else log("✗ " + ((r && r.error) || "Failed."), "err");
      btn.disabled = false;
    });
  }
  if (!$("burninAdd")) return;
  $("burninAdd").onclick = function () {
    var t = parseInt($("burnLow").value, 10) || 5;
    run("DH_addBurninLayer", { track: t, ext: cs.getSystemPath(SystemPath.EXTENSION) }, "Adding burn-in layer on V" + t, this);
  };
  $("burninCapture").onclick = function () {
    run("DH_captureBurnin", {}, "Capturing burn-in settings", this);
  };
})();


/* ---- Prep: Pre-flight + Music & Stock report ---- */
(function () {
  if (!$("preflightRun")) return;
  function num(id, d) { var el = $(id); return el ? (parseInt(el.value, 10) || d) : d; }
  function chk(id) { var el = $(id); return el ? !!el.checked : true; }
  function layout() {
    function lohi(a, b) { var lo = num(a, 1), hi = num(b, 1); return lo <= hi ? [lo, hi] : [hi, lo]; }
    var c = lohi("clipsLow", "clipsHigh"), g = lohi("gfxLow", "gfxHigh"), b = lohi("burnLow", "burnHigh");
    return { clipsLow: c[0], clipsHigh: c[1], gfxLow: g[0], gfxHigh: g[1], burnLow: b[0], burnHigh: b[1] };
  }
  function done(btn) { btn.disabled = false; }

  $("preflightRun").onclick = function () {
    var btn = this; btn.disabled = true;
    log("──────────────");
    log("Pre-flight…");
    host("DH_preflight", { layout: layout(), clipsOn: chk("clipsOn"), gfxOn: chk("gfxOn"), burnOn: chk("burnOn") }, function (r) {
      done(btn);
      if (!r || !r.ok) { log("✗ " + ((r && r.error) || "Pre-flight failed."), "err"); return; }
      log(r.summary);
      for (var i = 0; i < r.issues.length; i++) {
        var it = r.issues[i], cls = it.sev === "err" ? "err" : "warn";
        log((it.sev === "err" ? "✗ " : "⚠ ") + it.what + " — " + it.where.length, cls);
        for (var j = 0; j < it.where.length && j < 8; j++) log("    " + it.where[j], "");
        if (it.where.length > 8) log("    …and " + (it.where.length - 8) + " more", "");
      }
      log("• " + r.note);
      if (!r.issues.length) log("✓ Pre-flight clean — ready to prep.", "ok");
      else log((r.errors ? "✗ " : "⚠ ") + r.errors + " problem(s), " + r.warnings + " warning(s).", r.errors ? "err" : "warn");
    });
  };

  $("msReport").onclick = function () {
    var btn = this; btn.disabled = true;
    log("──────────────");
    log("Music & stock report…");
    host("DH_musicStockReport", {}, function (r) {
      done(btn);
      if (!r || !r.ok) { log("✗ " + ((r && r.error) || "Report failed."), "err"); return; }
      var flagged = 0, i;
      log("Music — " + r.music.length + " use(s) of " + r.totals.length + " track(s):");
      for (i = 0; i < r.totals.length; i++) log("    " + r.totals[i].file + "  ·  " + r.totals[i].uses + "× · " + r.totals[i].sec + "s", "");
      for (i = 0; i < r.music.length; i++) if (r.music[i].flag) { flagged++; log("⚠ " + r.music[i].flag + "  " + r.music[i].track + " " + r.music[i].tin + "  " + r.music[i].file, "warn"); }
      log("Stock — " + r.stock.length + " clip(s):");
      for (i = 0; i < r.stock.length; i++) {
        var u = r.stock[i];
        if (u.flag) flagged++;
        log((u.flag ? "⚠ " + u.flag + "  " : "    ") + u.track + " " + u.tin + "  " + u.file, u.flag ? "warn" : "");
      }
      if (!r.music.length && !r.stock.length) log("• No music or stock found (matched by file path and name — see README for the patterns).");
      if (r.csv) log("✓ Saved " + r.csv, "ok");
      if (flagged) log("⚠ " + flagged + " item(s) flagged — clear or replace before delivery.", "warn");
      else if (r.music.length || r.stock.length) log("✓ Nothing flagged.", "ok");
    });
  };
})();

