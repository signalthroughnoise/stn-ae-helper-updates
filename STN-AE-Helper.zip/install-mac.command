#!/bin/bash
# STN - AE Helper — macOS installer.
# Run from Terminal:  bash install-mac.command
# (or right-click ▸ Open the first time, to get past Gatekeeper)

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DEST="$HOME/Library/Application Support/Adobe/CEP/extensions"
NAME="STN - AE Helper"

echo "$NAME — installing for macOS"
echo "-------------------------------------"

# 1. Allow unsigned (dev-mode) panels. Set across plausible CEP versions
#    so it works whatever Premiere build you're on.
for v in 9 10 11 12 13 14 15; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1 2>/dev/null
done
echo "✓ Enabled unsigned panels (PlayerDebugMode)"

# 2. Remove older panels this product replaces, so they stop showing up
#    under Window ▸ Extensions.
mkdir -p "$DEST"
for old in "AE Helper" "Signal Assistant Editor" "Deckhand"; do
  if [ -d "$DEST/$old" ]; then
    rm -rf "$DEST/$old"
    echo "✓ Removed old panel: $old"
  fi
done

# 3. Copy the panel into the CEP extensions folder.
rm -rf "$DEST/$NAME"
cp -R "$DIR" "$DEST/$NAME"
echo "✓ Installed to: $DEST/$NAME"

# 4. Clear Gatekeeper quarantine so Premiere will load it.
xattr -cr "$DEST/$NAME" 2>/dev/null
echo "✓ Cleared quarantine attributes"

echo
echo "Done. Restart Premiere → Window ▸ Extensions ▸ $NAME"
