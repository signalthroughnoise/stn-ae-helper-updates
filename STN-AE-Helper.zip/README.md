# STN - AE Helper — install & usage

_Version 2.0 — built on Signal Assistant Editor 1.3.2 (formerly Deckhand) with the STN additions._

## macOS quick install

1. Open Terminal, type `bash ` (with the trailing space), then **drag `install-mac.command`
   into the window** and hit Return. It enables unsigned panels, removes older panels this
   replaces (AE Helper, Signal Assistant Editor, Deckhand), copies the panel into place, and
   clears Gatekeeper quarantine.
2. Restart Premiere → **Window ▸ Extensions ▸ STN - AE Helper**.

(`CSInterface.js` is already included in `client/` — no need to add it.)

**Presets are bundled.** The two reference presets the panel uses live inside the
extension at `Presets/` (Apple ProRes 422 LT and Match Source – High bitrate) and load
into the dropdowns automatically. To add or swap one, drop a `.epr` into that folder and
hit ↻ Refresh. Note: neither bundled preset has a timecode burn-in — for the burn-in
slot, add a `.epr` that has **Timecode Overlay** enabled (export Effects tab).

The manual steps and full reference are below if you'd rather not use the installer.

---


A Premiere Pro panel that prepares finish-team deliverables from the **active sequence**.
It never touches your master: each team gets a throwaway clone, graphics are stripped on
the clone, exports run against the clone, and clones are left in the project (they must
persist because Media Encoder renders them in the background).

## What each button produces

| Team   | Outputs                                                            | Graphics |
|--------|-------------------------------------------------------------------|----------|
| Color  | reference video, reference + TC burn-in, FCP7 XML, one EDL/track  | stripped |
| Finish | reference video, reference + TC burn-in, FCP7 XML, one EDL/track  | kept     |
| Audio  | reference video, OMF of audio (embedded, trimmed, pan)            | n/a      |

Files land in `<output folder>/<SPOT>_prep_<MMDD>_<time>/<Color|Finish|Audio>/`,
where `<MMDD>` is the zero-padded run date (e.g. `0805`) and `<time>` is the run
start rounded to the nearest 5 minutes (e.g. `1100am`),
so each prep run gets its own subfolder and runs never overwrite each other.

## Bundled dependency

This panel includes Adobe's standard `CSInterface.js` (CEP 12) in `client/`. It's the
bridge between the panel UI and the ExtendScript that drives Premiere. Already present —
nothing to download.

## Install (unsigned, dev mode)

1. **Enable unsigned panels** (one time):
   - **macOS:** `defaults write com.adobe.CSXS.12 PlayerDebugMode 1`
   - **Windows:** in `regedit`, add String `PlayerDebugMode = 1` under
     `HKEY_CURRENT_USER/Software/Adobe/CSXS.12`
   (Premiere 26.x uses CEP 12+. The Mac installer sets CSXS 9–15 so it works
   regardless of exact build; if installing by hand, match your version's number.)

2. **Copy this folder (as `STN - AE Helper`)** into the CEP extensions directory:
   - **macOS:** `~/Library/Application Support/Adobe/CEP/extensions/`
   - **Windows:** `C:\Users\<you>\AppData\Roaming\Adobe\CEP\extensions\`

3. Restart Premiere → **Window ▸ Extensions ▸ STN - AE Helper**.

## Presets

The panel uses the `.epr` files in the extension's `Presets/` folder, shown in the two
dropdowns. Bundled by default: **Apple ProRes 422 LT** (clean master codec) and
**Match Source – High bitrate** (H.264). Pick one per slot. To add a timecode burn-in
option, save a preset with **Timecode Overlay** enabled and drop its `.epr` into
`Presets/`, then hit ↻ Refresh.


## Usage

1. Open the sequence. In **Track layout**, set the video-track *ranges* your graphics and
   (optionally) TC burn-ins live on, using the ▲/▼ steppers. Tick **TC burn-ins on video
   tracks** only if your sequence actually has burn-in layers.
2. Fill spot name, output folder, presets.
3. Click a team (or **All three**).
4. XML / AAF / EDL are written immediately. Reference videos **queue in Media Encoder**
   and finish in the background — leave the clones in the project until AME is done.

## Known v1 caveats (called out in the log when they occur)

- **EDL transitions** are written as straight cuts. Dissolves are flagged to verify.
- **Speed-ramped clips** get nominal source TC and are flagged (Premiere's API reports
  retimed source TC unreliably).
- **Reel names** default to the first 8 chars of the source filename. If your colorist
  needs tape/reel from a metadata field instead, that's a small change in `trackReelName()`.
- **"Without graphics" XML:** graphics clips are *disabled* on the clone. If your XML
  target still reads disabled clips, we switch to deleting them on the clone instead —
  worth verifying on your first conform.

## Slate (Signal Slate MOGRT)

**Insert Signal Slate** (Slate page) picks the template matching the sequence shape —
`Slate/Signal Slate_1920x1080.mogrt`, `_1080x1920.mogrt` or `_1080x1080.mogrt` — and places it at the
head of the active sequence — 00:59:53:00, the sequence start — trimmed to exactly
5 seconds (then 2s of black, program at 01:00:00:00). It goes on the lowest video track
that keeps it visible (V1 when the head is empty), is scaled for non-1920×1080
sequences, and won't add a second slate if one is already there. The Reader edits its
9 text fields: Agency, Client, Title, ADID, Audio, Duration, Date, Format, Copyright
(**Set** writes one, **All** writes every field). To update the slate design, re-export
the MOGRT from After Effects and replace the file in `Slate/`, keeping the same name.

## Social Guides (Edit page)

**Social Guides** lists every image in the extension's `Guides/` folder: safe-zone
guides for Reels, Stories, TikTok, YouTube Shorts, Snapchat, a universal 9:16 guide,
4:5 / 1:1 feed margins, and 16:9 title/action safe plus center-cut crop guides.
**Add** imports the guide into an **STN Guides** bin (once per project), places it on
a new top track across the whole sequence at 50% opacity, and scales it to the
sequence frame. Subfolders become headings; a leading number ("01 ") sets the
order and is hidden. Drop in your own PNGs to add more. `Guides/README.txt` lists
the safe-zone numbers and sources. Projects that still have the old
`06_Tools ▸ Overlays ▸ SOCIAL_GUIDES…` bin show those guides too, under
"From this project".

## Search (STN Search Suite)

The **Search** page (🔎) shows the STN Search Suite — music (Cue Sheet), stock
footage (Second Unit) and templates (Take One) — loaded live from
https://signalthroughnoise.github.io/stn-search/, so changes published there appear
in the panel automatically. Every search link opens in your default browser. Needs
an internet connection; if it can't load, the page offers **Try again** and **Open in
browser**.

## Updates

The panel checks **github.com/signalthroughnoise/stn-ae-helper-updates** for new releases
(Developer page, or click the version number on the home screen). Until that repository
exists it simply reports that it couldn't check. (It no longer looks at the old Deckhand repo.)

## Navigation

The panel opens on a **home screen** listing available tools. Click **Deliver** to
open the delivery page; the **‹** button top-left returns home. Future tools appear
as additional cards on the home screen.

## Track layout

Graphics and TC burn-ins are specified as inclusive video-track *ranges* (bottom→top),
so multiple graphics or burn-in layers are supported. Color strips the graphics range;
Finish keeps it. The clean reference is rendered with burn-in tracks **off**; the
`_REF_TC` reference with them **on** — so timecode comes from your sequence, not a
special preset. XML and EDLs always exclude burn-in tracks (and, for Color, graphics).
Each variant uses its own throwaway clone, so a delivery leaves several clones in the
project until Media Encoder finishes — that's expected.

## Where things go

**On disk:** prep deliverables land in
`<output folder>/<Sequence Name>_prep_<MMDD>_<time>/<Color|Finish|Audio>/`
and Deliver outputs land in `<output folder>/<Sequence Name>_deliver_<MMDD>_<time>/<Segment>/`.
`<MMDD>` is the zero-padded run date (e.g. `0805`) and
`<time>` is the run start rounded to the nearest 5 minutes (12-hour, e.g. `1100am`,
`905pm`), so every run is self-contained. The "Specd Master" segment writes into a
folder named **Master_Spec**. Delivery filenames carry no "_Slate" tag: the slate
version keeps the AD-ID (from Filename override) and the no-slate version drops it,
which is what tells the two apart. Generic outputs end in `_Generic`, Specd Master
outputs end in `_Spec`. If a slate and no-slate are both built without an AD-ID to
separate them, the slate file gets `_slate` appended so neither overwrites the other.
**In the Premiere project:** every sequence the panel creates is filed under
`07_Prep / STN_<Prep|Deliver>_MMDD / <run folder>` (created if missing) — the same
per-run folder name used on disk, so clones from a run stay grouped together.

**Audio OMF settings (fixed):** 48 kHz, 16-bit, embedded audio (AIFF), trimmed, pan included,
OMF title = sequence name. Handle frames default to 24 and are adjustable.

## Voice Over (scratch reads)

Audio ▸ Voice Over uses your Mac's built-in voices: free, offline, no account.
For better voices, download English "Premium"/"Enhanced" voices in System Settings ▸
Accessibility ▸ Spoken Content ▸ System Voice ▸ Manage Voices, then hit ⟳ in the panel.
Optional: save your own ElevenLabs API key on the Developer page to switch to ElevenLabs.
No key ships with the panel.

## Prep ▸ Pre-flight

Run Pre-flight before prepping: offline media, disabled/reversed/speed-changed/time-remapped
clips, nests, multicam, and graphics or burn-ins outside the Track layout ranges.
Music & Stock Report lists music (audio files whose path or name looks like music —
e.g. a `Music` folder or a library name) and stock (paths/names containing AdobeStock, iStock,
Getty, Shutterstock, Pond5, Storyblocks, Artgrid, Artlist, Envato, "stock", …), flags temp
music and preview/watermarked comps, and writes `<Sequence>_MusicStock_MMDD.csv` beside the project.
