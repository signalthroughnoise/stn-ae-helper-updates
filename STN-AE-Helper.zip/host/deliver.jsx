/**********************************************************************
 * Deckhand — ExtendScript host (Premiere Pro)
 *
 * Entry points called from the panel:
 *   DH_browse(jsonArg)   -> { ok, path }
 *   DH_deliver(jsonArg)  -> { ok, error, log:[{msg,cls}] }
 *
 * Design: never touch the master. Each team gets a throwaway CLONE of
 * the active sequence; graphics are stripped on the clone (not the
 * original); exports run against the clone; clones are LEFT in the
 * project (not deleted) because Media Encoder renders them async and
 * needs them to persist until rendering finishes.
 *
 * Tested against the documented PPro ExtendScript API. EDL is generated
 * directly from timeline data because Premiere exposes no EDL export.
 *********************************************************************/

#target premierepro

/* ---- JSON polyfill (Crockford json2.js, public domain) ----
   ExtendScript's ES3 engine has no native JSON; this supplies it.
   Guarded, so it won't override a real JSON if one exists. ---- */
//  json2.js
//  2023-05-10
//  Public Domain.
//  NO WARRANTY EXPRESSED OR IMPLIED. USE AT YOUR OWN RISK.

//  USE YOUR OWN COPY. IT IS EXTREMELY UNWISE TO LOAD CODE FROM SERVERS YOU DO
//  NOT CONTROL.

//  This file creates a global JSON object containing two methods: stringify
//  and parse. This file provides the ES5 JSON capability to ES3 systems.
//  If a project might run on IE8 or earlier, then this file should be included.
//  This file does nothing on ES5 systems.

//      JSON.stringify(value, replacer, space)
//          value       any JavaScript value, usually an object or array.
//          replacer    an optional parameter that determines how object
//                      values are stringified for objects. It can be a
//                      function or an array of strings.
//          space       an optional parameter that specifies the indentation
//                      of nested structures. If it is omitted, the text will
//                      be packed without extra whitespace. If it is a number,
//                      it will specify the number of spaces to indent at each
//                      level. If it is a string (such as "\t" or "&nbsp;"),
//                      it contains the characters used to indent at each level.
//          This method produces a JSON text from a JavaScript value.
//          When an object value is found, if the object contains a toJSON
//          method, its toJSON method will be called and the result will be
//          stringified. A toJSON method does not serialize: it returns the
//          value represented by the name/value pair that should be serialized,
//          or undefined if nothing should be serialized. The toJSON method
//          will be passed the key associated with the value, and this will be
//          bound to the value.

//          For example, this would serialize Dates as ISO strings.

//              Date.prototype.toJSON = function (key) {
//                  function f(n) {
//                      // Format integers to have at least two digits.
//                      return (n < 10)
//                          ? "0" + n
//                          : n;
//                  }
//                  return this.getUTCFullYear()   + "-" +
//                       f(this.getUTCMonth() + 1) + "-" +
//                       f(this.getUTCDate())      + "T" +
//                       f(this.getUTCHours())     + ":" +
//                       f(this.getUTCMinutes())   + ":" +
//                       f(this.getUTCSeconds())   + "Z";
//              };

//          You can provide an optional replacer method. It will be passed the
//          key and value of each member, with this bound to the containing
//          object. The value that is returned from your method will be
//          serialized. If your method returns undefined, then the member will
//          be excluded from the serialization.

//          If the replacer parameter is an array of strings, then it will be
//          used to select the members to be serialized. It filters the results
//          such that only members with keys listed in the replacer array are
//          stringified.

//          Values that do not have JSON representations, such as undefined or
//          functions, will not be serialized. Such values in objects will be
//          dropped; in arrays they will be replaced with null. You can use
//          a replacer function to replace those with JSON values.

//          JSON.stringify(undefined) returns undefined.

//          The optional space parameter produces a stringification of the
//          value that is filled with line breaks and indentation to make it
//          easier to read.

//          If the space parameter is a non-empty string, then that string will
//          be used for indentation. If the space parameter is a number, then
//          the indentation will be that many spaces.

//          Example:

//          text = JSON.stringify(["e", {pluribus: "unum"}]);
//          // text is '["e",{"pluribus":"unum"}]'

//          text = JSON.stringify(["e", {pluribus: "unum"}], null, "\t");
//          // text is '[\n\t"e",\n\t{\n\t\t"pluribus": "unum"\n\t}\n]'

//          text = JSON.stringify([new Date()], function (key, value) {
//              return this[key] instanceof Date
//                  ? "Date(" + this[key] + ")"
//                  : value;
//          });
//          // text is '["Date(---current time---)"]'

//      JSON.parse(text, reviver)
//          This method parses a JSON text to produce an object or array.
//          It can throw a SyntaxError exception.

//          The optional reviver parameter is a function that can filter and
//          transform the results. It receives each of the keys and values,
//          and its return value is used instead of the original value.
//          If it returns what it received, then the structure is not modified.
//          If it returns undefined then the member is deleted.

//          Example:

//          // Parse the text. Values that look like ISO date strings will
//          // be converted to Date objects.

//          myData = JSON.parse(text, function (key, value) {
//              var a;
//              if (typeof value === "string") {
//                  a =
//   /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2}(?:\.\d*)?)Z$/.exec(value);
//                  if (a) {
//                      return new Date(Date.UTC(
//                         +a[1], +a[2] - 1, +a[3], +a[4], +a[5], +a[6]
//                      ));
//                  }
//                  return value;
//              }
//          });

//          myData = JSON.parse(
//              "[\"Date(09/09/2001)\"]",
//              function (key, value) {
//                  var d;
//                  if (
//                      typeof value === "string"
//                      && value.slice(0, 5) === "Date("
//                      && value.slice(-1) === ")"
//                  ) {
//                      d = new Date(value.slice(5, -1));
//                      if (d) {
//                          return d;
//                      }
//                  }
//                  return value;
//              }
//          );

//  This is a reference implementation. You are free to copy, modify, or
//  redistribute.

/*jslint
    eval, for, this
*/

/*property
    JSON, apply, call, charCodeAt, getUTCDate, getUTCFullYear, getUTCHours,
    getUTCMinutes, getUTCMonth, getUTCSeconds, hasOwnProperty, join,
    lastIndex, length, parse, prototype, push, replace, slice, stringify,
    test, toJSON, toString, valueOf
*/


// Create a JSON object only if one does not already exist. We create the
// methods in a closure to avoid creating global variables.

if (typeof JSON !== "object") {
    JSON = {};
}

(function () {
    "use strict";

    var rx_one = /^[\],:{}\s]*$/;
    var rx_two = /\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g;
    var rx_three = /"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g;
    var rx_four = /(?:^|:|,)(?:\s*\[)+/g;
    var rx_escapable = /[\\"\u0000-\u001f\u007f-\u009f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;
    var rx_dangerous = /[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g;

    function f(n) {
        // Format integers to have at least two digits.
        return (n < 10)
            ? "0" + n
            : n;
    }

    function this_value() {
        return this.valueOf();
    }

    if (typeof Date.prototype.toJSON !== "function") {

        Date.prototype.toJSON = function () {

            return isFinite(this.valueOf())
                ? (
                    this.getUTCFullYear()
                    + "-"
                    + f(this.getUTCMonth() + 1)
                    + "-"
                    + f(this.getUTCDate())
                    + "T"
                    + f(this.getUTCHours())
                    + ":"
                    + f(this.getUTCMinutes())
                    + ":"
                    + f(this.getUTCSeconds())
                    + "Z"
                )
                : null;
        };

        Boolean.prototype.toJSON = this_value;
        Number.prototype.toJSON = this_value;
        String.prototype.toJSON = this_value;
    }

    var gap;
    var indent;
    var meta;
    var rep;


    function quote(string) {

// If the string contains no control characters, no quote characters, and no
// backslash characters, then we can safely slap some quotes around it.
// Otherwise we must also replace the offending characters with safe escape
// sequences.

        rx_escapable.lastIndex = 0;
        return rx_escapable.test(string)
            ? "\"" + string.replace(rx_escapable, function (a) {
                var c = meta[a];
                return typeof c === "string"
                    ? c
                    : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4);
            }) + "\""
            : "\"" + string + "\"";
    }


    function str(key, holder) {

// Produce a string from holder[key].

        var i;          // The loop counter.
        var k;          // The member key.
        var v;          // The member value.
        var length;
        var mind = gap;
        var partial;
        var value = holder[key];

// If the value has a toJSON method, call it to obtain a replacement value.

        if (
            value
            && typeof value === "object"
            && typeof value.toJSON === "function"
        ) {
            value = value.toJSON(key);
        }

// If we were called with a replacer function, then call the replacer to
// obtain a replacement value.

        if (typeof rep === "function") {
            value = rep.call(holder, key, value);
        }

// What happens next depends on the value's type.

        switch (typeof value) {
        case "string":
            return quote(value);

        case "number":

// JSON numbers must be finite. Encode non-finite numbers as null.

            return (isFinite(value))
                ? String(value)
                : "null";

        case "boolean":
        case "null":

// If the value is a boolean or null, convert it to a string. Note:
// typeof null does not produce "null". The case is included here in
// the remote chance that this gets fixed someday.

            return String(value);

// If the type is "object", we might be dealing with an object or an array or
// null.

        case "object":

// Due to a specification blunder in ECMAScript, typeof null is "object",
// so watch out for that case.

            if (!value) {
                return "null";
            }

// Make an array to hold the partial results of stringifying this object value.

            gap += indent;
            partial = [];

// Is the value an array?

            if (Object.prototype.toString.apply(value) === "[object Array]") {

// The value is an array. Stringify every element. Use null as a placeholder
// for non-JSON values.

                length = value.length;
                for (i = 0; i < length; i += 1) {
                    partial[i] = str(i, value) || "null";
                }

// Join all of the elements together, separated with commas, and wrap them in
// brackets.

                v = partial.length === 0
                    ? "[]"
                    : gap
                        ? (
                            "[\n"
                            + gap
                            + partial.join(",\n" + gap)
                            + "\n"
                            + mind
                            + "]"
                        )
                        : "[" + partial.join(",") + "]";
                gap = mind;
                return v;
            }

// If the replacer is an array, use it to select the members to be stringified.

            if (rep && typeof rep === "object") {
                length = rep.length;
                for (i = 0; i < length; i += 1) {
                    if (typeof rep[i] === "string") {
                        k = rep[i];
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (
                                (gap)
                                    ? ": "
                                    : ":"
                            ) + v);
                        }
                    }
                }
            } else {

// Otherwise, iterate through all of the keys in the object.

                for (k in value) {
                    if (Object.prototype.hasOwnProperty.call(value, k)) {
                        v = str(k, value);
                        if (v) {
                            partial.push(quote(k) + (
                                (gap)
                                    ? ": "
                                    : ":"
                            ) + v);
                        }
                    }
                }
            }

// Join all of the member texts together, separated with commas,
// and wrap them in braces.

            v = partial.length === 0
                ? "{}"
                : gap
                    ? "{\n" + gap + partial.join(",\n" + gap) + "\n" + mind + "}"
                    : "{" + partial.join(",") + "}";
            gap = mind;
            return v;
        }
    }

// If the JSON object does not yet have a stringify method, give it one.

    if (typeof JSON.stringify !== "function") {
        meta = {    // table of character substitutions
            "\b": "\\b",
            "\t": "\\t",
            "\n": "\\n",
            "\f": "\\f",
            "\r": "\\r",
            "\"": "\\\"",
            "\\": "\\\\"
        };
        JSON.stringify = function (value, replacer, space) {

// The stringify method takes a value and an optional replacer, and an optional
// space parameter, and returns a JSON text. The replacer can be a function
// that can replace values, or an array of strings that will select the keys.
// A default replacer method can be provided. Use of the space parameter can
// produce text that is more easily readable.

            var i;
            gap = "";
            indent = "";

// If the space parameter is a number, make an indent string containing that
// many spaces.

            if (typeof space === "number") {
                for (i = 0; i < space; i += 1) {
                    indent += " ";
                }

// If the space parameter is a string, it will be used as the indent string.

            } else if (typeof space === "string") {
                indent = space;
            }

// If there is a replacer, it must be a function or an array.
// Otherwise, throw an error.

            rep = replacer;
            if (replacer && typeof replacer !== "function" && (
                typeof replacer !== "object"
                || typeof replacer.length !== "number"
            )) {
                throw new Error("JSON.stringify");
            }

// Make a fake root object containing our value under the key of "".
// Return the result of stringifying the value.

            return str("", {"": value});
        };
    }


// If the JSON object does not yet have a parse method, give it one.

    if (typeof JSON.parse !== "function") {
        JSON.parse = function (text, reviver) {

// The parse method takes a text and an optional reviver function, and returns
// a JavaScript value if the text is a valid JSON text.

            var j;

            function walk(holder, key) {

// The walk method is used to recursively walk the resulting structure so
// that modifications can be made.

                var k;
                var v;
                var value = holder[key];
                if (value && typeof value === "object") {
                    for (k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            v = walk(value, k);
                            if (v !== undefined) {
                                value[k] = v;
                            } else {
                                delete value[k];
                            }
                        }
                    }
                }
                return reviver.call(holder, key, value);
            }


// Parsing happens in four stages. In the first stage, we replace certain
// Unicode characters with escape sequences. JavaScript handles many characters
// incorrectly, either silently deleting them, or treating them as line endings.

            text = String(text);
            rx_dangerous.lastIndex = 0;
            if (rx_dangerous.test(text)) {
                text = text.replace(rx_dangerous, function (a) {
                    return (
                        "\\u"
                        + ("0000" + a.charCodeAt(0).toString(16)).slice(-4)
                    );
                });
            }

// In the second stage, we run the text against regular expressions that look
// for non-JSON patterns. We are especially concerned with "()" and "new"
// because they can cause invocation, and "=" because it can cause mutation.
// But just to be safe, we want to reject all unexpected forms.

// We split the second stage into 4 regexp operations in order to work around
// crippling inefficiencies in IE's and Safari's regexp engines. First we
// replace the JSON backslash pairs with "@" (a non-JSON character). Second, we
// replace all simple value tokens with "]" characters. Third, we delete all
// open brackets that follow a colon or comma or that begin the text. Finally,
// we look to see that the remaining characters are only whitespace or "]" or
// "," or ":" or "{" or "}". If that is so, then the text is safe for eval.

            if (
                rx_one.test(
                    text
                        .replace(rx_two, "@")
                        .replace(rx_three, "]")
                        .replace(rx_four, "")
                )
            ) {

// In the third stage we use the eval function to compile the text into a
// JavaScript structure. The "{" operator is subject to a syntactic ambiguity
// in JavaScript: it can begin a block or an object literal. We wrap the text
// in parens to eliminate the ambiguity.

                j = eval("(" + text + ")");

// In the optional fourth stage, we recursively walk the new structure, passing
// each name/value pair to a reviver function for possible transformation.

                return (typeof reviver === "function")
                    ? walk({"": j}, "")
                    : j;
            }

// If the text is not JSON parseable, then a SyntaxError is thrown.

            throw new SyntaxError("JSON.parse");
        };
    }
}());

/* ---- end JSON polyfill ---- */

var TICKS_PER_SECOND = 254016000000; // Premiere's fixed tick rate

/* ============================ utilities ============================ */

var LOG = [];
function logMsg(msg, cls) { LOG.push({ msg: msg, cls: cls || "" }); }
function resetLog() { LOG = []; }

function reply(obj) {
  obj.log = LOG;
  return JSON.stringify(obj);
}

function safeParse(jsonArg) {
  try { return JSON.parse(decodeURIComponent(jsonArg)); } catch (e) {
    try { return JSON.parse(jsonArg); } catch (e2) { return {}; }
  }
}

function sanitize(name) {
  return String(name).replace(/[^A-Za-z0-9_\-]+/g, "_").replace(/^_+|_+$/g, "");
}

/* Like sanitize, but for user-facing FILE NAMES: spaces are allowed. Only
   characters that are actually illegal in a filename are removed. */
function fileSafe(name) {
  return String(name)
    .replace(/[\/\\:*?"<>|]/g, "")
    .replace(/[\x00-\x1f]/g, "")
    .replace(/\s+/g, " ")
    .replace(/^\s+|\s+$/g, "");
}

function ensureFolder(path) {
  var f = new Folder(path);
  if (!f.exists) {
    var parent = f.parent;
    if (parent && !parent.exists) ensureFolder(parent.fsName);
    f.create();
  }
  return f;
}

function sep() { return ($.os.indexOf("Windows") !== -1) ? "\\" : "/"; }

/* ---- project bins (where created sequences are filed) ---- */

function dateMMDD() {
  var d = new Date();
  return ("0" + (d.getMonth() + 1)).slice(-2) + ("0" + d.getDate()).slice(-2);
}

/* Current wall-clock time rounded to the nearest 5 minutes, 12-hour, no colon,
   e.g. 11:00 -> "1100am", 9:05 PM -> "905pm". Used to name per-run folders/bins. */
function runStamp() {
  var d = new Date();
  var mins = Math.round((d.getHours() * 60 + d.getMinutes()) / 5) * 5;
  mins = ((mins % 1440) + 1440) % 1440;            // wrap within the day
  var h24 = Math.floor(mins / 60), m = mins % 60;
  var ampm = h24 < 12 ? "am" : "pm";
  var h12 = h24 % 12; if (h12 === 0) h12 = 12;
  return "" + h12 + ("0" + m).slice(-2) + ampm;
}

function findBinByName(parent, name) {
  for (var i = 0; i < parent.children.numItems; i++) {
    var it = parent.children[i];
    try {
      if (it.type === ProjectItemType.BIN && it.name === name) return it;
    } catch (e) {}
  }
  return null;
}

function getOrCreateBin(parent, name) {
  var existing = findBinByName(parent, name);
  if (existing) return existing;
  return parent.createBin(name);
}

/* Returns 07_Prep / Deckhand_<kind>_MMDD, creating either if missing. */
function getDeckhandBin(kind) {
  var root = app.project.rootItem;
  var prep = getOrCreateBin(root, "07_Prep");
  return getOrCreateBin(prep, "STN_" + kind + "_" + dateMMDD());
}
function getPrepBin() { return getDeckhandBin("Prep"); }

/* ---- timecode ---- */

function fpsFromSeq(seq) {
  return TICKS_PER_SECOND / Number(seq.timebase); // e.g. 23.976, 24, 25, 29.97
}
function tcInfo(fps) {
  var nominal = Math.round(fps);
  var df = (Math.abs(fps - 29.97) < 0.05) || (Math.abs(fps - 59.94) < 0.05);
  return { nominal: nominal, df: df };
}
function pad2(n) { return (n < 10 ? "0" : "") + n; }

/* Convert an absolute frame count to a CMX3600 timecode string. */
function framesToTC(frames, info) {
  frames = Math.round(frames);
  var fps = info.nominal;
  var sepChar = ":";
  if (info.df) {
    // Standard SMPTE drop-frame algorithm.
    var dropPerMin = Math.round(fps * 0.066666); // 2 @29.97, 4 @59.94
    var framesPer10Min = fps * 60 * 10 - 9 * dropPerMin;
    var framesPerMin = fps * 60 - dropPerMin;
    var d = Math.floor(frames / framesPer10Min);
    var m = frames % framesPer10Min;
    if (m > dropPerMin) {
      frames += dropPerMin * 9 * d +
                dropPerMin * Math.floor((m - dropPerMin) / framesPerMin);
    } else {
      frames += dropPerMin * 9 * d;
    }
    sepChar = ";";
  }
  var fr = frames % fps;
  var totalSec = Math.floor(frames / fps);
  var s = totalSec % 60;
  var mn = Math.floor(totalSec / 60) % 60;
  var h = Math.floor(totalSec / 3600) % 24;
  return pad2(h) + ":" + pad2(mn) + ":" + pad2(s) + sepChar + pad2(fr);
}

function ticksToFrames(ticksStr, ticksPerFrame) {
  return Number(ticksStr) / ticksPerFrame;
}

/* ============================ browse ============================ */

function DH_browse(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  try {
    if (a.kind === "folder") {
      var fol = Folder.selectDialog("Choose output folder");
      return reply({ ok: !!fol, path: fol ? fol.fsName : "" });
    } else {
      // Windows wants a string mask; macOS wants a filter function.
      var mask = ($.os.indexOf("Windows") !== -1)
        ? "Adobe Encoder Preset:*.epr"
        : function (f) { return (f instanceof Folder) || /\.epr$/i.test(f.name); };
      var fil = File.openDialog("Choose .epr preset", mask);
      return reply({ ok: !!fil, path: fil ? fil.fsName : "" });
    }
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* ============================ presets ============================ */

function listEprFilesRecursive(folder, out, depth) {
  if (!folder || !folder.exists || depth > 6) return;
  var items;
  try { items = folder.getFiles(); } catch (e) { return; }
  for (var i = 0; i < items.length; i++) {
    var it = items[i];
    if (it instanceof Folder) {
      listEprFilesRecursive(it, out, depth + 1);
    } else if (/\.epr$/i.test(it.name)) {
      out.push(it);
    }
  }
}

/* Scan the standard AME preset locations for user .epr presets. */
/* Lists .epr files from the extension's own bundled Presets folder.
   The panel passes its path (cs.getSystemPath(EXTENSION) + "/Presets"). */
function DH_listPresets(jsonArg) {
  resetLog();
  try {
    var a = safeParse(jsonArg);
    var dir = a.dir || "";
    var folder = new Folder(dir);
    if (!folder.exists && dir) {
      try { folder = new Folder(decodeURIComponent(dir)); } catch (e) {}
    }

    var files = [];
    listEprFilesRecursive(folder, files, 0);

    var seen = {}, presets = [];
    for (var f = 0; f < files.length; f++) {
      var p = files[f].fsName;
      if (seen[p]) continue;
      seen[p] = true;
      presets.push({ name: String(files[f].displayName).replace(/\.epr$/i, ""), path: p });
    }
    presets.sort(function (x, y) {
      var xn = x.name.toLowerCase(), yn = y.name.toLowerCase();
      return xn < yn ? -1 : (xn > yn ? 1 : 0);
    });
    return reply({ ok: true, presets: presets, dir: folder.fsName });
  } catch (e) {
    return reply({ ok: false, error: String(e), presets: [] });
  }
}

/* ============================ clone ============================ */

/* Capture existing sequence IDs, clone the active sequence, then find
   the new one by diffing IDs (clone() returns a boolean, not the seq). */
function cloneActiveSequence(label, targetBin) {
  var proj = app.project;
  var before = {};
  for (var i = 0; i < proj.sequences.numSequences; i++) {
    before[proj.sequences[i].sequenceID] = true;
  }
  var src = proj.activeSequence;
  if (!src) return null;

  var ok = src.clone();
  if (!ok) return null;

  var found = null;
  for (var j = 0; j < proj.sequences.numSequences; j++) {
    var s = proj.sequences[j];
    if (!before[s.sequenceID]) { found = s; break; }
  }
  if (found) {
    try { found.name = src.name + " — " + label; } catch (e) {}
    try { found.projectItem.name = src.name + " — " + label; } catch (e2) {}
    if (targetBin) { try { found.projectItem.moveBin(targetBin); } catch (e3) {} }
  }
  return found;
}

/* ==================== track ranges (graphics / burn-in) ==================== */

function activate(seq) { try { app.project.activeSequence = seq; } catch (e) {} }

/* Enable/disable every trackItem on video tracks low..high (1-based, inclusive). */
function setTrackRangeDisabled(seq, low, high, disabled) {
  var count = 0;
  for (var t = low - 1; t <= high - 1; t++) {
    if (t < 0 || t >= seq.videoTracks.numTracks) continue;
    var track = seq.videoTracks[t];
    for (var c = 0; c < track.clips.numItems; c++) {
      try { track.clips[c].disabled = disabled; count++; } catch (e) {}
    }
  }
  return count;
}

/* Deletes empty video/audio tracks from a sequence via QE (the DOM has no
   track-removal API). Uses the same method probing proven by Collapse Video
   Tracks: deleteVideoTrack/removeVideoTrack, scanned top-down so lower indices
   stay valid, never touching V1/A1 (index 0). Track deletion isn't broadly
   scriptable, so failures are swallowed per-track. Returns counts. */
function removeEmptyTracks(seq) {
  var vRemoved = 0, aRemoved = 0, qseq = null;
  try { app.enableQE(); qseq = qe.project.getActiveSequence(); } catch (e) {}
  if (!qseq) return { v: 0, a: 0 };

  var v;
  for (v = seq.videoTracks.numTracks - 1; v >= 1; v--) {
    var vt = seq.videoTracks[v], vEmpty = false;
    try { vEmpty = (vt.clips.numItems === 0); } catch (e1) {}
    if (!vEmpty) continue;
    var vDone = false;
    try { if (typeof qseq.deleteVideoTrack === "function") { qseq.deleteVideoTrack(v); vDone = true; } } catch (e2) {}
    if (!vDone) { try { if (typeof qseq.removeVideoTrack === "function") { qseq.removeVideoTrack(v); vDone = true; } } catch (e3) {} }
    if (vDone) vRemoved++;
  }

  var a;
  for (a = seq.audioTracks.numTracks - 1; a >= 1; a--) {
    var at = seq.audioTracks[a], aEmpty = false;
    try { aEmpty = (at.clips.numItems === 0); } catch (e4) {}
    if (!aEmpty) continue;
    var aDone = false;
    try { if (typeof qseq.deleteAudioTrack === "function") { qseq.deleteAudioTrack(a); aDone = true; } } catch (e5) {}
    if (!aDone) { try { if (typeof qseq.removeAudioTrack === "function") { qseq.removeAudioTrack(a); aDone = true; } } catch (e6) {} }
    if (aDone) aRemoved++;
  }
  return { v: vRemoved, a: aRemoved };
}

/* Removes every audio clip from a clone, so color/finish prep XMLs carry no
   audio. Iterates backwards because removing reindexes the collection. */
function removeAllAudioClips(seq) {
  var removed = 0;
  for (var t = 0; t < seq.audioTracks.numTracks; t++) {
    var track = seq.audioTracks[t];
    for (var c = track.clips.numItems - 1; c >= 0; c--) {
      try { track.clips[c].remove(false, false); removed++; } catch (e) {}
    }
  }
  return removed;
}

/* Removes the Harbor Slate MOGRT clip from a clone, wherever it sits, so it
   never serializes into a prep XML. Matches by clip name (harbor/slate).
   Returns the count removed. */
function removeSlateMogrt(seq) {
  var removed = 0;
  for (var t = seq.videoTracks.numTracks - 1; t >= 0; t--) {
    var track = seq.videoTracks[t];
    for (var c = track.clips.numItems - 1; c >= 0; c--) {
      var clip = track.clips[c], nm = "";
      try { nm = String(clip.name); } catch (e) {}
      if (/harbor|slate/i.test(nm)) {
        try { clip.remove(false, false); removed++; } catch (e2) {}
      }
    }
  }
  return removed;
}

/* Hard-delete every trackItem on video tracks low..high (1-based, inclusive).
   Used for the TC burn-in range on clones that feed XML/EDL — a *disabled*
   clip still serializes into FCP7 XML, so it must actually be removed. */
function removeTrackRangeClips(seq, low, high) {
  var count = 0;
  for (var t = low - 1; t <= high - 1; t++) {
    if (t < 0 || t >= seq.videoTracks.numTracks) continue;
    var track = seq.videoTracks[t];
    for (var c = track.clips.numItems - 1; c >= 0; c--) {
      try { track.clips[c].remove(false, false); count++; } catch (e) {}
    }
  }
  return count;
}

/* Intrinsic (fixed) components that must survive an effect strip. */
var DH_KEEP_FX = {
  "AE.ADBE Motion": true,
  "AE.ADBE Opacity": true,
  "AE.ADBE Time Remapping": true,
  "AE.ADBE Fixed To Parametric": true,
  "AE.ADBE Vector Motion": true
};

/* Removes every non-intrinsic effect from a clip. Iterates backwards because
   removing a component reindexes the collection. */
function stripClipEffects(clip) {
  var removed = 0;
  try {
    var comps = clip.components;
    for (var i = comps.numItems - 1; i >= 0; i--) {
      var comp = comps[i], mn = "", dn = "";
      try { mn = String(comp.matchName); } catch (e) {}
      try { dn = String(comp.displayName); } catch (e2) {}
      if (DH_KEEP_FX[mn] === true) continue;
      if (dn === "Motion" || dn === "Opacity" || dn === "Time Remapping") continue;
      try { comp.remove(); removed++; } catch (e3) {}
    }
  } catch (e4) {}
  return removed;
}

/* Recenters Motion > Position to the frame center (normalized 0.5, 0.5). */
function centerClipPosition(clip) {
  var set = false;
  try {
    var comps = clip.components;
    for (var ci = 0; ci < comps.numItems; ci++) {
      var comp = comps[ci], mn = "", dn = "";
      try { mn = String(comp.matchName); } catch (e) {}
      try { dn = String(comp.displayName); } catch (e2) {}
      if (mn !== "AE.ADBE Motion" && dn !== "Motion") continue;
      var props = comp.properties;
      for (var pi = 0; pi < props.numItems; pi++) {
        var p = props[pi], pdn = "";
        try { pdn = String(p.displayName); } catch (e3) {}
        if (pdn === "Position") {
          try { p.setValue([0.5, 0.5], true); set = true; } catch (e4) {}
        }
      }
    }
  } catch (e5) {}
  return set;
}

/* Reads a clip's native media dimensions from its projectItem metadata.
   Returns {w,h} or null. */
function getMediaDims(clip) {
  try {
    var pi = clip.projectItem;
    if (!pi) return null;
    var md = pi.getProjectMetadata();
    if (!md) return null;
    var m = String(md).match(/VideoInfo[^>]*>\s*([0-9]+)\s*[x\u00D7]\s*([0-9]+)/i);
    if (m) {
      var w = parseInt(m[1], 10), h = parseInt(m[2], 10);
      if (w > 0 && h > 0) return { w: w, h: h };
    }
  } catch (e) {}
  return null;
}

/* True "Set to Frame Size": computes the scale that fits the clip's full native
   image inside the sequence frame and writes it to Motion > Scale (per-instance,
   non-destructive). Assumes square pixels. Returns true if Scale was set. */
function fitClipToFrame(clip, seqW, seqH) {
  var dims = getMediaDims(clip);
  if (!dims) return false;
  var fit = Math.min(seqW / dims.w, seqH / dims.h) * 100;
  fit = Math.round(fit * 10000) / 10000;
  var set = false;
  try {
    var comps = clip.components;
    for (var ci = 0; ci < comps.numItems; ci++) {
      var comp = comps[ci];
      var mn = "", dn = "";
      try { mn = String(comp.matchName); } catch (e) {}
      try { dn = String(comp.displayName); } catch (e2) {}
      if (mn === "AE.ADBE Motion" || dn === "Motion") {
        var props = comp.properties;
        for (var pi = 0; pi < props.numItems; pi++) {
          var p = props[pi], pdn = "";
          try { pdn = String(p.displayName); } catch (e3) {}
          if (pdn === "Scale") { try { p.setValue(fit, true); set = true; } catch (e4) {} }
        }
      }
    }
  } catch (e5) {}
  return set;
}

/* ============================ exports ============================ */

/* Validates that a preset path is set and the .epr actually exists on disk.
   Returns true only when it's safe to hand to AME. */
function presetUsable(presetPath) {
  if (!presetPath) return false;
  var s = String(presetPath);
  if (s.replace(/^\s+|\s+$/g, "") === "") return false;
  try { if (!(new File(presetPath)).exists) return false; } catch (e) {}
  return true;
}

/* In/out marks on the master sequence for the current prep run, or null when
   none are set. Reference movies honour them (AME "Sequence In/Out"). */
var PREP_RANGE = null;
/* Seconds from sequence start -> HH:MM:SS:FF including the sequence's start TC. */
function framesToTCsafe(seq, sec) {
  try {
    var tpf = Number(seq.timebase), zero = Number(seq.zeroPoint) || 0;
    var fps = Math.round(TICKS_PER_SECOND / tpf);
    var f = Math.round((sec * TICKS_PER_SECOND + zero) / tpf);
    function p(n) { return (n < 10 ? "0" : "") + n; }
    return p(Math.floor(f / (fps * 3600))) + ":" + p(Math.floor(f / (fps * 60)) % 60) + ":" + p(Math.floor(f / fps) % 60) + ":" + p(f % fps);
  } catch (e) { return sec.toFixed(2) + "s"; }
}
function readMarkedRange(seq) {
  try {
    var inS = Number(seq.getInPointAsTime().seconds);
    var outS = Number(seq.getOutPointAsTime().seconds);
    var endS = seqEndSeconds(seq);
    if (!(outS > inS)) return null;
    if (inS > 0.0005 || (endS > 0 && outS < endS - 0.0005)) return { inSec: inS, outSec: outS };
  } catch (e) {}
  return null;
}

function exportReference(seq, presetPath, outPath) {
  // Queues an async render in Adobe Media Encoder. A missing/empty/invalid
  // preset skips THIS deliverable only — it must never abort the whole run.
  if (!presetUsable(presetPath)) return null;
  try {
    app.encoder.launchEncoder();
    // encodeSequence(seq, outputPath, presetPath, workArea, removeWhenDone)
    // workArea 0 = entire sequence, 1 = in to out. removeWhenDone 1 = tidy AME queue.
    // When the master has in/out marks, copy them onto this clone and render
    // only that range.
    var workArea = 0;
    if (PREP_RANGE) {
      try {
        seq.setInPoint(PREP_RANGE.inSec);
        seq.setOutPoint(PREP_RANGE.outSec);
        workArea = 1;
        try { app.project.save(); } catch (es) {}   // flush the marks to AME
      } catch (er) { logMsg("⚠ Couldn't apply the in/out to " + seq.name + " — rendering the whole sequence.", "warn"); }
    }
    var jobID = app.encoder.encodeSequence(seq, outPath, presetPath, workArea, 1);
    app.encoder.startBatch();
    return jobID;
  } catch (e2) { return null; }
}

function exportFcpXml(seq, outPath) {
  return seq.exportAsFinalCutProXML(outPath, 1); // 1 = suppress UI
}

function exportOMF(seq, outPath, omfTitle, handleFrames) {
  // app.project.exportOMF(seq, path, OMFTitle, sampleRate, bitsPerSample,
  //   audioEncapsulated(1=embed), audioFileFormat(0=AIFF,1=WAV),
  //   trimAudioFiles(1=trim), handleFrames, includePan(1=include))
  return app.project.exportOMF(
    seq, outPath,
    omfTitle,   // OMF title = sequence name
    48000,      // sampleRate
    16,         // bitsPerSample
    1,          // audioEncapsulated — embed audio
    0,          // audioFileFormat — AIFF (standard for embedded OMF)
    1,          // trimAudioFiles
    handleFrames,
    1           // includePan
  );
}

/* ---- EDL generator: one CMX3600 file per video track ---- */

function trackReelName(clip) {
  var name = clip.name;
  try {
    var pi = clip.projectItem;
    if (pi) {
      var mp = pi.getMediaPath();
      if (mp) { var parts = mp.split(/[\\\/]/); name = parts[parts.length - 1]; }
    }
  } catch (e) {}
  var base = sanitize(name).toUpperCase();
  return base.substr(0, 8) || "TAPE";
}

/* Returns { written:[paths], warnings:[strings] }.
   Iterates every video track; clips disabled on the clone (stripped graphics,
   burn-in tracks) are skipped, so the EDLs carry exactly the conform content. */
function generateEDLs(seq, outDir, spot) {
  var info = tcInfo(fpsFromSeq(seq));
  var ticksPerFrame = Number(seq.timebase);
  var zeroFrames = 0;
  try { zeroFrames = ticksToFrames(seq.zeroPoint, ticksPerFrame); } catch (e) {}

  var fcm = info.df ? "DROP FRAME" : "NON-DROP FRAME";
  var written = [], warnings = [];

  for (var t = 0; t < seq.videoTracks.numTracks; t++) {
    var track = seq.videoTracks[t];
    if (track.clips.numItems === 0) continue;

    // Transition presence is a v1 caveat (treated as cuts).
    try {
      if (track.transitions && track.transitions.numItems > 0) {
        warnings.push("V" + (t + 1) + ": " + track.transitions.numItems +
          " transition(s) written as straight cuts — verify dissolves.");
      }
    } catch (eT) {}

    var lines = [];
    lines.push("TITLE:   " + sanitize(spot) + "_V" + (t + 1));
    lines.push("FCM: " + fcm);

    var evt = 0;
    for (var c = 0; c < track.clips.numItems; c++) {
      var clip = track.clips[c];
      if (clip.disabled) continue;

      // Speed changes make source TC unreliable — flag, still write nominal.
      try {
        if (typeof clip.speed !== "undefined" && Math.abs(clip.speed - 1) > 0.001) {
          warnings.push("V" + (t + 1) + " \"" + clip.name +
            "\": speed " + clip.speed + " — source TC is nominal, verify.");
        }
      } catch (eS) {}

      var srcIn  = ticksToFrames(clip.inPoint.ticks,  ticksPerFrame);
      var srcOut = ticksToFrames(clip.outPoint.ticks, ticksPerFrame);
      var recIn  = ticksToFrames(clip.start.ticks,    ticksPerFrame) + zeroFrames;
      var recOut = ticksToFrames(clip.end.ticks,      ticksPerFrame) + zeroFrames;

      evt++;
      var num = ("00" + evt).slice(-3);
      var reel = (trackReelName(clip) + "        ").substr(0, 8);
      lines.push(
        num + "  " + reel + " V     C        " +
        framesToTC(srcIn, info)  + " " + framesToTC(srcOut, info) + " " +
        framesToTC(recIn, info)  + " " + framesToTC(recOut, info)
      );
      lines.push("* FROM CLIP NAME: " + clip.name);
    }

    if (evt === 0) continue;

    var path = outDir + sep() + sanitize(spot) + "_V" + (t + 1) + ".edl";
    var f = new File(path);
    f.encoding = "UTF-8";
    f.open("w");
    f.write(lines.join("\n") + "\n");
    f.close();
    written.push(path);
  }
  return { written: written, warnings: warnings };
}

/* ---- Asset collection: copy source media from a video track range ----
   Files land in <dest>/Media/<subFolder> (e.g. Media/GFX, Media/Video). ---- */

function collectTrackAssets(seq, lowV, highV, destDir, subFolder) {
  var mediaDir = destDir + sep() + "Media";
  ensureFolder(mediaDir);
  if (subFolder) { mediaDir = mediaDir + sep() + subFolder; ensureFolder(mediaDir); }
  var seen = {}, copied = 0, skipped = 0;
  for (var t = lowV - 1; t <= highV - 1; t++) {
    if (t < 0 || t >= seq.videoTracks.numTracks) continue;
    var track = seq.videoTracks[t];
    for (var c = 0; c < track.clips.numItems; c++) {
      var clip = track.clips[c];
      try {
        var pi = clip.projectItem;
        if (!pi) continue;
        var mp = pi.getMediaPath();
        if (!mp || seen[mp]) continue;
        seen[mp] = true;
        var srcFile = new File(mp);
        if (!srcFile.exists) { skipped++; continue; }
        var destFile = new File(mediaDir + sep() + srcFile.name);
        if (destFile.exists) { skipped++; continue; } // don't overwrite
        srcFile.copy(destFile);
        copied++;
      } catch (e) { skipped++; }
    }
  }
  return { copied: copied, skipped: skipped };
}

/* ============================ orchestrator ============================ */

function deliverTeam(team, cfg, ctx) {
  var label = team.charAt(0).toUpperCase() + team.slice(1);
  // Grouped: <out>/<Department>/<sequence run>/ · Default: <out>/<run>/<Department>/
  var dir = ctx.group ? (ctx.outFolder + sep() + label + sep() + ctx.runName)
                      : (ctx.baseDir + sep() + label);
  ensureFolder(dir);
  var stem = dir + sep() + ctx.seqSafe;   // no team label — the folder already names the department

  // Shared reference viewing copy — every prep button produces one. Graphics
  // stay on; the TC burn-in tracks (Track layout) are hidden. No "Reference"
  // in the filename. Burn-ins can only be hidden on a clone, since AME renders
  // the clone's state asynchronously and we must not touch the master.
  if (presetUsable(cfg.presetReference) || (team === "audio" && cfg.audioBurn && presetUsable(cfg.presetBurn))) {
    var refPath = dir + sep() + ctx.seqSafe + ".mov";
    if (team === "audio" && cfg.audioBurn && presetUsable(cfg.presetBurn)) {
      // Audio "Burn-in reference": timecode burn-ins visible, TC burn-in preset.
      activate(ctx.master);
      var rb = cloneActiveSequence(label + " RefTC", ctx.prepBin);
      var burnPath = dir + sep() + ctx.seqSafe + "_tc.mov";
      if (rb) { activate(rb); exportReference(rb, cfg.presetBurn, burnPath); }
      else exportReference(ctx.master, cfg.presetBurn, burnPath);
      logMsg("• Audio: reference + TC burn-in queued in AME.", "");
    } else if (cfg.burnOn) {
      activate(ctx.master);
      var rc = cloneActiveSequence(label + " Ref", ctx.prepBin);
      if (rc) {
        setTrackRangeDisabled(rc, cfg.burnLow, cfg.burnHigh, true);
        activate(rc);
        exportReference(rc, cfg.presetReference, refPath);
      } else {
        logMsg("⚠ " + label + ": ref clone failed; exported with burn-ins visible.", "warn");
        exportReference(ctx.master, cfg.presetReference, refPath);
      }
      logMsg("• " + label + ": reference queued in AME.", "");
    } else {
      exportReference(ctx.master, cfg.presetReference, refPath);
      logMsg("• " + label + ": reference queued in AME.", "");
    }
  } else {
    logMsg("• " + label + ": no reference preset selected — reference skipped.", "warn");
  }

  // Color strips graphics; Finish keeps them.
  var stripGfx = (team === "color") && cfg.gfxOn;

  if (team === "audio") {
    // Audio delivers the shared Reference export (queued above) plus an OMF.
    // No clean-reference clone — the OMF is written straight from the master
    // (picture state is irrelevant to an audio-only OMF).
    var omfOk = exportOMF(ctx.master, stem + ".omf", ctx.seqRaw, cfg.omfHandles);
    logMsg(omfOk === 0 ? "✓ Audio: OMF written (\"" + ctx.seqRaw + "\", " + cfg.omfHandles + "f handles)."
                       : "⚠ Audio: OMF returned code " + omfOk + ".",
           omfOk === 0 ? "ok" : "warn");
    return;
  }

  /* ---- CLEAN clone: graphics per team, burn-in OFF ----
     Drives the clean reference, the FCP7 XML, and the EDLs. */
  activate(ctx.master);
  var cc = cloneActiveSequence(label + " Clean", ctx.prepBin);
  if (!cc) { logMsg("✗ " + label + ": could not clone.", "err"); return; }
  if (stripGfx) {
    // Color XML must not carry Graphics/Comps at all — disabled clips still
    // serialize into FCP7 XML, so remove them outright on the XML/EDL clone.
    var ng = removeTrackRangeClips(cc, cfg.gfxLow, cfg.gfxHigh);
    logMsg("• " + label + ": graphics/comps removed V" + cfg.gfxLow + "–V" + cfg.gfxHigh +
           " (" + ng + " clip(s)) — excluded from XML/EDL.", "");
  }
  // TC burn-ins are *removed*, not just disabled: FCP7 XML serializes disabled
  // clips, so the prep XML would still carry the burn-in track content.
  if (cfg.burnOn) {
    var nb = removeTrackRangeClips(cc, cfg.burnLow, cfg.burnHigh);
    logMsg("• " + label + ": TC burn-ins removed V" + cfg.burnLow + "–V" + cfg.burnHigh +
           " (" + nb + " clip(s)) — excluded from XML/EDL.", "");
  }
  // Slate MOGRT is excluded from every prep XML (color and finish).
  if (team === "color" || team === "finish") {
    var nsl = removeSlateMogrt(cc);
    if (nsl > 0) logMsg("• " + label + ": slate MOGRT removed (" + nsl +
                        " clip(s)) — excluded from XML.", "");
    // Color/finish XMLs are picture-only — strip all audio.
    var na = removeAllAudioClips(cc);
    if (na > 0) logMsg("• " + label + ": audio removed (" + na +
                       " clip(s)) — excluded from XML/EDL.", "");
  }
  activate(cc);

  // Color & Finish XML: strip empty tracks so the FCP7 XML carries only tracks
  // with content. QE targets the active sequence, so cc must be active (it is).
  if (team === "color" || team === "finish") {
    var et = removeEmptyTracks(cc);
    if (et.v || et.a) logMsg("• " + label + ": removed " + et.v + " empty video / " + et.a +
                             " empty audio track(s) before XML.", "");
  }

  if (team !== "finish") {
    if (presetUsable(cfg.presetClean)) {
      exportReference(cc, cfg.presetClean, stem + "_clean.mov");
      logMsg("• " + label + ": clean reference queued in AME.", "");
    } else {
      logMsg("• " + label + ": no clean preset selected — clean reference skipped.", "warn");
    }
  }
  exportFcpXml(cc, stem + ".xml");
  logMsg("✓ " + label + ": FCP7 XML written.", "ok");
  var edl = generateEDLs(cc, dir, ctx.seqSafe);
  logMsg("✓ " + label + ": " + edl.written.length + " EDL(s) written.", "ok");
  for (var w = 0; w < edl.warnings.length; w++) logMsg("⚠ " + edl.warnings[w], "warn");

  /* ---- BURN clone: graphics per team, burn-in ON ----
     A separate clone is required: AME renders asynchronously against the
     clone's final state, so one toggled clone would render both refs alike. */
  if (cfg.burnOn) {
    if (!presetUsable(cfg.presetBurn)) {
      logMsg("• " + label + ": no burn-in preset selected — _tc export skipped.", "warn");
    } else {
      activate(ctx.master);
      var bc = cloneActiveSequence(label + " Burn", ctx.prepBin);
      if (!bc) { logMsg("⚠ " + label + ": burn clone failed; skipped TC ref.", "warn"); return; }
      if (stripGfx) setTrackRangeDisabled(bc, cfg.gfxLow, cfg.gfxHigh, true);
      // burn-in tracks left enabled
      activate(bc);
      exportReference(bc, cfg.presetBurn, stem + "_tc.mov");
      logMsg("• " + label + ": burn-in reference queued in AME.", "");
    }
  } else {
    logMsg("• " + label + ": TC burn-ins off — no _tc export.", "");
  }

  // Collect source media for Finish when enabled.
  if (team === "finish" && cfg.collectVideo && cfg.clipsOn) {
    var vid = collectTrackAssets(ctx.master, cfg.clipsLow, cfg.clipsHigh, dir, "Video");
    logMsg("✓ Finish: " + vid.copied + " video asset(s) copied to Media/Video" +
           (vid.skipped > 0 ? " (" + vid.skipped + " skipped)" : "") + ".", "ok");
  }
  if (team === "finish" && cfg.collectGfx && cfg.gfxOn) {
    var gfx = collectTrackAssets(ctx.master, cfg.gfxLow, cfg.gfxHigh, dir, "GFX");
    logMsg("✓ Finish: " + gfx.copied + " GFX asset(s) copied to Media/GFX" +
           (gfx.skipped > 0 ? " (" + gfx.skipped + " skipped)" : "") + ".", "ok");
  }

  // Color Submaster: a third color clone with content-track clips fit to frame.
  if (team === "color" && cfg.colorSubmaster) {
    if (!cfg.presetSubmaster) {
      logMsg("⚠ Color Submaster checked but no submaster preset selected — skipped.", "warn");
    } else {
      activate(ctx.master);
      // Optional upscale of the submaster sequence before fitting clips to frame.
      var resW = 0, resH = 0, resTag = "";
      if (cfg.colorSubmaster4k === true)      { resW = 4096; resH = 2160; resTag = "4K"; }
      else if (cfg.colorSubmaster2k === true) { resW = 2560; resH = 1440; resTag = "2K"; }

      var smLabel = "Color Submaster" + (resTag ? " " + resTag : "");
      var sm = cloneActiveSequence(smLabel, ctx.prepBin);
      if (!sm) { logMsg("⚠ Color Submaster: could not clone.", "warn"); }
      else {
        // Strip graphics + burn-ins like the clean master.
        if (cfg.gfxOn)  setTrackRangeDisabled(sm, cfg.gfxLow, cfg.gfxHigh, true);
        if (cfg.burnOn) setTrackRangeDisabled(sm, cfg.burnLow, cfg.burnHigh, true);

        // Resize the sequence frame via the documented getSettings/setSettings API.
        if (resW) {
          try {
            var st = sm.getSettings();
            st.videoFrameWidth  = resW;
            st.videoFrameHeight = resH;
            sm.setSettings(st);
            logMsg("• Submaster: frame size set to " + resW + "×" + resH + ".", "");
          } catch (eSz) { logMsg("⚠ Submaster: could not set frame size: " + eSz, "warn"); }
        }

        // Every clip in the submaster gets a clean slate: all effects removed,
        // Position recentered, Scale fit to the (possibly resized) frame.
        var fs = sm.getSettings();
        var seqW = Number(fs.videoFrameWidth)  || 1920;
        var seqH = Number(fs.videoFrameHeight) || 1080;
        var fitN = 0, skipN = 0, fxN = 0, ctrN = 0;
        for (var ft = 0; ft < sm.videoTracks.numTracks; ft++) {
          var ftr = sm.videoTracks[ft];
          for (var fc = 0; fc < ftr.clips.numItems; fc++) {
            var sc = ftr.clips[fc];
            fxN += stripClipEffects(sc);
            if (centerClipPosition(sc)) ctrN++;
            if (fitClipToFrame(sc, seqW, seqH)) fitN++; else skipN++;
          }
        }
        logMsg("• Submaster: " + fxN + " effect(s) removed, " + ctrN + " clip(s) centered, " +
               fitN + " fit to " + seqW + "×" + seqH +
               (skipN ? " (" + skipN + " skipped — no media size)" : "") + ".", "");

        activate(sm);
        var smStem = dir + sep() + ctx.seqSafe + "_ColorSub" + (resTag ? "_" + resTag : "");
        exportReference(sm, cfg.presetSubmaster, smStem + ".mov");
        // No submaster XML/EDL — the regular color XML + EDLs cover the conform.
        logMsg("✓ Color Submaster: reference queued.", "ok");
      }
    }
  }
}

function deliverCore(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var cfg = a.config || {};
  var team = a.team;

  if (!app.project) return reply({ ok: false, error: "No project open." });
  if (!app.project.activeSequence) return reply({ ok: false, error: "No active sequence." });

  try {
    var master = app.project.activeSequence;
    var seqRaw = (cfg.seqName && cfg.seqName !== "(no sequence open)") ? cfg.seqName : master.name;
    var seqSafe = sanitize(seqRaw) || "Sequence";
    var runName = seqSafe + "_prep_" + dateMMDD() + "_" + runStamp();
    var baseDir = cfg.outFolder + sep() + runName;  // per-run subfolder (default layout)
    if (cfg.groupByDept !== true) {
      ensureFolder(baseDir);
    }

    PREP_RANGE = readMarkedRange(master);
    if (PREP_RANGE) logMsg("• Reference movies use the sequence In/Out (" + framesToTCsafe(master, PREP_RANGE.inSec) + " – " + framesToTCsafe(master, PREP_RANGE.outSec) + ").", "");
    else logMsg("• No In/Out set — reference movies cover the whole sequence.", "");

    var ctx = {
      master:  master,
      baseDir: baseDir,
      prepBin: getOrCreateBin(getPrepBin(), runName),       // clones grouped per run
      seqRaw:  seqRaw,
      seqSafe: seqSafe,
      group:   (cfg.groupByDept === true),                  // department-first folders
      outFolder: cfg.outFolder,
      runName: runName
    };

    var teams = (team === "all") ? ["color", "finish", "audio"] : [team];
    for (var i = 0; i < teams.length; i++) deliverTeam(teams[i], cfg, ctx);
    return reply({ ok: true });
  } catch (e) {
    return reply({ ok: false, error: String(e) + (e.line ? " (line " + e.line + ")" : "") });
  }
}


/* ==================== Prep: multi-sequence fan-out ====================
   Same rule as the Slate page: act on the active sequence, unless 2+ sequences
   are selected in the Project panel. The prep cores read app.project
   .activeSequence (and QE's getActiveSequence), so each target is activated in
   turn and the original active sequence restored afterwards. Folder layout is
   untouched \u2014 both the grouped and default layouts already key off each run's
   own sequence name, so grouped gives <out>/<Dept>/<seq>_prep_<stamp>/ per
   sequence and default gives <out>/<run>/<Dept>/. ==================== */

function panelTargets() { return slateTargets(); }

/* Runs a *Core across every target, merging their logs. coreFn(argString, seq)
   must return a reply() JSON string. */
function runAcrossTargets(argString, coreFn, mutateArg) {
  var targets = panelTargets();
  if (!targets.length) return JSON.stringify({ ok: false, error: "No active sequence.", log: [] });

  var multi = targets.length > 1;
  var prev = null;
  try { prev = app.project.activeSequence; } catch (e) {}

  var mergedLog = [], okCount = 0, failures = [], last = null, i;

  for (i = 0; i < targets.length; i++) {
    var seq = targets[i], nm = seqName(seq), parsed = null;
    if (multi) {
      mergedLog.push({ msg: "\u2500\u2500 [" + (i + 1) + "/" + targets.length + "] " + nm + " \u2500\u2500", cls: "" });
    }
    try {
      activate(seq);
      var arg = mutateArg ? mutateArg(argString, seq, multi) : argString;
      var raw = coreFn(arg);
      parsed = JSON.parse(raw);
    } catch (e2) {
      parsed = { ok: false, error: String(e2), log: [] };
    }
    if (parsed.log) { for (var k = 0; k < parsed.log.length; k++) mergedLog.push(parsed.log[k]); }
    if (parsed.ok) { okCount++; last = parsed; }
    else failures.push({ seq: nm, error: parsed.error || "failed" });
  }

  if (prev) activate(prev);

  var out = multi ? {} : (last || {});
  out.ok = okCount > 0;
  out.log = mergedLog;
  out.total = targets.length;
  out.updated = okCount;
  out.failures = failures;
  if (!okCount) out.error = failures.length ? failures[0].error : "Nothing ran.";
  /* Track-selector shifting only makes sense against a single sequence. */
  if (multi && out.removedTracks) out.removedTracks = null;
  return JSON.stringify(out);
}

/* Each run must be named for its OWN sequence, not the name sitting in the
   panel's Sequence Name field (which tracks the active sequence only). */
function prepArgForSeq(argString, seq, multi) {
  if (!multi) return argString;
  var a = safeParse(argString);
  if (!a.config) a.config = {};
  a.config.seqName = seqName(seq);
  return JSON.stringify(a);
}

function DH_deliver(jsonArg) {
  return runAcrossTargets(jsonArg, deliverCore, prepArgForSeq);
}
function DH_collapseVideoTracks(jsonArg) {
  return runAcrossTargets(jsonArg, collapseCore, null);
}
function DH_buildConstantSpeed(jsonArg) {
  return runAcrossTargets(jsonArg, varSpeedCore, null);
}

/* Target report for the Prep page banner (same payload as the Slate one). */
function DH_getPrepTargets(jsonArg) { return DH_getSlateTargets(jsonArg); }


/* ==================== Deliver: multi-sequence fan-out ====================
   Filenames on this page are built panel-side from the Filename override boxes
   plus the ACTIVE sequence's slate MOGRT. Across a selection that name has to
   be rebuilt per sequence, so the panel sends the override spec (which boxes
   are ticked, in their fixed order) and the host resolves each sequence's own
   slate. AD-ID override is a single literal value and cannot be fanned out, so
   the panel disables it whenever a selection is live. ==================== */

/* Panel-side fnoClean(), reproduced so names match exactly. */
function fnoCleanHost(v) {
  return String(v)
    .replace(/[:"'\/\\|?*<>]/g, "")
    .replace(/[\u2018\u2019\u201A\u201B\u201C\u201D\u201E\u201F\u2039\u203A\u00AB\u00BB`]/g, "")
    .replace(/\s+/g, " ")
    .replace(/^\s+|\s+$/g, "");
}

/* Builds the override filename for one sequence from its own slate MOGRT.
   fields is the ordered list the panel sent, e.g. ["AD-ID","CLIENT","SEQ NAME"]. */
function overrideNameForSeq(seq, fields, excludeAdId) {
  var parts = [], hit = null, i;
  try { hit = findSlateComponentDeep(seq); } catch (e) {}
  for (i = 0; i < fields.length; i++) {
    var f = String(fields[i]);
    if (excludeAdId && f === "AD-ID") continue;
    var v = "";
    if (f === "SEQ NAME") {
      v = fnoCleanHost(seqName(seq));
    } else if (hit) {
      var prm = findMGTParam(hit.comp, f);
      if (prm) v = fnoCleanHost(readMGTParamValue(prm));
    }
    if (v) parts.push(v);
  }
  return parts.join("_");
}

/* Reads a sequence's AD-ID, used as the search token for the AD-ID override. */
function adIdForSeq(seq) {
  try {
    var hit = findSlateComponentDeep(seq);
    if (!hit) return "";
    var prm = findMGTParam(hit.comp, "AD-ID");
    return prm ? String(readMGTParamValue(prm)) : "";
  } catch (e) { return ""; }
}

/* Rewrites the config for one target sequence. Single-target runs pass through
   untouched so a hand-typed filename still wins. */
function deliverArgForSeq(argString, seq, multi) {
  if (!multi) return argString;
  var a = safeParse(argString);
  var cfg = a.config || (a.config = {});
  var nm = seqName(seq);

  cfg.seqName = nm;
  cfg.adId = adIdForSeq(seq);

  var fields = cfg.fnoFields || [];
  if (fields.length) {
    var full = overrideNameForSeq(seq, fields, false);
    var noSl = overrideNameForSeq(seq, fields, true);
    cfg.fileName = full || nm;
    cfg.fileNameNoSlate = noSl || cfg.fileName;
  } else if (cfg.fileNameDirty !== true) {
    cfg.fileName = nm;            // no override, no hand-typed name
    cfg.fileNameNoSlate = nm;
  }
  /* AD-ID override is a single literal — never fan it out. */
  var segs = cfg.segments || [];
  for (var i = 0; i < segs.length; i++) { segs[i].isciOn = false; segs[i].isci = ""; }
  return JSON.stringify(a);
}

function DH_runDeliver3(jsonArg) {
  return runAcrossTargets(jsonArg, deliverRunCore, deliverArgForSeq);
}

/* ============================ Edit: version-up ============================ */

/* Rolls the trailing number in a name up by one, preserving zero-padding width
   and any trailing non-digits. "Cowboy_30_v1" -> "Cowboy_30_v2",
   "...v18" -> "...v19", "...v09" -> "...v10". No trailing number -> "_v2".
   Skips names already taken so no duplicate-named sequences are created. */
function incrementTrailingNumber(name, taken) {
  var match = String(name).match(/(\d+)(\D*)$/);
  var base, num, suffix;
  if (!match) { base = String(name); num = null; suffix = ""; }
  else {
    num = match[1];
    suffix = match[2] || "";
    base = String(name).substring(0, String(name).length - match[0].length);
  }
  function makeName(n) {
    if (num === null) return String(name) + "_v2";
    var s = String(n);
    while (s.length < num.length) s = "0" + s;
    return base + s + suffix;
  }
  var start = (num === null) ? 2 : (parseInt(num, 10) + 1);
  var candidate = makeName(start), guard = 0;
  while (taken[candidate] && guard < 9999) { start++; candidate = makeName(start); guard++; }
  return candidate;
}

/* Finds the bin that directly contains the projectItem with the given nodeId,
   searching the project tree recursively. Returns the containing bin or null. */
function findParentBin(bin, targetNodeId) {
  var kids = bin.children;
  for (var i = 0; i < kids.numItems; i++) {
    var child = kids[i];
    try { if (String(child.nodeId) === targetNodeId) return bin; } catch (e) {}
    var isBin = false;
    try { isBin = (child.type === ProjectItemType.BIN); } catch (e2) {}
    if (isBin) {
      var found = findParentBin(child, targetNodeId);
      if (found) return found;
    }
  }
  return null;
}

/* Duplicates the sequence selected in the Project panel and rolls its trailing
   version number up by one. */
function DH_dupSequence(jsonArg) {
  resetLog();
  if (!app.project) return reply({ ok: false, error: "No project open." });
  try {
    var sel = null;
    try { sel = app.getCurrentProjectViewSelection(); } catch (e) {}
    if (!sel || !sel.length)
      return reply({ ok: false, error: "Select a sequence in the Project panel first." });

    var selItem = null;
    for (var i = 0; i < sel.length; i++) {
      try { if (sel[i].isSequence && sel[i].isSequence()) { selItem = sel[i]; break; } } catch (e2) {}
    }
    if (!selItem)
      return reply({ ok: false, error: "No sequence selected — pick a sequence (not a clip or bin) in the Project panel." });

    var seqs = app.project.sequences;
    var target = null, selId = "";
    try { selId = String(selItem.nodeId); } catch (e3) {}
    for (var s = 0; s < seqs.numSequences; s++) {
      try {
        if (seqs[s].projectItem && String(seqs[s].projectItem.nodeId) === selId) { target = seqs[s]; break; }
      } catch (e4) {}
    }
    if (!target) {
      for (var s2 = 0; s2 < seqs.numSequences; s2++)
        if (String(seqs[s2].name) === String(selItem.name)) { target = seqs[s2]; break; }
    }
    if (!target) return reply({ ok: false, error: "Could not resolve the selected sequence." });

    var origName = String(selItem.name);

    var taken = {};
    for (var t = 0; t < seqs.numSequences; t++) { try { taken[String(seqs[t].name)] = true; } catch (e5) {} }

    // Make the target active, then clone it.
    try { app.project.openSequence(target.sequenceID); } catch (eOpen) {}
    activate(target);

    var beforeIDs = {};
    for (var b = 0; b < seqs.numSequences; b++) { try { beforeIDs[seqs[b].sequenceID] = true; } catch (e6) {} }

    try { app.project.activeSequence.clone(); }
    catch (eClone) { return reply({ ok: false, error: "Clone failed: " + eClone }); }

    var newSeq = null;
    for (var n = 0; n < seqs.numSequences; n++) {
      try { if (!beforeIDs[seqs[n].sequenceID]) { newSeq = seqs[n]; break; } } catch (e7) {}
    }
    if (!newSeq) return reply({ ok: false, error: "Clone created but the new sequence could not be found." });

    var newName = incrementTrailingNumber(origName, taken);
    try { newSeq.name = newName; } catch (e8) {}
    try { if (newSeq.projectItem) newSeq.projectItem.name = newName; } catch (e9) {}

    // Move the duplicate into the same bin as the original.
    try {
      var parentBin = findParentBin(app.project.rootItem, selId);
      if (parentBin && newSeq.projectItem &&
          String(parentBin.nodeId) !== String(app.project.rootItem.nodeId)) {
        newSeq.projectItem.moveBin(parentBin);
      }
    } catch (eMove) {}

    logMsg("✓ Duplicated '" + origName + "'  →  '" + newName + "'.", "ok");
    return reply({ ok: true, oldName: origName, newName: newName });
  } catch (e) {
    return reply({ ok: false, error: String(e) + (e.line ? " (line " + e.line + ")" : "") });
  }
}

/* Returns the active sequence's name, for the panel's read-only display. */
function DH_seqName(jsonArg) {
  resetLog();
  try {
    var n = (app.project && app.project.activeSequence) ? app.project.activeSequence.name : "";
    return reply({ ok: true, name: n });
  } catch (e) {
    return reply({ ok: false, name: "", error: String(e) });
  }
}

/* Current video track count of the active sequence — polled by the panel so the
   Track Layout range selectors can clamp themselves to what actually exists,
   whether tracks disappeared via Collapse Video Tracks or a manual delete in
   Premiere's own timeline. */
function DH_videoTrackCount(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    var n = seq ? seq.videoTracks.numTracks : 0;
    return reply({ ok: true, tracks: n });
  } catch (e) {
    return reply({ ok: false, tracks: 0, error: String(e) });
  }
}

/* ============================ Slate MOGRT ============================ */

/* The 8 fields the panel wants to read/write, in the user's casing. Matching
   against the MOGRT's actual param names is case-insensitive and ignores
   spaces/dashes/underscores, so "AD-ID" matches "Ad Id", "ad_id", etc. */
var SLATE_REQUEST_FIELDS = ["AGENCY", "CLIENT", "TITLE", "AD-ID", "AUDIO", "DURATION", "DATE", "FORMAT", "COPYRIGHT"];   // Signal Slate MOGRT, in its order

function normName(s) { return String(s).toLowerCase().replace(/[^a-z0-9]/g, ""); }

/* Reads a text value from a MOGRT ComponentParam. Newer Premiere returns a
   JSON blob carrying textEditValue; older returns a plain string. */
function readMGTParamValue(param) {
  var raw;
  try { raw = param.getValue(); } catch (e) { return ""; }
  if (raw === null || raw === undefined) return "";
  var s = String(raw);
  try {
    var obj = JSON.parse(s);
    if (obj && typeof obj.textEditValue === "string") return obj.textEditValue;
    if (obj && typeof obj.value === "string") return obj.value;
  } catch (e2) {}
  return s;
}

/* Writes a text value back, preserving the JSON blob format when present
   (and updating fontTextRunLength, which the text engine requires). */
function writeMGTParamValue(param, newValue) {
  var raw;
  try { raw = param.getValue(); } catch (e) { raw = null; }
  if (raw !== null && raw !== undefined) {
    try {
      var obj = JSON.parse(String(raw));
      if (obj && typeof obj.textEditValue !== "undefined") {
        obj.textEditValue = newValue;
        if (typeof obj.fontTextRunLength !== "undefined")
          obj.fontTextRunLength = [newValue.length];
        param.setValue(JSON.stringify(obj), true);
        return true;
      }
    } catch (e2) {}
  }
  param.setValue(newValue, true);
  return true;
}

/* Finds a MOGRT in the active sequence, preferring a clip named like the
   Harbor Slate. getMGTComponent() returns null for PPro-authored MOGRTs, so
   only AE-authored templates are readable. Returns {comp, clip} or null. */
function findSlateComponent(seq) {
  var fallback = null;
  for (var t = seq.videoTracks.numTracks - 1; t >= 0; t--) {
    var track = seq.videoTracks[t];
    for (var c = 0; c < track.clips.numItems; c++) {
      var clip = track.clips[c], comp = null;
      try { comp = clip.getMGTComponent(); } catch (e) {}
      if (comp) {
        var nm = "";
        try { nm = String(clip.name); } catch (e2) {}
        if (/harbor|slate/i.test(nm)) return { comp: comp, clip: clip };
        if (!fallback) fallback = { comp: comp, clip: clip };
      }
    }
  }
  return fallback;
}

/* Lists every exposed param {name, value} — a diagnostic so the user can see
   the MOGRT's real field names if the 8 requested ones don't match. */
function listMGTParams(comp) {
  var out = [];
  try {
    var props = comp.properties;
    for (var i = 0; i < props.numItems; i++) {
      var p = props[i], nm = "";
      try { nm = String(p.displayName); }
      catch (e) { try { nm = String(p.name); } catch (e2) { nm = "param " + i; } }
      out.push({ name: nm, value: readMGTParamValue(p) });
    }
  } catch (e3) {}
  return out;
}

/* Case-insensitive param lookup by display name. */
function findMGTParam(comp, fieldName) {
  var target = normName(fieldName);
  try {
    var props = comp.properties;
    for (var i = 0; i < props.numItems; i++) {
      var p = props[i], nm = "";
      try { nm = String(p.displayName); } catch (e) { continue; }
      if (normName(nm) === target) return p;
    }
  } catch (e2) {}
  return null;
}

function DH_readSlate(jsonArg) {
  resetLog();
  if (!app.project || !app.project.activeSequence)
    return reply({ ok: false, error: "No active sequence." });
  try {
    var seq = app.project.activeSequence;
    var hit = findSlateComponent(seq);
    if (!hit) return reply({ ok: true, found: false });
    var fields = {}, toggles = {};
    for (var i = 0; i < SLATE_REQUEST_FIELDS.length; i++) {
      var f = SLATE_REQUEST_FIELDS[i];
      var p = findMGTParam(hit.comp, f);
      fields[f] = p ? readMGTParamValue(p) : "";
      var tp = findToggleParam(hit.comp, f);
      toggles[f] = { present: !!tp, on: tp ? readMGTBool(tp) : false };
    }
    var nm = "";
    try { nm = String(hit.clip.name); } catch (e) {}
    return reply({ ok: true, found: true, clipName: nm, fields: fields, toggles: toggles });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* ---- Multi-sequence targeting -------------------------------------------
   The slate tools act on the active sequence. If 2+ sequences are selected in
   the Project panel, they act on that selection instead. ---------------------- */

function seqNodeId(seq) { try { return String(seq.projectItem.nodeId); } catch (e) { return ""; } }
function seqName(seq)   { try { return String(seq.name); } catch (e) { return ""; } }

/* Sequences currently selected in the Project panel, in project order. Matches
   on nodeId, falling back to name where projectItem is unavailable. */
function selectedSequences() {
  var out = [], sel = null, i, j;
  try { sel = app.getCurrentProjectViewSelection(); } catch (e) { return out; }
  if (!sel || !sel.length) return out;

  var ids = {}, names = {}, any = false;
  for (i = 0; i < sel.length; i++) {
    var it = sel[i], isSeq = false;
    try { isSeq = it.isSequence(); } catch (e2) { isSeq = false; }
    if (!isSeq) continue;
    any = true;
    try { ids[String(it.nodeId)] = true; } catch (e3) {}
    try { names[String(it.name)] = true; } catch (e4) {}
  }
  if (!any) return out;

  var seqs = app.project.sequences;
  for (j = 0; j < seqs.numSequences; j++) {
    var s = seqs[j];
    if (!s) continue;
    var nid = seqNodeId(s);
    if ((nid && ids[nid]) || (!nid && names[seqName(s)])) out.push(s);
  }
  return out;
}

/* Target list: Project-panel selection when it holds 2+ sequences, else the
   active sequence alone. */
function slateTargets() {
  var sel = selectedSequences();
  if (sel.length > 1) return sel;
  var a = null;
  try { a = app.project ? app.project.activeSequence : null; } catch (e) {}
  return a ? [a] : [];
}

/* findSlateComponent, retried once with the sequence opened. getMGTComponent()
   can read back null on a sequence that has not been opened this session. */
function findSlateComponentDeep(seq) {
  var hit = findSlateComponent(seq);
  if (hit) return hit;
  var prev = null;
  try { prev = app.project.activeSequence; } catch (e) {}
  activate(seq);
  hit = findSlateComponent(seq);
  if (prev) activate(prev);
  return hit;
}

/* Runs fn(hit, seq) across every target. fn returns null on success or an
   error string. Reply shape is shared by the field and toggle writers. */
function slateApplyAll(fn) {
  var targets = slateTargets();
  if (!targets.length) return { ok: false, error: "No active sequence." };

  var okNames = [], failed = [], i;
  for (i = 0; i < targets.length; i++) {
    var seq = targets[i], nm = seqName(seq), err = null;
    try {
      var hit = findSlateComponentDeep(seq);
      if (!hit) err = "no readable MOGRT";
      else err = fn(hit, seq);
    } catch (e) { err = String(e); }
    if (err) failed.push({ seq: nm, error: err });
    else okNames.push(nm);
  }
  return {
    ok: okNames.length > 0,
    total: targets.length,
    updated: okNames.length,
    sequences: okNames,
    failures: failed,
    error: okNames.length ? "" : (failed.length ? failed[0].error : "Nothing updated.")
  };
}

/* Reports the current target set so the panel can label the Set buttons. */
function DH_getSlateTargets(jsonArg) {
  try {
    var sel = selectedSequences(), names = [], i;
    var multi = sel.length > 1;
    var list = multi ? sel : slateTargets();
    for (i = 0; i < list.length; i++) names.push(seqName(list[i]));
    return reply({ ok: true, multi: multi, count: names.length, sequences: names });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

function DH_setSlateField(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  if (!app.project) return reply({ ok: false, error: "No project." });
  try {
    var res = slateApplyAll(function (hit) {
      var p = findMGTParam(hit.comp, a.field);
      if (!p) return "field '" + a.field + "' not in MOGRT";
      writeMGTParamValue(p, a.value || "");
      return null;
    });
    return reply(res);
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* ---- Per-row on/off toggle (a checkbox param paired with each text field) ---- */
function isBoolish(raw) {
  if (raw === true || raw === false) return true;
  var s = String(raw).toLowerCase();
  return s === "0" || s === "1" || s === "true" || s === "false";
}
function readMGTBool(param) {
  var raw; try { raw = param.getValue(); } catch (e) { return false; }
  var s = String(raw).toLowerCase();
  return s === "1" || s === "true";
}
/* Finds the checkbox param that controls a field's on/off state. The Harbor
   slate names them "<FIELD> ON/OFF" (e.g. "AGENCY ON/OFF"), which normalizes to
   "<field>onoff". We match that plus a few other conventions, and as a fallback
   any boolean-valued param whose name starts with the field name. Requiring a
   boolean value means the field's own text param is never picked. */
function findToggleParam(comp, fieldName) {
  var base = normName(fieldName);
  var sfx = ["onoff", "on", "off", "show", "visible", "enable", "enabled", "display", "active", "toggle", ""];
  var exact = {};
  for (var k = 0; k < sfx.length; k++) { exact[base + sfx[k]] = true; exact[sfx[k] + base] = true; }
  var starts = null;
  try {
    var props = comp.properties;
    for (var i = 0; i < props.numItems; i++) {
      var p = props[i], nm = "";
      try { nm = String(p.displayName); } catch (e) { continue; }
      var nn = normName(nm), raw;
      try { raw = p.getValue(); } catch (e2) { continue; }
      if (!isBoolish(raw)) continue;
      if (exact[nn]) return p;                                  // best match
      if (!starts && nn.indexOf(base) === 0 && base.length) starts = p;   // fallback
    }
  } catch (e3) {}
  return starts;
}

/* Writes a boolean to a checkbox param, trying the value shapes Premiere uses
   for MOGRT checkboxes across versions (JSON blob, number, boolean, string). */
function writeMGTBool(param, on) {
  var raw; try { raw = param.getValue(); } catch (e) { raw = null; }
  if (raw !== null && raw !== undefined) {
    try {
      var obj = JSON.parse(String(raw));
      if (obj && typeof obj === "object" && typeof obj.value !== "undefined") {
        obj.value = on ? 1 : 0;
        param.setValue(JSON.stringify(obj), true);
        return true;
      }
    } catch (e2) {}
  }
  try { param.setValue(on ? 1 : 0, true); return true; } catch (e3) {}
  try { param.setValue(on, true); return true; } catch (e4) {}
  try { param.setValue(on ? "1" : "0", true); return true; } catch (e5) {}
  return false;
}

function DH_setSlateToggle(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  if (!app.project) return reply({ ok: false, error: "No project." });
  var on = (a.on === true || String(a.on) === "true");
  try {
    var res = slateApplyAll(function (hit) {
      var p = findToggleParam(hit.comp, a.field);
      if (!p) return "no '" + a.field + " ON/OFF' control";
      if (!writeMGTBool(p, on)) return "could not set the on/off control";
      return null;
    });
    res.on = on;
    return reply(res);
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* ---- File dialogs for the Slate Mapper (panel writes/reads the bytes) ---- */
function DH_saveDialog(jsonArg) {
  var a = safeParse(jsonArg);
  try {
    var name = (a && a.name) ? String(a.name) : "template.xlsx";
    var start = new File(Folder.desktop.fsName + sep() + name);
    var f = start.saveDlg("Export slate template");
    if (!f) return reply({ ok: false });
    var p = f.fsName;
    if (!/\.xlsx$/i.test(p)) p += ".xlsx";
    return reply({ ok: true, path: p });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}
function DH_openDialog(jsonArg) {
  try {
    var mask = ($.os.indexOf("Windows") !== -1)
      ? "Excel template:*.xlsx"
      : function (f) { return (f instanceof Folder) || /\.xlsx$/i.test(f.name); };
    var f = File.openDialog("Choose slate template (.xlsx)", mask);
    if (!f) return reply({ ok: false });
    return reply({ ok: true, path: f.fsName });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* ============================ Deliver ============================ */

/* Sequence length in seconds, measured from physical frame 0 (so it works as a
   setOutPoint value). Falls back to scanning clips if Sequence.end is unusable. */
function seqEndSeconds(seq) {
  var t = 0;
  try { t = Number(seq.end); } catch (e) {}
  if (!t || t <= 0) {
    try {
      var lists = [seq.videoTracks, seq.audioTracks];
      for (var L = 0; L < lists.length; L++) {
        var tracks = lists[L];
        for (var tr = 0; tr < tracks.numTracks; tr++) {
          var clips = tracks[tr].clips;
          for (var c = 0; c < clips.numItems; c++) {
            var e = Number(clips[c].end.ticks);
            if (e > t) t = e;
          }
        }
      }
    } catch (e2) {}
  }
  return t / TICKS_PER_SECOND;
}

function exportWorkArea(seq, presetPath, outPath, workArea) {
  // workArea: 0 = entire sequence, 1 = in-to-out.
  app.encoder.launchEncoder();
  var jobID = app.encoder.encodeSequence(seq, outPath, presetPath, workArea, 1);
  // Flush in/out state to AME so the async render picks up the correct range.
  app.project.save();
  app.encoder.startBatch();
  return jobID;
}

/* ISCI override (Generic deliveries): on the export clone's Harbor Slate MOGRT,
   set AD-ID to the supplied ISCI code and append "_GENERIC" to TITLE.
   Best-effort — only AE-authored MOGRTs expose these params to scripting. */
function applyIsciOverride(seq, isci) {
  try {
    var hit = findSlateComponent(seq);
    if (!hit || !hit.comp) { logMsg("⚠ ISCI: no slate MOGRT found on the clone — AD-ID/TITLE not overridden.", "warn"); return; }
    var comp = hit.comp;
    var adp = findMGTParam(comp, "AD-ID");
    if (adp) { writeMGTParamValue(adp, String(isci)); logMsg("• ISCI: AD-ID set to \"" + isci + "\".", ""); }
    else logMsg("⚠ ISCI: AD-ID param not found in MOGRT.", "warn");
    var tp = findMGTParam(comp, "TITLE");
    if (tp) {
      var cur = ""; try { cur = String(readMGTParamValue(tp)); } catch (e) {}
      if (cur === "undefined" || cur === "null") cur = "";
      var nu = cur + " GENERIC";
      writeMGTParamValue(tp, nu);
      logMsg("• ISCI: TITLE → \"" + nu + "\".", "");
    } else logMsg("⚠ ISCI: TITLE param not found in MOGRT.", "warn");
    // If either was missing, dump the real param names so we can map them.
    if (!adp || !tp) {
      var names = listMGTParams(comp), s = "";
      for (var i = 0; i < names.length; i++) s += (i ? ", " : "") + names[i].name;
      logMsg("  MOGRT fields seen: " + (s || "(none)"), "");
    }
  } catch (e2) { logMsg("⚠ ISCI override error: " + e2, "warn"); }
}

/* Exports the active sequence as Master / Master_Spec / Generic / Additional.
   Per segment: Slate = whole sequence; No slate = from 01:00:00:00 to end. No
   "_Slate" in filenames — the no-slate variant instead drops the AD-ID, and the
   slate variant keeps it. Generic files end "_Generic", Specd Master "_Spec".
   Each no-slate export gets its own clone so the in/out state can't go stale. */
function deliverRunCore(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var cfg = a.config || {};

  if (!app.project) return reply({ ok: false, error: "No project open." });
  if (!app.project.activeSequence) return reply({ ok: false, error: "No active sequence." });
  if (!cfg.outFolder) return reply({ ok: false, error: "Pick an output folder first." });

  try {
    var master = app.project.activeSequence;
    var nameBase = (cfg.fileName && cfg.fileName.length) ? cfg.fileName
                 : ((cfg.seqName && cfg.seqName !== "(no sequence open)") ? cfg.seqName : master.name);
    var seqSafe = fileSafe(nameBase) || "Sequence";
    // No-slate filename ignores the AD-ID override (built panel-side).
    var noSlateBase = (cfg.fileNameNoSlate && cfg.fileNameNoSlate.length) ? cfg.fileNameNoSlate : nameBase;
    var noSlateSafe = fileSafe(noSlateBase) || "Sequence";
    var segments = cfg.segments || [];

    // Per-run container, named from the sequence (not the filename override).
    var seqForRun = (cfg.seqName && cfg.seqName !== "(no sequence open)") ? cfg.seqName : master.name;
    var runName = (sanitize(seqForRun) || "Sequence") + "_deliver_" + dateMMDD() + "_" + runStamp();
    var runDir = cfg.outFolder + sep() + runName;
    if (cfg.groupByDept !== true) ensureFolder(runDir);   // grouped mode nests under each segment root instead
    var dlvBin = getOrCreateBin(getDeckhandBin("Deliver"), runName);

    var anything = false;
    for (var s = 0; s < segments.length; s++)
      if (segments[s].slate || segments[s].noslate) anything = true;
    if (!anything) { logMsg("Nothing checked to export.", "warn"); return reply({ ok: true }); }

    var usedFolders = {};
    for (var i = 0; i < segments.length; i++) {
      var seg = segments[i];
      if (!seg.slate && !seg.noslate) continue;
      if (!seg.preset) { logMsg("⚠ " + seg.name + ": no preset selected — skipped.", "warn"); continue; }

      // "Specd Master" delivers into a folder named "Master_Spec".
      var segLabel = (seg.name === "Specd Master") ? "Master_Spec" : seg.name;
      var folderName = sanitize(segLabel) || ("Segment" + (i + 1));
      var baseName = folderName, n = 2;
      while (usedFolders[folderName]) { folderName = baseName + "_" + n; n++; }
      usedFolders[folderName] = true;
      // Grouped: <out>/<Segment root>/<sequence run>/ · Default: <out>/<run>/<Segment>/
      var segDir = (cfg.groupByDept === true) ? (cfg.outFolder + sep() + folderName + sep() + runName)
                                              : (runDir + sep() + folderName);
      ensureFolder(segDir);

      // The panel sends the suffix explicitly (seg.suffix), so the host doesn't
      // infer it from the name. Fall back to name-matching only if it's absent.
      var segNorm = String(seg.name || "").toLowerCase().replace(/[^a-z]/g, "");
      var isGeneric = (segNorm === "generic");
      var isci = (isGeneric && seg.isciOn && seg.isci) ? String(seg.isci) : "";
      var suffix;
      if (typeof seg.suffix === "string") {
        suffix = isci ? "_GENERIC" : seg.suffix;
      } else {
        suffix = isGeneric ? (isci ? "_GENERIC" : "_Generic")
               : (segNorm === "specdmaster") ? "_Spec" : "";
      }
      logMsg("· segment \"" + seg.name + "\" (panel suffix \"" + (seg.suffix != null ? seg.suffix : "?") + "\") → \"" + (suffix || "(none)") + "\".", "");
      var slateBase = seqSafe + suffix;
      var nsBase = noSlateSafe + suffix;
      // ISCI also replaces the AD-ID text inside the filename (the override that
      // would otherwise carry the slate AD-ID), so the generic file reads with
      // the new code rather than the original.
      if (isci && cfg.adId) {
        var fromTok = fileSafe(cfg.adId), toTok = fileSafe(isci);
        if (fromTok) {
          while (slateBase.indexOf(fromTok) !== -1) slateBase = slateBase.replace(fromTok, toTok);
          while (nsBase.indexOf(fromTok) !== -1) nsBase = nsBase.replace(fromTok, toTok);
        }
      }
      if (seg.slate && seg.noslate && slateBase === nsBase) slateBase = slateBase + "_slate";

      if (seg.slate) {
        activate(master);
        var slateClone = cloneActiveSequence("Deliver " + sanitize(seg.name) + " Slate", dlvBin);
        if (!slateClone) { logMsg("⚠ " + seg.name + ": slate clone failed — skipped.", "warn"); }
        else {
          if (seg.gfxOn) setTrackRangeDisabled(slateClone, seg.gfxLow, seg.gfxHigh, true);
          if (isci) applyIsciOverride(slateClone, isci);
          activate(slateClone);
          exportWorkArea(slateClone, seg.preset, segDir + sep() + slateBase + ".mov", 0);
          logMsg("• " + seg.name + ": slate queued (" + slateBase + ").", "");
        }
      }
      if (seg.noslate) {
        activate(master);
        var nsClone = cloneActiveSequence("Deliver NoSlate " + (i + 1), dlvBin);
        if (!nsClone) { logMsg("⚠ " + seg.name + ": no-slate clone failed — skipped.", "warn"); continue; }
        if (seg.gfxOn) setTrackRangeDisabled(nsClone, seg.gfxLow, seg.gfxHigh, true);
        if (isci) applyIsciOverride(nsClone, isci);
        // Pin the export range to [01:00:00:00 → end]. Sequences always start at
        // 00:59:53:00 — a fixed 7 seconds of *timecode* before the in-point.
        // The catch: at NTSC rates (23.976, 29.97) timecode seconds are not real
        // seconds, so "3600 − zeroSec" placed the in early (it landed at
        // 00:59:56:09 on a 23.976 sequence). Compute the lead in frames instead
        // (7s × nominal fps) and convert to real seconds for setInPoint. Both in
        // and out must be set for AME's In/Out (workArea 1) range to be honored.
        var fps = fpsFromSeq(nsClone);
        var leadFrames = 7 * tcInfo(fps).nominal;   // 00:59:53:00 → 01:00:00:00
        var inSec = leadFrames / fps;
        var outSec = seqEndSeconds(nsClone);
        try {
          nsClone.setInPoint(inSec);
          if (outSec > inSec) nsClone.setOutPoint(outSec);
        } catch (eI) {
          logMsg("⚠ " + seg.name + ": could not set in/out: " + eI, "warn");
        }
        activate(nsClone);
        exportWorkArea(nsClone, seg.preset, segDir + sep() + nsBase + ".mov", 1);
        logMsg("• " + seg.name + ": no-slate queued from 01:00:00:00 (" + nsBase + ").", "");
      }
    }
    return reply({ ok: true });
  } catch (e) {
    return reply({ ok: false, error: String(e) + (e.line ? " (line " + e.line + ")" : "") });
  }
}

/* ===================== Edit page: clip tools ===================== *
 * These drive Premiere automation that can't be exercised outside the app, so
 * they're best-effort. Effects are added through the QE DOM, which is the only
 * scriptable path for "add this effect to the selected clip". If a name doesn't
 * match your install's effect list (localized builds differ), the log will say
 * so and you can tell me the exact name to match. */

function qeActiveSequence() {
  app.enableQE();
  return qe.project ? qe.project.getActiveSequence() : null;
}

/* The QE clip at a given gap-free position. Standard DOM track.clips skips gaps,
   but QE getItemAt() includes empty/gap items, so we walk QE items and count
   only the real ones to line them up with the standard clip order. */
function qeRealClipAt(qeTrack, position) {
  var nI = 0; try { nI = qeTrack.numItems; } catch (e) { return null; }
  var seen = -1;
  for (var k = 0; k < nI; k++) {
    var it = qeTrack.getItemAt(k), empty = false;
    try { empty = (it.type === "Empty"); } catch (e2) {}
    if (!empty) { try { if (String(it.name) === "") empty = true; } catch (e3) {} }
    if (empty) continue;
    seen++;
    if (seen === position) return it;
  }
  return null;
}

/* Add a named video effect to every selected clip on the active sequence.
   Selection is read through the standard API (reliable), then each selected
   clip is matched to its QE counterpart by track + position so QE can apply
   the effect (the QE 'selected' flag is unreliable across versions). */
function addEffectByName(effectName) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });

    // Gather selected clips: { track, pos } using the standard DOM.
    var picks = [], vts = seq.videoTracks;
    for (var t = 0; t < vts.numTracks; t++) {
      var clips = vts[t].clips;
      for (var p = 0; p < clips.numItems; p++) {
        var s = false; try { s = clips[p].isSelected(); } catch (e) {}
        if (s) picks.push({ track: t, pos: p });
      }
    }
    if (!picks.length) return reply({ ok: false, error: "No clip selected on the active sequence." });

    var qseq = qeActiveSequence();
    if (!qseq) return reply({ ok: false, error: "Could not open the QE sequence to apply effects." });
    var fx = null;
    try { fx = qe.project.getVideoEffectByName(effectName); } catch (e2) {}
    if (!fx) return reply({ ok: false, error: "Effect not found on this system: \"" + effectName + "\". Tell me the exact name shown in your Effects panel." });

    var count = 0, miss = 0;
    for (var i = 0; i < picks.length; i++) {
      var qTrack = null; try { qTrack = qseq.getVideoTrackAt(picks[i].track); } catch (e3) {}
      var qClip = qTrack ? qeRealClipAt(qTrack, picks[i].pos) : null;
      if (!qClip) { miss++; continue; }
      try { qClip.addVideoEffect(fx); count++; }
      catch (e4) { miss++; logMsg("⚠ Could not add to a clip: " + e4, "warn"); }
    }
    if (!count) return reply({ ok: false, error: "Found the selection but couldn't match it in QE to apply the effect." });
    return reply({ ok: true, message: effectName + " added to " + count + " clip(s)" + (miss ? " (" + miss + " skipped)." : ".") });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

function DH_addEffect_warp(jsonArg)      { return addEffectByName("Warp Stabilizer"); }
function DH_addEffect_transform(jsonArg) { return addEffectByName("Transform"); }
function DH_addEffect_flipH(jsonArg)     { return addEffectByName("Horizontal Flip"); }
/* "Flip Vertical" applies the actual Vertical Flip effect. */
function DH_addEffect_flipV(jsonArg)     { return addEffectByName("Vertical Flip"); }

/* Collect selected clips as { track, pos } via the standard DOM, then return the
   matched QE clips. Shared by speed/interpolation ops that need the QE clip. */
function selectedQeClips() {
  var out = [], seq = app.project.activeSequence;
  if (!seq) return out;
  var picks = [], vts = seq.videoTracks;
  for (var t = 0; t < vts.numTracks; t++) {
    var clips = vts[t].clips;
    for (var p = 0; p < clips.numItems; p++) {
      var s = false; try { s = clips[p].isSelected(); } catch (e) {}
      if (s) picks.push({ track: t, pos: p, dom: clips[p] });
    }
  }
  if (!picks.length) return out;
  var qseq = qeActiveSequence();
  if (!qseq) return out;
  for (var i = 0; i < picks.length; i++) {
    var qt = null; try { qt = qseq.getVideoTrackAt(picks[i].track); } catch (e2) {}
    var qc = qt ? qeRealClipAt(qt, picks[i].pos) : null;
    if (qc) out.push({ qe: qc, dom: picks[i].dom, track: picks[i].track, pos: picks[i].pos });
  }
  return out;
}

/* Recursively search the Project panel for an item by (case-insensitive) name. */
function findProjectItemByName(root, want) {
  try {
    for (var i = 0; i < root.children.numItems; i++) {
      var it = root.children[i];
      if (it && String(it.name).toLowerCase() === String(want).toLowerCase()) return it;
      if (it && it.type === ProjectItemType.BIN) {
        var deep = findProjectItemByName(it, want);
        if (deep) return deep;
      }
    }
  } catch (e) {}
  return null;
}


/* ---- Fitted layer sources: find loosely, create when missing ---- */
function normItemName(n) { return String(n).toLowerCase().replace(/[^a-z0-9]/g, ""); }
/* First non-bin item whose name equals or starts with one of `names`
   (case/space-insensitive), searched through every bin. */
function findItemLoose(root, names) {
  var want = []; for (var w = 0; w < names.length; w++) want.push(normItemName(names[w]));
  var exact = null, prefix = null;
  function walk(bin) {
    var kids; try { kids = bin.children; } catch (e) { return; }
    for (var i = 0; i < kids.numItems && !exact; i++) {
      var it = kids[i], isBin = false;
      try { isBin = (it.type === ProjectItemType.BIN); } catch (e1) {}
      if (isBin) { walk(it); continue; }
      var nn = normItemName(it.name);
      for (var k = 0; k < want.length; k++) {
        if (nn === want[k]) { exact = it; break; }
        if (!prefix && nn.indexOf(want[k]) === 0) prefix = it;
      }
    }
  }
  walk(root);
  return exact || prefix;
}
/* Snapshot of every item's nodeId, so a newly created item can be spotted. */
function allNodeIds(root, map) {
  map = map || {};
  try {
    for (var i = 0; i < root.children.numItems; i++) {
      var it = root.children[i];
      try { map[String(it.nodeId)] = true; } catch (e) {}
      var isBin = false; try { isBin = (it.type === ProjectItemType.BIN); } catch (e1) {}
      if (isBin) allNodeIds(it, map);
    }
  } catch (e2) {}
  return map;
}
function newItemSince(root, before) {
  var found = null;
  (function walk(bin) {
    try {
      for (var i = 0; i < bin.children.numItems && !found; i++) {
        var it = bin.children[i], isBin = false;
        try { isBin = (it.type === ProjectItemType.BIN); } catch (e1) {}
        if (isBin) { walk(it); continue; }
        var id = ""; try { id = String(it.nodeId); } catch (e) {}
        if (id && !before[id]) found = it;
      }
    } catch (e2) {}
  })(root);
  return found;
}
/* Try Premiere's (undocumented) QE "new synthetic item" calls. Signatures differ
   by version, so several are tried; success = a new item appears in the project. */
function qeCreateSynthetic(re, seq, name) {
  try { app.enableQE(); } catch (e0) {}
  var qp = null; try { qp = qe.project; } catch (e) {}
  if (!qp) return null;
  var methods = [];
  try { var rm = qp.reflect.methods; for (var i = 0; i < rm.length; i++) if (re.test(String(rm[i].name))) methods.push(String(rm[i].name)); } catch (e1) {}
  if (!methods.length) { logMsg("• This Premiere has no scriptable '" + name + "' command.", ""); return null; }
  var w = 1920, h = 1080, tb = 0, parN = 1, parD = 1;
  try { w = seq.frameSizeHorizontal; h = seq.frameSizeVertical; } catch (e2) {}
  try { tb = seq.timebase; } catch (e3) {}
  var argSets = [[w, h, tb, parN, parD], [w, h, tb, parN, parD, name], [w, h, tb, 1.0], [w, h, tb, 1.0, name], [name]];
  for (var m = 0; m < methods.length; m++) {
    for (var a = 0; a < argSets.length; a++) {
      var before = allNodeIds(app.project.rootItem);
      try { qp[methods[m]].apply(qp, argSets[a]); } catch (e4) { continue; }
      var it = newItemSince(app.project.rootItem, before);
      if (it) { try { it.name = name; } catch (e5) {} logMsg("• Created '" + name + "' (" + methods[m] + ").", ""); return it; }
    }
  }
  logMsg("• Tried " + methods.join(", ") + " but no new item appeared.", "warn");
  return null;
}
/* Adjustment Layer source: existing item, else create one, filed in 06_Tools. */
function getAdjustmentSource(seq) {
  var it = findItemLoose(app.project.rootItem, ["Adjustment Layer"]);
  if (it) return it;
  it = qeCreateSynthetic(/^new.*adjust/i, seq, "Adjustment Layer");
  if (it) { try { it.moveBin(getToolsBin()); } catch (e) {} }
  return it;
}
/* Black source for this sequence's frame size:
   1) a "Black Video <W>x<H>" item made earlier by this button,
   2) an exact "Black Video" / "Black Matte" / "Black" item you made yourself,
   3) otherwise import the panel's bundled black frame closest to the sequence's
      shape (a still holds any duration) and name it "Black Video <W>x<H>". */
function getBlackSource(seq, extDir) {
  var w = 1920, h = 1080;
  try { w = Number(seq.frameSizeHorizontal) || w; h = Number(seq.frameSizeVertical) || h; } catch (e0) {}
  var sized = "Black Video " + w + "x" + h;
  var it = findItemLoose(app.project.rootItem, [sized]);
  if (it && normItemName(it.name) === normItemName(sized)) return it;
  var cands = ["Black Video", "Black Matte", "Black"];
  for (var c = 0; c < cands.length; c++) {
    var x = findItemLoose(app.project.rootItem, [cands[c]]);
    if (x && normItemName(x.name) === normItemName(cands[c])) return x;
  }
  if (!extDir) return null;
  var r = w / h, file = "Black_16x9.png";
  if (r < 0.7) file = "Black_9x16.png";
  else if (r < 0.9) file = "Black_4x5.png";
  else if (r < 1.2) file = "Black_1x1.png";
  var f = new File(extDir + "/Assets/" + file);
  if (!f.exists) { logMsg("⚠ Bundled black frame missing: " + f.fsName, "warn"); return null; }
  var before = allNodeIds(app.project.rootItem);
  try { app.project.importFiles([f.fsName], true, getToolsBin(), false); } catch (e) { logMsg("⚠ Import failed: " + e, "warn"); }
  it = newItemSince(app.project.rootItem, before);
  if (it) { try { it.name = sized; } catch (e1) {} logMsg("• Added '" + sized + "' to 06_Tools (made once, reused after).", ""); }
  return it;
}

/* Fitted Adjustment Layer: span an adjustment layer over the selected clip on
   the next track up. Premiere has no API to *create* an adjustment layer, so we
   reuse an "Adjustment Layer" item from the Project panel (create one once via
   File ▸ New ▸ Adjustment Layer). Best-effort: track creation and end-trimming
   vary by version. */
function DH_fittedAdjustmentLayer(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var r = fittedAdjLayerCore(seq);
    if (!r.ok) return reply({ ok: false, error: r.error });
    return reply({ ok: true, message: "Adjustment layer placed on V" + (r.targetIdx + 1) + ", fitted to the selected clip." });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* Finds the destination track for a fitted overlay: scanning UPWARD from just
   above the selection, the LOWEST existing video track that is empty across
   [startSec, endSec) — i.e. the first track it can drop onto without overwriting
   anything. If every track above the selection is occupied at that span, adds a
   new track on top and returns its index. minIdx is the selected clip's own
   track index — never place at or below it. */
function highestEmptyTrackIdx(seq, minIdx, startSec, endSec) {
  var vts = seq.videoTracks;
  // Walk from the track just above the selection upward; take the first
  // (lowest) one with no clip overlapping the span.
  for (var t = minIdx + 1; t < vts.numTracks; t++) {
    var clips = vts[t].clips, occupied = false;
    for (var c = 0; c < clips.numItems; c++) {
      var cs = clips[c].start.seconds, ce = clips[c].end.seconds;
      if (cs < endSec - 0.0005 && ce > startSec + 0.0005) { occupied = true; break; }
    }
    if (!occupied) return t;
  }
  // Every track above the selection is busy at this span — add a fresh one on top.
  var newIdx = vts.numTracks;
  try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0, 0, 0, 0); } catch (e) {}
  return newIdx;
}

/* Places a fitted adjustment layer and returns where it landed, so callers can
   act on it further (e.g. add an effect). */
function fittedAdjLayerCore(seq) {
  var sel = null, selTrackIdx = -1, vts = seq.videoTracks;
  for (var t = 0; t < vts.numTracks && !sel; t++) {
    var clips = vts[t].clips;
    for (var c = 0; c < clips.numItems; c++) {
      var s = false; try { s = clips[c].isSelected(); } catch (e) {}
      if (s) { sel = clips[c]; selTrackIdx = t; break; }
    }
  }
  if (!sel) return { ok: false, error: "No clip selected on the active sequence." };

  var adj = getAdjustmentSource(seq);
  if (!adj) return { ok: false, error: "Couldn't find or create an Adjustment Layer. Make one once (File \u25b8 New \u25b8 Adjustment Layer) and this button will reuse it." };

  var startSec = sel.start.seconds;
  // Land on the highest empty track over the clip's span, not just the next one up.
  var targetIdx = highestEmptyTrackIdx(seq, selTrackIdx, startSec, sel.end.seconds);
  var target = seq.videoTracks[targetIdx];
  if (!target) return { ok: false, error: "No empty video track above the selected clip, and one couldn't be added." };

  // Constrain the Adjustment Layer source to the selected clip's EXACT duration
  // BEFORE placing it, so overwriteClip lays it down already-trimmed instead of at
  // its full default length. That's what prevents it from ever spanning — even
  // momentarily — later clips on the destination track. Ticks are frame-exact;
  // fall back to seconds. (setInPoint/setOutPoint signature varies, so we try the
  // mediaType-qualified form first, then the bare form.)
  var durTicks = null;
  try { durTicks = String(Number(sel.end.ticks) - Number(sel.start.ticks)); } catch (edt) {}
  var trimmed = false;
  if (durTicks && durTicks !== "NaN") {
    try { adj.setInPoint("0", 4); adj.setOutPoint(durTicks, 4); trimmed = true; } catch (t1) {}
    if (!trimmed) { try { adj.setInPoint("0"); adj.setOutPoint(durTicks); trimmed = true; } catch (t2) {} }
  }
  if (!trimmed) {
    var durSec = sel.end.seconds - sel.start.seconds;
    try { adj.setInPoint(0, 4); adj.setOutPoint(durSec, 4); trimmed = true; } catch (t3) {}
    if (!trimmed) { try { adj.setInPoint(0); adj.setOutPoint(durSec); } catch (t4) {} }
  }

  try { target.overwriteClip(adj, startSec); }
  catch (e3) { return { ok: false, error: "Couldn't place the adjustment layer: " + e3 }; }

  var added = null, position = -1, tclips = target.clips;
  for (var k = 0; k < tclips.numItems; k++) {
    if (Math.abs(tclips[k].start.seconds - startSec) < 0.002) { added = tclips[k]; position = k; break; }
  }
  // Frame-snap the end to the clip's out, but only ever SHORTEN — never extend, so
  // a rounding overshoot can't clobber the next clip.
  if (added) {
    try { if (added.end.seconds > sel.end.seconds + 0.0005) added.end = sel.end; }
    catch (e4) { logMsg("⚠ Placed, but couldn't snap to the clip's length: " + e4, "warn"); }
  }

  return { ok: true, added: added, position: position, target: target, targetIdx: targetIdx, selTrackIdx: selTrackIdx };
}

/* Checks the "Uniform Scale" box on a clip's Transform effect. Transform's
   Uniform Scale is a boolean property; setValue accepts 1/true/"1" depending on
   build, so all three are tried. Returns true on the first that sticks. */
function setUniformScaleOn(clip) {
  try {
    var comps = clip.components;
    for (var i = 0; i < comps.numItems; i++) {
      var comp = comps[i], dn = "";
      try { dn = String(comp.displayName); } catch (e) {}
      if (dn !== "Transform") continue;
      var props = comp.properties;
      for (var p = 0; p < props.numItems; p++) {
        var prop = props[p], pn = "";
        try { pn = String(prop.displayName); } catch (e2) { continue; }
        if (normName(pn) === normName("Uniform Scale")) {
          try { prop.setValue(1, true); return true; } catch (e3) {}
          try { prop.setValue(true, true); return true; } catch (e4) {}
          try { prop.setValue("1", true); return true; } catch (e5) {}
        }
      }
    }
  } catch (e6) {}
  return false;
}

/* Fitted adjustment layer, then the Transform effect added onto it. Premiere
   can't create a layer with the effect pre-applied, so this is the two-step
   version: place the layer, then add Transform to it in the sequence. */
function DH_fittedAdjustmentLayerTransform(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var r = fittedAdjLayerCore(seq);
    if (!r.ok) return reply({ ok: false, error: r.error });

    var addedFx = false;
    try {
      app.enableQE();
      var qseq = qe.project.getActiveSequence();
      var qTrack = qseq.getVideoTrackAt(r.targetIdx);
      var qClip = (r.position >= 0 && qTrack) ? qeRealClipAt(qTrack, r.position) : null;
      var fx = null; try { fx = qe.project.getVideoEffectByName("Transform"); } catch (ef) {}
      if (qClip && fx) {
        qClip.addVideoEffect(fx); addedFx = true;
        // Default Uniform Scale ON. The effect just landed on the DOM clip
        // (r.added); find its Transform component and check the box.
        if (r.added) {
          var us = setUniformScaleOn(r.added);
          if (!us) logMsg("• Transform added, but couldn't set Uniform Scale — set it manually.", "");
        }
      }
      else if (!fx) logMsg("⚠ 'Transform' effect not found on this system.", "warn");
      else logMsg("⚠ Couldn't locate the new layer in QE to add Transform.", "warn");
    } catch (e2) { logMsg("⚠ Transform step: " + e2, "warn"); }

    return reply({ ok: true, message: "Adjustment layer placed on V" + (r.targetIdx + 1) +
      (addedFx ? " with Transform added." : " — but Transform wasn't added; apply it manually.") });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* 06_Tools bin at the project root (created if missing). */
function getToolsBin() { return getOrCreateBin(app.project.rootItem, "06_Tools"); }

/* Fitted matte: find the matte source item, move it into 06_Tools, and lay it
   over the selected clip on the track above — same proven placement as the
   adjustment layer. kind = "black" | "white" | "color".
   NOTE: Premiere's scripting can't create color mattes or open the New Color
   Matte dialog, so (like the adjustment layer) this reuses a matte you've made
   once. Name them "Black Matte", "White Matte", "Color Matte". */
function fittedMatte(kind, extDir) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });

    var sel = null, selTrackIdx = -1, vts = seq.videoTracks;
    for (var t = 0; t < vts.numTracks && !sel; t++) {
      var clips = vts[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var s = false; try { s = clips[c].isSelected(); } catch (e) {}
        if (s) { sel = clips[c]; selTrackIdx = t; break; }
      }
    }
    if (!sel) return reply({ ok: false, error: "No clip selected on the active sequence." });

    var label = (kind === "black") ? "Black Video" : "White Color Matte";
    var cands = (kind === "black") ? ["Black Video", "Black", "Black Matte"]
                                   : ["White Color Matte", "White Matte", "White"];
    var matte = (kind === "black") ? getBlackSource(seq, extDir) : findItemLoose(app.project.rootItem, cands);
    if (!matte) {
      var how = (kind === "black") ? "File \u25b8 New \u25b8 Black Video" : "File \u25b8 New \u25b8 Color Matte";
      return reply({ ok: false, error: "No '" + label + "' item found in the project. Create one once (" + how + ", name it \"" + label + "\"), then use this button." });
    }

    try { matte.moveBin(getToolsBin()); } catch (e5) { logMsg("⚠ Couldn't move the matte into 06_Tools: " + e5, "warn"); }

    var startSec = sel.start.seconds;
    // Land on the highest empty track over the clip's span, not just the next one up.
    var targetIdx = highestEmptyTrackIdx(seq, selTrackIdx, startSec, sel.end.seconds);
    var target = seq.videoTracks[targetIdx];
    if (!target) return reply({ ok: false, error: "No empty video track above the selected clip, and one couldn't be added." });

    // Constrain the source to the selected clip's EXACT duration BEFORE placing it,
    // so overwriteClip lays it down already-trimmed and never spans later clips on
    // the destination track — same fix as Fitted Adjustment Layer. Ticks are
    // frame-exact; fall back to seconds.
    var durTicks = null;
    try { durTicks = String(Number(sel.end.ticks) - Number(sel.start.ticks)); } catch (edt) {}
    var trimmed = false;
    if (durTicks && durTicks !== "NaN") {
      try { matte.setInPoint("0", 4); matte.setOutPoint(durTicks, 4); trimmed = true; } catch (t1) {}
      if (!trimmed) { try { matte.setInPoint("0"); matte.setOutPoint(durTicks); trimmed = true; } catch (t2) {} }
    }
    if (!trimmed) {
      var durSec = sel.end.seconds - sel.start.seconds;
      try { matte.setInPoint(0, 4); matte.setOutPoint(durSec, 4); trimmed = true; } catch (t3) {}
      if (!trimmed) { try { matte.setInPoint(0); matte.setOutPoint(durSec); } catch (t4) {} }
    }

    try { target.overwriteClip(matte, startSec); }
    catch (e3) { return reply({ ok: false, error: "Couldn't place the matte: " + e3 }); }

    var added = null, tclips = target.clips;
    for (var k = 0; k < tclips.numItems; k++) {
      if (Math.abs(tclips[k].start.seconds - startSec) < 0.002) { added = tclips[k]; break; }
    }
    // Frame-snap the end to the clip's out, but only ever SHORTEN — never extend —
    // so a rounding overshoot can't clobber the next clip.
    if (added) {
      try { if (added.end.seconds > sel.end.seconds + 0.0005) added.end = sel.end; }
      catch (e4) { logMsg("⚠ Placed, but couldn't snap to the clip's length: " + e4, "warn"); }
    }

    return reply({ ok: true, message: label + " placed on V" + (targetIdx + 1) + ", fitted to the selected clip (source in 06_Tools)." });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

function DH_fittedBlackMatte(jsonArg) { var a = safeParse(jsonArg); return fittedMatte("black", a && a.ext ? String(a.ext) : ""); }
function DH_fittedWhiteMatte(jsonArg) { return fittedMatte("white"); }

/* ===================== Edit page: Social Guides ===================== *
 * The guides live in the project at 06_Tools ▸ SOCIAL_GUIDES_JAN_2026 (bins +
 * PNG items), not on disk. We read that bin tree and place a chosen item. */

/* The SOCIAL_GUIDES bin at 06_Tools ▸ Overlays ▸ SOCIAL_GUIDES_*, or null if the
   path is missing. The leaf is matched loosely (starts with "SOCIAL_GUIDES",
   underscores/spaces ignored) so the monthly date suffix doesn't need updating. */
function getSocialGuidesBin() {
  var tools = findBinByName(app.project.rootItem, "06_Tools");
  if (!tools) return null;
  var overlays = findBinByName(tools, "Overlays");
  if (!overlays) return null;
  var kids = overlays.children;
  for (var i = 0; i < kids.numItems; i++) {
    var it = kids[i], isBin = false;
    try { isBin = (it.type === ProjectItemType.BIN); } catch (e) {}
    if (!isBin) continue;
    var nn = String(it.name).toLowerCase().replace(/[^a-z0-9]/g, "");
    if (nn.indexOf("socialguides") === 0) return it;
  }
  return null;
}

/* Walk the bin: sub-bins become "sep" separators, other items become selectable
   entries referenced by nodeId (unique + stable within the session). */
function collectSocialGuides(bin, out) {
  var kids = bin.children;
  var bins = [], items = [];
  for (var i = 0; i < kids.numItems; i++) {
    var it = kids[i], isBin = false;
    try { isBin = (it.type === ProjectItemType.BIN); } catch (e) {}
    if (isBin) bins.push(it); else items.push(it);
  }
  for (var f = 0; f < items.length; f++) {
    var ref = ""; try { ref = String(items[f].nodeId); } catch (e2) {}
    out.push({ type: "file", label: String(items[f].name), ref: ref });
  }
  for (var d = 0; d < bins.length; d++) {
    out.push({ type: "sep", label: String(bins[d].name) });
    collectSocialGuides(bins[d], out);
  }
}

function DH_listSocialGuides(jsonArg) {
  resetLog();
  if (!app.project) return reply({ ok: false, error: "No project open." });
  var guides = getSocialGuidesBin();
  if (!guides) return reply({ ok: false, error: "Couldn't find 06_Tools ▸ Overlays ▸ SOCIAL_GUIDES… in this project." });
  var out = [];
  collectSocialGuides(guides, out);
  return reply({ ok: true, entries: out });
}

/* Find a project item by nodeId under a bin (recursive). */
function findItemByNodeId(bin, id) {
  var kids = bin.children;
  for (var i = 0; i < kids.numItems; i++) {
    var it = kids[i];
    var nid = ""; try { nid = String(it.nodeId); } catch (e) {}
    if (nid === id) return it;
    var isBin = false; try { isBin = (it.type === ProjectItemType.BIN); } catch (e2) {}
    if (isBin) { var deep = findItemByNodeId(it, id); if (deep) return deep; }
  }
  return null;
}

/* The latest end point of any clip on any track, as a Time (or null if empty). */
function seqContentEndTime(seq) {
  var best = null, bestSec = -1, groups = [seq.videoTracks, seq.audioTracks];
  for (var g = 0; g < groups.length; g++) {
    var tr = groups[g];
    for (var t = 0; t < tr.numTracks; t++) {
      var clips = tr[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var e = clips[c].end, s = -1; try { s = e.seconds; } catch (x) {}
        if (s > bestSec) { bestSec = s; best = e; }
      }
    }
  }
  return best;
}

/* Add the chosen guide onto the highest empty video track (or a new one),
   spanning from the sequence start to the end of its last asset. Guides from
   the project bin (legacy) come in by nodeId; guides shipped with the extension
   (Guides/ folder) come in by file path — see DH_addSocialGuideFile. */
function DH_addSocialGuide(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var ref = a && a.ref ? String(a.ref) : "";
  if (!ref) return reply({ ok: false, error: "No guide selected." });
  var seq = app.project.activeSequence;
  if (!seq) return reply({ ok: false, error: "No active sequence." });

  var guides = getSocialGuidesBin();
  if (!guides) return reply({ ok: false, error: "Couldn't find 06_Tools ▸ Overlays ▸ SOCIAL_GUIDES… in this project." });
  var item = findItemByNodeId(guides, ref);
  if (!item) return reply({ ok: false, error: "That guide is no longer in the bin — reopen the list and try again." });
  return reply(placeGuideItem(seq, item, null, 50));
}

/* Guide file shipped in the extension's Guides/ folder: import it once into a
   root "STN Guides" bin (reused on later adds), then place it like any guide.
   a = { path, w, h } — w/h are the PNG's pixel size, read by the panel. */
function DH_addSocialGuideFile(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var path = a && a.path ? String(a.path) : "";
  if (!path) return reply({ ok: false, error: "No guide selected." });
  if (!app.project) return reply({ ok: false, error: "No project open." });
  var seq = app.project.activeSequence;
  if (!seq) return reply({ ok: false, error: "No active sequence." });
  var f = new File(path);
  if (!f.exists) return reply({ ok: false, error: "Guide file not found: " + path });

  var bin = getOrCreateBin(app.project.rootItem, "STN Guides");
  var norm = function (s) { return String(s || "").replace(/\\/g, "/").toLowerCase(); };
  var want = norm(f.fsName);
  var findIn = function () {
    var kids = bin.children;
    for (var i = 0; i < kids.numItems; i++) {
      var mp = ""; try { mp = kids[i].getMediaPath(); } catch (e) {}
      if (mp && norm(mp) === want) return kids[i];
    }
    return null;
  };
  var item = findIn();
  if (!item) {
    try { app.project.importFiles([f.fsName], true, bin, false); }
    catch (eI) { return reply({ ok: false, error: "Couldn't import the guide: " + eI }); }
    item = findIn();
  }
  if (!item) return reply({ ok: false, error: "Imported the guide but couldn't find it in the STN Guides bin." });
  var dims = (a.w > 0 && a.h > 0) ? { w: Number(a.w), h: Number(a.h) } : null;
  var op = (Number(a.opacity) > 0 && Number(a.opacity) <= 100) ? Number(a.opacity) : 50;
  return reply(placeGuideItem(seq, item, dims, op));
}

/* Shared placement: top empty video track (or a new one on top), from 0 to the
   end of the last clip, fitted to the frame, 50% opacity. Returns a reply object. */
function placeGuideItem(seq, item, dims, opacity) {
  var name = String(item.name);
  var op = opacity || 50;
  var endTime = seqContentEndTime(seq);   // Time (or null on an empty sequence)

  // Target the highest track if it's empty. If it has clips, add a NEW track on
  // top (inserted at the top, not the bottom) and place the guide there so it
  // never overwrites existing content.
  var vts = seq.videoTracks, topIdx = vts.numTracks - 1, target = vts[topIdx];
  var topEmpty = false; try { topEmpty = (target.clips.numItems === 0); } catch (e2) {}
  if (!topEmpty) {
    try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0, 0, 0, 0); }
    catch (e3) { logMsg("⚠ Couldn't add a video track: " + e3, "warn"); }
    vts = seq.videoTracks; topIdx = vts.numTracks - 1; target = vts[topIdx];
    var nowEmpty = false; try { nowEmpty = (target.clips.numItems === 0); } catch (e3b) {}
    if (!nowEmpty) {  // fallback if the new track didn't land on top: highest empty track
      for (var ti = vts.numTracks - 1; ti >= 0; ti--) {
        var n = 1; try { n = vts[ti].clips.numItems; } catch (e3c) {}
        if (n === 0) { topIdx = ti; target = vts[ti]; nowEmpty = true; break; }
      }
    }
    if (!nowEmpty) return { ok: false, error: "Couldn't create an empty track above the content for the guide." };
  }
  if (!target) return { ok: false, error: "No video track available for the guide." };

  try { target.overwriteClip(item, 0); }
  catch (e4) { return { ok: false, error: "Couldn't place the guide: " + e4 }; }

  var added = null, tclips = target.clips;
  for (var k = 0; k < tclips.numItems; k++) {
    var s = 1; try { s = tclips[k].start.seconds; } catch (x2) {}
    if (s < 0.002) { added = tclips[k]; break; }
  }
  if (!added && tclips.numItems) added = tclips[tclips.numItems - 1];
  if (added && endTime) { try { added.end = endTime; } catch (e5) { logMsg("⚠ Guide placed, but couldn't stretch it to cover the sequence: " + e5, "warn"); } }
  if (added && op !== 100) { if (!setClipOpacity(added, op)) logMsg("⚠ Guide placed, but couldn't set it to " + op + "% opacity — adjust manually.", "warn"); }

  // Fit the guide to the sequence frame so it lines up at any resolution.
  if (added) {
    var seqW = 0, seqH = 0;
    try { var st = seq.getSettings(); seqW = Number(st.videoFrameWidth); seqH = Number(st.videoFrameHeight); } catch (e6) {}
    if (!seqW || !seqH) { try { seqW = Number(seq.frameSizeHorizontal); seqH = Number(seq.frameSizeVertical); } catch (e7) {} }
    if (seqW && seqH) {
      var fitted = fitClipToFrame(added, seqW, seqH);
      if (!fitted && dims) fitted = setMotionScale(added, Math.min(seqW / dims.w, seqH / dims.h) * 100);
      if (!fitted) logMsg("⚠ Couldn't scale the guide to the frame — use Set to Frame Size if it looks off.", "warn");
      var gd = dims || getMediaDims(added);
      if (gd && Math.abs((gd.w / gd.h) - (seqW / seqH)) > 0.02)
        logMsg("⚠ This guide is " + gd.w + "×" + gd.h + " but the sequence is " + seqW + "×" + seqH + " — pick a guide that matches the format.", "warn");
    }
  }

  return { ok: true, message: "\"" + name + "\" added to V" + (topIdx + 1) + " at " + op + "% opacity, spanning the sequence." };
}

/* Writes Motion > Scale (percent). Used when media metadata has no frame size. */
function setMotionScale(clip, pct) {
  pct = Math.round(pct * 10000) / 10000;
  try {
    var comps = clip.components;
    for (var ci = 0; ci < comps.numItems; ci++) {
      var comp = comps[ci], mn = "", dn = "";
      try { mn = String(comp.matchName); } catch (e) {}
      try { dn = String(comp.displayName); } catch (e2) {}
      if (mn !== "AE.ADBE Motion" && dn !== "Motion") continue;
      var props = comp.properties;
      for (var pi = 0; pi < props.numItems; pi++) {
        var pdn = ""; try { pdn = String(props[pi].displayName); } catch (e3) {}
        if (pdn === "Scale") { try { props[pi].setValue(pct, true); return true; } catch (e4) {} }
      }
    }
  } catch (e5) {}
  return false;
}

/* Set a clip's Opacity to a percentage (0–100) via its intrinsic Opacity param. */
function setClipOpacity(clip, pct) {
  try {
    var comps = clip.components;
    for (var i = 0; i < comps.numItems; i++) {
      var comp = comps[i], cn = "";
      try { cn = String(comp.displayName); } catch (e) {}
      if (!/opacity/i.test(cn)) continue;
      var props = comp.properties;
      for (var j = 0; j < props.numItems; j++) {
        var p = props[j], pn = "";
        try { pn = String(p.displayName); } catch (e2) {}
        if (!/opacity/i.test(pn)) continue;
        try { p.setValue(pct, true); return true; }
        catch (e3) { try { p.setValue(pct); return true; } catch (e4) {} }
      }
    }
  } catch (e5) {}
  return false;
}

/* ===================== Prep: Collapse Video Tracks ===================== *
 * DESTRUCTIVE. Within the "Clips on video tracks" range: delete disabled clips,
 * then reduce V2..Vhigh onto V1 track-by-track (ascending, so the higher track
 * wins on overlap = top-track priority). Once that's done, every empty video
 * track in the sequence — not just the collapsed range — gets deleted, so
 * empty Graphics/TC-burn-in tracks or other leftovers are swept up too. V1 is
 * never deleted, even if empty. This is complex, untestable-here Premiere
 * automation — run it on a DUPLICATE sequence first. Moving with exact source
 * trims and deleting empty tracks are best-effort and depend on the Premiere
 * version's scripting surface. */
/* Remove clips from a QE video track. If disabledOnly, only disabled clips are
   removed; otherwise every clip is removed. Non-ripple removal leaves gaps (which
   we don't care about when clearing), and re-scanning from the top each pass keeps
   indices valid. A guard prevents any chance of an infinite loop. */
function qeClearTrack(qt, disabledOnly) {
  var removed = 0, guard = 0;
  while (guard++ < 2000) {
    var nI = 0; try { nI = qt.numItems; } catch (e) { break; }
    var target = null;
    for (var k = 0; k < nI; k++) {
      var it = qt.getItemAt(k), empty = false;
      try { empty = (it.type === "Empty"); } catch (e2) {}
      if (!empty) { try { if (String(it.name) === "") empty = true; } catch (e3) {} }
      if (empty) continue;
      if (disabledOnly) { var dis = false; try { dis = it.disabled; } catch (e4) {} if (!dis) continue; }
      target = it; break;
    }
    if (!target) break;
    try { target.remove(false, false); removed++; } catch (e5) { break; }
  }
  return removed;
}

function collapseCore(jsonArg) {
  resetLog();
  try {
    var a = safeParse(jsonArg);
    var low  = Math.max(1, parseInt(a.low, 10) || 1);
    var high = Math.max(low, parseInt(a.high, 10) || 1);
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var nTracks = seq.videoTracks.numTracks;
    if (high > nTracks) high = nTracks;
    if (nTracks < 2 || high < 2) return reply({ ok: false, error: "Nothing above V1 to collapse in that range." });

    var startIdx = Math.max(1, low - 1);   // first source track (index; never V1)
    var lastIdx  = high - 1;                // last source track (index)

    var qseq = null; try { app.enableQE(); qseq = qe.project.getActiveSequence(); } catch (e) {}
    if (!qseq) return reply({ ok: false, error: "Couldn't open the QE sequence — the collapse needs it." });

    // Step 1 — delete disabled clips in range FIRST, so they are never nudged down
    // (a surviving disabled clip would move onto V1 and clobber the enabled clip
    // underneath). Detect them via the reliable standard-DOM .disabled flag — QE's
    // own flag can't be trusted — and remove via QE, highest position first so the
    // lower positions stay valid.
    var disabledRemoved = 0;
    for (var t = Math.max(0, low - 1); t <= lastIdx; t++) {
      var std = seq.videoTracks[t], positions = [];
      for (var c = 0; c < std.clips.numItems; c++) {
        var d0 = false; try { d0 = (std.clips[c].disabled === true); } catch (ed) {}
        if (d0) positions.push(c);
      }
      if (positions.length) {
        var qtd = qseq.getVideoTrackAt(t);
        for (var p = positions.length - 1; p >= 0; p--) {
          var qcd = qeRealClipAt(qtd, positions[p]);
          if (qcd) { try { qcd.remove(false, false); disabledRemoved++; } catch (er) {} }
        }
      }
    }
    logMsg("• Removed " + disabledRemoved + " disabled clip(s) in range.", "");

    // Step 2 — nudge each track's clips DOWN onto V1, ascending (V2, then V3, …) so
    // the top track lands last and wins overlaps. We move the *actual timeline clip*
    // via QE moveToTrack, so its Motion + effects + keyframes ride along (unlike
    // overwriteClip, which rebuilds a clean clip from the project item).
    //   moveToTrack(videoTrackShift, audioTrackShift, timeShift, duplicate)
    //   • videoTrackShift = -idx  → move down `idx` tracks to reach V1 (index 0)
    //   • audioTrackShift = 0     → leave audio alone
    //   • timeShift = "00:00:00:00" → keep the same timeline position
    //   • duplicate = 0           → MOVE (clear the source), don't copy
    var moved = 0, moveFail = 0;
    for (var idx = startIdx; idx <= lastIdx; idx++) {
      var guard = 0;
      while (guard++ < 3000) {
        var qt = qseq.getVideoTrackAt(idx);       // re-fetch — the tree changes as we move
        var clip = qeRealClipAt(qt, 0);           // first remaining real clip on this track
        if (!clip) break;
        var ok = false;
        try { clip.moveToTrack(-idx, 0, "00:00:00:00", 0); ok = true; moved++; }
        catch (e2) { moveFail++; logMsg("⚠ V" + (idx + 1) + ": a clip couldn't be nudged down: " + e2, "warn"); }
        if (!ok) break;                            // stop this track rather than spin
      }
    }
    logMsg("• Nudged " + moved + " clip(s) down to V1" + (moveFail ? " (" + moveFail + " failed)" : "") + ".", "");

    // Step 3 — delete EVERY empty video track in the sequence, not just the ones
    // inside the collapsed range (best-effort; track deletion is not broadly
    // scriptable). This sweeps up empty Graphics/TC-burn-in tracks — or any other
    // leftover empty track above V1 — at the same time as the collapsed range.
    // Scan top-down and never touch V1 (index 0), so lower indices stay valid.
    var removedTracks = [];
    var sweepTop = seq.videoTracks.numTracks - 1;
    for (var d = sweepTop; d >= 1; d--) {
      var trk = seq.videoTracks[d], empty = false;
      try { empty = (trk.clips.numItems === 0); } catch (e7) {}
      if (!empty) continue;
      var done = false;
      try { if (typeof qseq.deleteVideoTrack === "function") { qseq.deleteVideoTrack(d); done = true; } } catch (e8) {}
      if (!done) { try { if (typeof qseq.removeVideoTrack === "function") { qseq.removeVideoTrack(d); done = true; } } catch (e9) {} }
      if (done) removedTracks.push(d + 1);
    }
    if (removedTracks.length) logMsg("• Deleted " + removedTracks.length + " empty track(s) across the sequence.", "");
    else logMsg("• Emptied tracks left in place (script can't delete tracks on this version) — right-click a track header ▸ Delete Empty Tracks to tidy up.", "");

    return reply({ ok: true, moved: moved, disabledRemoved: disabledRemoved, removedTracks: removedTracks });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* ===================== Developer: Command ID Explorer ===================== *
 * Probe for a command-execution API and fire a numeric command ID. NOTE:
 * app.executeCommand()/findMenuCommandId() are After Effects APIs; Premiere is
 * not known to expose command-ID execution, so this reports honestly whether the
 * method exists on this build before attempting it. */
function devSnapshot() {
  var s = { seqs: 0, items: 0, activeSeq: "" };
  try { s.seqs = app.project.sequences.numSequences; } catch (e) {}
  try { s.items = app.project.rootItem.children.numItems; } catch (e2) {}
  try { s.activeSeq = app.project.activeSequence ? String(app.project.activeSequence.name) : ""; } catch (e3) {}
  return s;
}
function devDescribeChange(b, a) {
  var parts = [];
  if (a.seqs > b.seqs) parts.push("added " + (a.seqs - b.seqs) + " sequence(s)");
  else if (a.seqs < b.seqs) parts.push("removed " + (b.seqs - a.seqs) + " sequence(s)");
  if (a.items > b.items) parts.push("added " + (a.items - b.items) + " project item(s)");
  else if (a.items < b.items) parts.push("removed " + (b.items - a.items) + " project item(s)");
  if (a.activeSeq !== b.activeSeq) parts.push("active sequence → " + (a.activeSeq || "(none)"));
  return parts.join(", ");
}
function DH_execCommand(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var id = parseInt(a.id, 10);
  if (isNaN(id)) return reply({ ok: false, error: "Enter a numeric command ID." });

  var hasExec = false, hasFind = false;
  try { hasExec = (typeof app.executeCommand === "function"); } catch (e) {}
  try { hasFind = (typeof app.findMenuCommandId === "function"); } catch (e2) {}

  if (!hasExec) {
    return reply({ ok: false,
      error: "no command-ID execution API on this build (app.executeCommand absent — that's an After Effects method).",
      note: "probe: executeCommand=" + hasExec + ", findMenuCommandId=" + hasFind });
  }

  var before = devSnapshot(), errStr = "";
  try { app.executeCommand(id); } catch (e3) { errStr = String(e3); }
  var change = devDescribeChange(before, devSnapshot());

  if (errStr) return reply({ ok: false, error: errStr });
  return reply({ ok: true, result: change || "executed (no detectable state change — watch Premiere)" });
}

/* ===================== Developer: QE Explorer + DOM Inspector ===================== */

/* Evaluate a QE expression and reflect its methods/properties. Whatever is typed
   is eval'd (method calls in the path run), so it doubles as an interactive
   invoker. Reading property values is wrapped per-property and truncated. */
function DH_qeInspect(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var expr = a.expr ? String(a.expr) : "qe.project";
  try { app.enableQE(); } catch (e0) {}
  var obj;
  try { obj = eval(expr); } catch (e) { return reply({ ok: false, error: "eval error: " + e }); }

  var typeStr = (obj === null) ? "null" : typeof obj;
  if (typeStr !== "object" && typeStr !== "function") {
    return reply({ ok: true, value: String(obj), type: typeStr, methods: [], properties: [] });
  }

  var methods = [], properties = [];
  try {
    var rm = obj.reflect.methods;
    for (var i = 0; i < rm.length; i++) {
      var mn = String(rm[i].name);
      if (mn.charAt(0) === "_" || mn === "reflect" || mn === "toString") continue;
      methods.push(mn);
    }
  } catch (e2) {}
  try {
    var rp = obj.reflect.properties;
    for (var j = 0; j < rp.length; j++) {
      var pn = String(rp[j].name);
      if (pn.charAt(0) === "_" || pn === "reflect") continue;
      var pv = "";
      try { pv = String(obj[pn]); } catch (epv) { pv = "(unreadable)"; }
      if (pv.length > 90) pv = pv.substring(0, 90) + "…";
      properties.push(pn + " = " + pv);
    }
  } catch (e3) {}
  methods.sort(); properties.sort();
  return reply({ ok: true, type: typeStr, methods: methods, properties: properties });
}

/* Snapshot of the standard-DOM state used by the DOM Inspector. Beyond the
   sequence/track summary, this deep-walks the SELECTED clip: its intrinsic
   properties (speed, reversed, duration, in/out, disabled) and every matched
   component + parameter value. The result is a flat map of "path → value" so the
   compare step can highlight exactly which properties changed, ala:
     playbackRate  100 ↓ -100
     isReversed    false ↓ true
     Component[2].param[5]  0 ↓ 1                                             */
function domReadParamValue(param) {
  // Try the most informative reads first; fall back gracefully.
  try {
    if (param.isTimeVarying && param.isTimeVarying()) {
      // keyframed — sample at the param's first keyframe time if available
      try {
        var ks = param.getKeys();
        if (ks && ks.length) return "kf@" + ks.length + ":" + String(param.getValueAtKey(ks[0]));
      } catch (ek) {}
      return "(keyframed)";
    }
  } catch (etv) {}
  try { return String(param.getValue()); } catch (e1) {}
  try { return String(param.value); } catch (e2) {}
  return "(unreadable)";
}
function domSnapshotClip(clip, map, prefix) {
  // Intrinsic TrackItem properties.
  function put(k, getter) { try { map[prefix + k] = String(getter()); } catch (e) {} }
  put("name",       function () { return clip.name; });
  put("duration",   function () { return clip.duration ? clip.duration.seconds : ""; });
  put("start",      function () { return clip.start ? clip.start.seconds : ""; });
  put("end",        function () { return clip.end ? clip.end.seconds : ""; });
  put("inPoint",    function () { return clip.inPoint ? clip.inPoint.seconds : ""; });
  put("outPoint",   function () { return clip.outPoint ? clip.outPoint.seconds : ""; });
  put("disabled",   function () { return clip.disabled; });
  put("type",       function () { return clip.type; });
  // Speed / reverse via QE (standard DOM doesn't expose them).
  return map;
}
function domSnapshotQeClip(qc, map, prefix) {
  function put(k, getter) { try { var v = getter(); if (v !== undefined && v !== null) map[prefix + k] = String(v); } catch (e) {} }
  put("playbackRate", function () { return qc.getSpeed ? Math.round(qc.getSpeed() * 100) : undefined; });
  put("isReversed",   function () { try { return qc.getSpeed && qc.getSpeed() < 0; } catch (e) { return undefined; } });
  put("isSpeedReversed", function () { return qc.isSpeedReversed ? qc.isSpeedReversed() : undefined; });
  // Components + parameters.
  try {
    var comps = qc.components;
    var nC = comps ? comps.numItems : 0;
    for (var ci = 0; ci < nC; ci++) {
      var comp = comps[ci];
      var cname = "";
      try { cname = String(comp.name); } catch (ecn) { cname = "Component"; }
      var cpref = prefix + "Component[" + ci + "]." ;
      try {
        var params = comp.properties;
        var nP = params ? params.numItems : 0;
        for (var pi = 0; pi < nP; pi++) {
          var pr = params[pi], pname = "";
          try { pname = String(pr.displayName || pr.name); } catch (epn) { pname = "param"; }
          map[cpref + "param[" + pi + "] " + pname] = domReadParamValue(pr);
        }
      } catch (ep) {}
      map[prefix + "Component[" + ci + "].name"] = cname;
    }
  } catch (ecomp) {}
  return map;
}
function DH_domState(jsonArg) {
  resetLog();
  var st = { seq: "", v: 0, a: 0, items: 0, sel: [], props: {} }, lines = [];
  try {
    var seq = app.project.activeSequence;
    if (seq) {
      st.seq = String(seq.name); st.v = seq.videoTracks.numTracks; st.a = seq.audioTracks.numTracks;
      lines.push("active sequence: " + st.seq);
      lines.push("tracks: " + st.v + " video, " + st.a + " audio");

      // Find selected video clips (standard DOM) and their track/pos for QE matching.
      var picks = [];
      for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var clips = seq.videoTracks[t].clips;
        for (var c = 0; c < clips.numItems; c++) {
          var s = false; try { s = clips[c].isSelected(); } catch (e) {}
          if (s) { st.sel.push("V" + (t + 1) + ":" + String(clips[c].name)); picks.push({ track: t, pos: c, dom: clips[c] }); }
        }
      }
      lines.push("selected clips: " + (st.sel.length ? st.sel.join("; ") : "none"));

      // Deep-snapshot the FIRST selected clip (the workflow is single-clip A→B).
      if (picks.length) {
        var pk = picks[0];
        domSnapshotClip(pk.dom, st.props, "");
        var qseq = null; try { qseq = qeActiveSequence(); } catch (eq) {}
        if (qseq) {
          var qt = null; try { qt = qseq.getVideoTrackAt(pk.track); } catch (eqt) {}
          var qc = qt ? qeRealClipAt(qt, pk.pos) : null;
          if (qc) domSnapshotQeClip(qc, st.props, "");
          else lines.push("(QE clip not matched — component params unavailable)");
        }
        var pc = 0; for (var kk in st.props) if (st.props.hasOwnProperty(kk)) pc++;
        lines.push("captured " + pc + " properties on: " + st.sel[0]);
      } else {
        lines.push("select a clip, then Snapshot to capture its properties");
      }
    } else {
      lines.push("active sequence: (none)");
    }
    st.items = app.project.rootItem.children.numItems;
    lines.push("project items at root: " + st.items);
  } catch (e2) { lines.push("error: " + e2); }
  return reply({ ok: true, state: st, lines: lines });
}

/* ===================== Edit: named effects, transitions, monitor ===================== */

/* List every video effect name available on this system (QE). */
function DH_listVideoEffects(jsonArg) {
  resetLog();
  try {
    try { app.enableQE(); } catch (eq) {}
    if (typeof qe === "undefined" || !qe || !qe.project) {
      return reply({ ok: false, error: "QE is unavailable — cannot enumerate effects." });
    }
    var names = null;
    try { names = qe.project.getVideoEffectList(); } catch (e1) {}
    if (!names || !names.length) {
      // Fallback: index-based enumeration on older builds.
      names = [];
      var n = 0; try { n = qe.project.numVideoEffects; } catch (e2) {}
      for (var i = 0; i < n; i++) {
        var fx = null; try { fx = qe.project.getVideoEffectByIndex(i); } catch (e3) {}
        if (fx && fx.name) names.push(String(fx.name));
      }
    }
    if (!names || !names.length) return reply({ ok: false, error: "No effects returned by QE." });
    var out = [];
    for (var k = 0; k < names.length; k++) {
      var nm = String(names[k]);
      if (nm) out.push(nm);
    }
    out.sort(function (a, b) {
      var la = a.toLowerCase(), lb = b.toLowerCase();
      return la < lb ? -1 : (la > lb ? 1 : 0);
    });
    return reply({ ok: true, effects: out });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* Add any video effect by name to the selected clip(s) — reuses addEffectByName. */
function DH_addEffectNamed(jsonArg) {
  var a = safeParse(jsonArg);
  return addEffectByName(a && a.name ? String(a.name) : "");
}

/* Apply a video transition (Video Transitions ▸ Animation) to the selected clip.
   Best-effort via QE — the addTransition signature isn't officially documented, so
   we try the common forms and report clearly if none take. */
/* Frame rate of the active sequence (fps + integer timecode base). */
function DH_seqFrameRate(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var fps = dhSeqFps(seq);
    if (!fps) return reply({ ok: false, error: "Couldn't read the sequence frame rate." });
    return reply({ ok: true, fps: fps, base: Math.round(fps) });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* fps from sequence settings (videoFrameRate is expressed in ticks per frame). */
function dhSeqFps(seq) {
  var TICKS_PER_SECOND = 254016000000;
  var fps = 0;
  try {
    var st = seq.getSettings();
    if (st && st.videoFrameRate) {
      var ticks = Number(st.videoFrameRate.ticks ? st.videoFrameRate.ticks : st.videoFrameRate);
      if (ticks > 0) fps = TICKS_PER_SECOND / ticks;
    }
  } catch (e) {}
  if (!fps) {
    try {
      var tb = Number(seq.timebase);
      if (tb > 0) fps = TICKS_PER_SECOND / tb;
    } catch (e2) {}
  }
  return fps;
}

/* Frames -> "HH:MM:SS:FF" against the rounded timecode base. */
function dhFramesToTC(frames, base) {
  if (!base || base < 1) base = 24;
  var f = Math.round(frames);
  if (f < 1) f = 1;
  var ff = f % base;
  var totalSec = Math.floor(f / base);
  var ss = totalSec % 60;
  var totalMin = Math.floor(totalSec / 60);
  var mm = totalMin % 60;
  var hh = Math.floor(totalMin / 60);
  function p2(n) { return (n < 10 ? "0" : "") + String(n); }
  return p2(hh) + ":" + p2(mm) + ":" + p2(ss) + ":" + p2(ff);
}

function DH_addTransition(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var name = a && a.name ? String(a.name) : "";
  var edge = a && a.edge ? String(a.edge) : "in";
  var secs = (a && a.seconds) ? Number(a.seconds) : 1;   // .25 / .5 / .75 / 1
  if (!(secs > 0)) secs = 1;
  var toStart = (edge !== "out");   // in point = clip start, out point = clip end
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var sel = null, selTrackIdx = -1, selPos = -1, vts = seq.videoTracks;
    for (var t = 0; t < vts.numTracks && !sel; t++) {
      var clips = vts[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var s = false; try { s = clips[c].isSelected(); } catch (e) {}
        if (s) { sel = clips[c]; selTrackIdx = t; selPos = c; break; }
      }
    }
    if (!sel) return reply({ ok: false, error: "No clip selected on the active sequence." });

    var fps = dhSeqFps(seq);
    if (!fps) fps = 24;
    var base = Math.round(fps);
    var frames = Math.round(secs * fps);
    if (frames < 1) frames = 1;
    var durTC = dhFramesToTC(frames, base);
    logMsg(String(secs) + " x " + fps.toFixed(3) + " fps = " + frames + " frame" + (frames === 1 ? "" : "s") + " (" + durTC + ")");

    app.enableQE();
    var qseq = qe.project.getActiveSequence();
    var tr = null; try { tr = qe.project.getVideoTransitionByName(name); } catch (e2) {}
    if (!tr) return reply({ ok: false, error: "Transition not found on this system: \"" + name + "\". Tell me the exact name from Effects > Video Transitions > Animation." });
    var qClip = qeRealClipAt(qseq.getVideoTrackAt(selTrackIdx), selPos);
    if (!qClip) return reply({ ok: false, error: "Couldn't locate the selected clip in QE." });

    // addToStart = in point, false = out point. Try the known signature forms.
    var applied = false, lastErr = "";
    var forms = [
      function () { qClip.addTransition(tr, toStart, durTC, 0); },
      function () { qClip.addTransition(tr, toStart, durTC); },
      function () { qClip.addTransition(tr, durTC, toStart); },
      function () { qClip.addTransition(tr, toStart); }
    ];
    for (var f = 0; f < forms.length && !applied; f++) {
      try { forms[f](); applied = true; } catch (e3) { lastErr = String(e3); }
    }
    if (!applied) return reply({ ok: false, error: "QE addTransition didn't take (" + lastErr + "). May need a different signature on your build." });
    return reply({ ok: true, message: name + " (" + frames + " fr) applied to the clip's " + (toStart ? "in" : "out") + " point." });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* Richer state snapshot for the Activity Watcher — includes clip counts so
   adds/removes of clips are detected, not just tracks/items. */
function DH_watchState(jsonArg) {
  resetLog();
  var st = { seq: "", vt: 0, at: 0, vclips: 0, aclips: 0, items: 0, sel: [] };
  try {
    var seq = app.project.activeSequence;
    if (seq) {
      st.seq = String(seq.name); st.vt = seq.videoTracks.numTracks; st.at = seq.audioTracks.numTracks;
      for (var t = 0; t < seq.videoTracks.numTracks; t++) {
        var clips = seq.videoTracks[t].clips;
        st.vclips += clips.numItems;
        for (var c = 0; c < clips.numItems; c++) {
          var s = false; try { s = clips[c].isSelected(); } catch (e) {}
          if (s) st.sel.push("V" + (t + 1) + ":" + String(clips[c].name));
        }
      }
      for (var at = 0; at < seq.audioTracks.numTracks; at++) {
        try { st.aclips += seq.audioTracks[at].clips.numItems; } catch (e2) {}
      }
    }
    st.items = app.project.rootItem.children.numItems;
  } catch (e3) {}
  return reply({ ok: true, state: st });
}

/* ==================== Frame.io comment markers (Edit page) ==================== */

/* Inverse of framesToTC: SMPTE timecode string -> absolute frame count.
   Handles drop-frame ("HH:MM:SS;FF" or DF sequences) via the standard formula. */
function tcStringToFrames(tc, info) {
  var m = String(tc).match(/^(\d{1,2})[:;](\d{1,2})[:;](\d{1,2})[:;](\d{1,2})$/);
  if (!m) return -1;
  var h = parseInt(m[1], 10), mn = parseInt(m[2], 10),
      s = parseInt(m[3], 10), f = parseInt(m[4], 10);
  var fps = info.nominal;
  var frames = ((h * 60 + mn) * 60 + s) * fps + f;
  if (info.df) {
    var dropPerMin = Math.round(fps * 0.066666);
    var totalMin = h * 60 + mn;
    frames -= dropPerMin * (totalMin - Math.floor(totalMin / 10));
  }
  return frames;
}

/* Places one sequence marker per entry: { tc, note }. Marker time is the
   entry TC minus the sequence start TC (zeroPoint). Out-of-bounds TCs are
   reported back per-entry rather than failing the batch. */
function DH_fioMarkers(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var entries = a.entries || [];
    if (!entries.length) return reply({ ok: false, error: "No notes to place." });

    var info = tcInfo(fpsFromSeq(seq));
    var ticksPerFrame = Number(seq.timebase);
    var zeroFrames = 0;
    try { zeroFrames = ticksToFrames(seq.zeroPoint, ticksPerFrame); } catch (e) {}
    var endFrames = 0;
    try { endFrames = Number(seq.end) / ticksPerFrame; } catch (e2) {}

    var placed = 0, results = [];
    for (var i = 0; i < entries.length; i++) {
      var ent = entries[i];
      var abs = tcStringToFrames(ent.tc, info);
      var rel = abs - zeroFrames;
      if (abs < 0 || rel < 0 || (endFrames > 0 && rel > endFrames)) {
        results.push({ tc: ent.tc, ok: false });
        continue;
      }
      var seconds = (rel * ticksPerFrame) / TICKS_PER_SECOND;
      var okOne = false;
      try {
        var mk = seq.markers.createMarker(seconds);
        if (mk) {
          try { mk.name = String(ent.note); } catch (e3) {}
          try { mk.comments = String(ent.note); } catch (e4) {}
          try { mk.setColorByIndex(2); } catch (e5) {}   // green — review notes
          okOne = true; placed++;
        }
      } catch (e6) {}
      results.push({ tc: ent.tc, ok: okOne });
    }
    logMsg("• " + placed + " of " + entries.length + " marker(s) placed on \"" +
           String(seq.name) + "\".", placed ? "" : "warn");
    return reply({ ok: placed > 0, placed: placed, total: entries.length, results: results });
  } catch (eT) {
    return reply({ ok: false, error: String(eT) });
  }
}

/* Moves the CTI of the active sequence to the given absolute timecode. */
function DH_fioJump(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var info = tcInfo(fpsFromSeq(seq));
    var abs = tcStringToFrames(a.tc, info);
    if (abs < 0) return reply({ ok: false, error: "Bad timecode: " + a.tc });
    var ticksPerFrame = Number(seq.timebase);
    var zeroFrames = 0;
    try { zeroFrames = ticksToFrames(seq.zeroPoint, ticksPerFrame); } catch (e) {}
    var rel = abs - zeroFrames;
    if (rel < 0) rel = 0;
    var ticks = String(Math.round(rel * ticksPerFrame));
    seq.setPlayerPosition(ticks);
    return reply({ ok: true });
  } catch (eT) {
    return reply({ ok: false, error: String(eT) });
  }
}

/* Identity of the active sequence — polled by the Frame.io Notes section so its
   checklist can follow whichever sequence is front-most. sequenceID is stable
   across renames; name is returned for display only. */
function DH_activeSeqId(jsonArg) {
  resetLog();
  try {
    var seq = app.project ? app.project.activeSequence : null;
    if (!seq) return reply({ ok: true, id: "", name: "" });
    return reply({ ok: true, id: String(seq.sequenceID), name: String(seq.name) });
  } catch (e) {
    return reply({ ok: false, id: "", name: "", error: String(e) });
  }
}

/* ── Variable-speed scan (Prep) ────────────────────────────────────────────
   Neither the standard DOM nor QE exposes time remapping on this build: a
   remapped clip reports getSpeed() 1, carries no remap component, and its
   inPoint/outPoint describe the *remapped* range rather than the source
   range traversed. The FCP7 XML is the only surface that carries the real
   data, so the scan exports the active sequence to a temp XML, reads it,
   and deletes it.

   In the XML each clipitem may carry a <filter> whose effectid is
   "timeremap", with:
     variablespeed  0 = constant, 1 = remapped   (the definitive flag)
     speed          average across the clip's ENTIRE extent — NOT the
                    trimmed portion, and therefore not usable directly
     graphdict      keyframes mapping <when> (remapped output frame) to
                    <value> (true source frame)

   Premiere seeds virtual keyframes at the clip's in and out, so the source
   range actually traversed is graph(out) - graph(in), and the constant rate
   that reproduces it over the same timeline duration is

       rate = (graph(out) - graph(in)) / (out - in)

   graphAt() still interpolates between bracketing keys rather than assuming
   an exact hit, so a build that omits the virtual keys degrades gracefully.
   Read-only — the sequence is never modified. */

function vsReadXmlText(path) {
  var f = new File(path);
  if (!f.exists) return "";
  var txt = "";
  try {
    f.encoding = "UTF-8";
    f.open("r");
    txt = f.read();
    f.close();
  } catch (e) { try { f.close(); } catch (e2) {} return ""; }
  return txt;
}

/* E4X cannot ingest a BOM, an XML prolog or a DOCTYPE — strip all three. */
function vsStripProlog(txt) {
  var s = String(txt);
  if (s.length && s.charCodeAt(0) === 65279) s = s.substring(1);
  s = s.replace(/^\s*<\?xml[^>]*\?>/, "");
  s = s.replace(/^\s*<!DOCTYPE[^>]*>/, "");
  return s;
}

/* Value of the remap graph at output frame w: exact key, else linear
   interpolation between the bracketing pair, else clamped to the ends. */
function vsGraphAt(keys, w) {
  var i;
  if (!keys || keys.length === 0) return null;
  for (i = 0; i < keys.length; i++) {
    if (keys[i].when === w) return keys[i].value;
  }
  for (i = 0; i < keys.length - 1; i++) {
    var a = keys[i], b = keys[i + 1];
    if (w > a.when && w < b.when) {
      var span = b.when - a.when;
      if (span <= 0) return a.value;
      return a.value + (b.value - a.value) * ((w - a.when) / span);
    }
  }
  if (w <= keys[0].when) return keys[0].value;
  return keys[keys.length - 1].value;
}

/* Shared collector: exports a temp XML, parses every variable-speed clipitem,
   deletes the temp, and returns { ok, hits } or { ok:false, error }. Both the
   scan and the build run off this so their numbers can never diverge. */
function vsCollectHits(seq) {
  var tmpPath = "";
  try {
    tmpPath = Folder.temp.fsName + "/dh_vspeed_" + (new Date()).getTime() + ".xml";
    try { exportFcpXml(seq, tmpPath); }
    catch (eX) { return { ok: false, error: "XML export failed: " + String(eX) }; }

    var raw = vsReadXmlText(tmpPath);
    if (!raw) return { ok: false, error: "Could not read the exported XML." };

    var root;
    try {
      XML.ignoreWhitespace = true;
      XML.ignoreComments = true;
      root = new XML(vsStripProlog(raw));
    } catch (eP) { return { ok: false, error: "XML parse failed: " + String(eP) }; }

    var seqNode = root.sequence[0];
    if (!seqNode) return { ok: false, error: "No sequence node in the XML." };

    var vtracks = seqNode.media.video.track;
    var hits = [], scanned = 0;
    var t, c, k, p;

    for (t = 0; t < vtracks.length(); t++) {
      var clips = vtracks[t].clipitem;
      for (c = 0; c < clips.length(); c++) {
        var ci = clips[c];
        scanned++;

        var tmEffect = null;
        var filters = ci.filter;
        for (k = 0; k < filters.length(); k++) {
          var eff = filters[k].effect;
          if (!eff || eff.length() === 0) continue;
          if (String(eff[0].effectid) === "timeremap") { tmEffect = eff[0]; break; }
        }
        if (!tmEffect) continue;

        var pVar = null, pSpeed = null, pGraph = null, pRev = null;
        var params = tmEffect.parameter;
        for (p = 0; p < params.length(); p++) {
          var pid = String(params[p].parameterid);
          if (pid === "variablespeed") pVar = params[p];
          else if (pid === "speed")    pSpeed = params[p];
          else if (pid === "graphdict") pGraph = params[p];
          else if (pid === "reverse")  pRev = params[p];
        }

        var isVar = false;
        if (pVar) { isVar = (parseInt(String(pVar.value), 10) === 1); }
        if (!isVar) continue;

        var keys = [];
        if (pGraph) {
          var kfs = pGraph.keyframe;
          for (k = 0; k < kfs.length(); k++) {
            var wv = parseFloat(String(kfs[k].when));
            var vv = parseFloat(String(kfs[k].value));
            if (!isNaN(wv) && !isNaN(vv)) keys.push({ when: wv, value: vv });
          }
        }

        var inF  = parseFloat(String(ci["in"]));
        var outF = parseFloat(String(ci.out));
        var stF  = parseFloat(String(ci.start));
        var enF  = parseFloat(String(ci.end));
        if (isNaN(inF) || isNaN(outF)) continue;

        var srcIn  = vsGraphAt(keys, inF);
        var srcOut = vsGraphAt(keys, outF);
        var tlSpan = outF - inF;
        var srcSpan = (srcIn === null || srcOut === null) ? 0 : (srcOut - srcIn);
        var rate = (tlSpan > 0 && srcSpan > 0) ? (srcSpan / tlSpan) : 0;

        var reversed = false;
        if (pRev) reversed = (String(pRev.value).toUpperCase() === "TRUE");

        var avgSpeed = pSpeed ? parseFloat(String(pSpeed.value)) : 0;

        hits.push({
          track: t + 1,
          name: String(ci.name),
          tlStart: stF,
          tlEnd: enF,
          remapIn: inF,
          remapOut: outF,
          srcIn: (srcIn === null) ? -1 : Math.round(srcIn * 100) / 100,
          srcOut: (srcOut === null) ? -1 : Math.round(srcOut * 100) / 100,
          srcSpan: Math.round(srcSpan * 100) / 100,
          tlSpan: tlSpan,
          rate: Math.round(rate * 10000) / 100,
          avgSpeed: Math.round(avgSpeed * 100) / 100,
          reversed: reversed,
          keyCount: keys.length
        });
      }
    }

    return { ok: true, scanned: scanned, tracks: vtracks.length(), hits: hits };
  } catch (e) {
    return { ok: false, error: String(e) };
  } finally {
    if (tmpPath) { try { var tf = new File(tmpPath); if (tf.exists) tf.remove(); } catch (eR) {} }
  }
}

/* ── Build constant-speed duplicates (Prep) ────────────────────────────────
   For every variable-speed clip the collector finds, lay a constant-speed
   copy on the nearest free track above it, spanning the same timeline range
   and traversing the same true source range.

   Sequence of operations per clip, and why:
     1. Trim the projectItem to the TRUE source range first. overwriteClip
        honours the projectItem's current in/out, so laying it down already
        trimmed avoids a full-length clip momentarily spanning — and
        clobbering — later content on the destination track.
     2. Place with overwriteClip at the original's start.
     3. Apply the constant rate via QE setSpeed; the DOM has no speed setter.
     4. Re-assert end, because setSpeed recalculates duration from the new
        rate and will otherwise leave the copy long or short.

   Video only — linked audio is not carried. Clips are processed in descending
   timeline order so that any track added on top never invalidates an index
   resolved earlier. */
function varSpeedCore(jsonArg) {
  resetLog();
  try {
    var proj = app.project;
    if (!proj) return reply({ ok: false, error: "No project open." });
    var seq = proj.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });

    var res = vsCollectHits(seq);
    if (!res.ok) return reply({ ok: false, error: res.error });
    var hits = res.hits;
    if (hits.length === 0) return reply({ ok: false, error: "No variable-speed clips found — nothing to build." });

    var fps = fpsFromSeq(seq);
    if (!fps || isNaN(fps) || fps <= 0) return reply({ ok: false, error: "Couldn't determine sequence frame rate." });
    var ticksPerFrame = TICKS_PER_SECOND / fps;

    /* Ascending timeline order. overwriteClip lays a copy down at 100% speed,
       so between placement and setSpeed its length equals the SOURCE span,
       which on any clip faster than 100% overhangs its final out point.
       Working left to right means each copy is sped up and trimmed to its real
       length before the next copy to its right is placed, so that overhang can
       never clobber a finished neighbour. (Descending did exactly that to a
       butted pair.) Adding a track appends above, so indices resolved earlier
       stay valid either way. */
    hits.sort(function (a, b) { return a.tlStart - b.tlStart; });

    logMsg("\u2022 Scanned " + res.scanned + " clip(s) across " + res.tracks +
           " video track(s) \u2014 " + hits.length + " with variable speed.", "");
    for (var q = 0; q < hits.length; q++) {
      var d = hits[q];
      logMsg("\u2500\u2500\u2500\u2500 V" + d.track + "  " + d.name + (d.reversed ? "   [REVERSED]" : ""), "");
      logMsg("     timeline " + d.tlStart + "\u2013" + d.tlEnd + " (" + d.tlSpan + "f)   true source " +
             d.srcIn + "\u2013" + d.srcOut + " (" + d.srcSpan + "f)   \u2192 " + d.rate + "%", "");
    }

    var built = 0, failed = 0, i;

    for (i = 0; i < hits.length; i++) {
      var x = hits[i];
      var label = "V" + x.track + "  " + x.name;

      if (x.srcIn < 0 || x.srcOut < 0 || x.srcSpan <= 0 || x.rate <= 0) {
        logMsg("\u2717 " + label + " \u2014 unusable graph data, skipped.", "err"); failed++; continue;
      }

      var srcTrack = seq.videoTracks[x.track - 1];
      if (!srcTrack) { logMsg("\u2717 " + label + " \u2014 source track missing.", "err"); failed++; continue; }

      /* Locate the DOM clip by matching its start frame to the XML's. */
      var startSec = x.tlStart * (ticksPerFrame / TICKS_PER_SECOND);
      var endSec   = x.tlEnd   * (ticksPerFrame / TICKS_PER_SECOND);
      var srcClip = null, c;
      for (c = 0; c < srcTrack.clips.numItems; c++) {
        var cs = 0; try { cs = srcTrack.clips[c].start.seconds; } catch (e0) {}
        if (Math.abs(cs - startSec) < 0.002) { srcClip = srcTrack.clips[c]; break; }
      }
      if (!srcClip) { logMsg("\u2717 " + label + " \u2014 couldn't match the clip in the timeline.", "err"); failed++; continue; }

      var pItem = null; try { pItem = srcClip.projectItem; } catch (e1) {}
      if (!pItem) { logMsg("\u2717 " + label + " \u2014 no project item.", "err"); failed++; continue; }

      /* 1 — trim the projectItem to the true source range (ticks, with the
             bare-signature fallback this codebase already relies on) */
      var inTicks  = String(Math.round(x.srcIn  * ticksPerFrame));
      var outTicks = String(Math.round(x.srcOut * ticksPerFrame));
      var trimmed = false;
      try { pItem.setInPoint(inTicks, 4); pItem.setOutPoint(outTicks, 4); trimmed = true; } catch (t1) {}
      if (!trimmed) { try { pItem.setInPoint(inTicks); pItem.setOutPoint(outTicks); trimmed = true; } catch (t2) {} }
      if (!trimmed) { logMsg("\u2717 " + label + " \u2014 couldn't set source in/out.", "err"); failed++; continue; }

      /* 2 — nearest free track above, adding one on top only if needed */
      /* Test track availability against the WORST-CASE span the copy occupies
         at any point — the untrimmed 100% length — not just its final span,
         otherwise a track holding content just past the out point would be
         judged free and then partially overwritten during placement. */
      var rawEndSec = startSec + (x.srcSpan * (ticksPerFrame / TICKS_PER_SECOND));
      var guardEndSec = (rawEndSec > endSec) ? rawEndSec : endSec;
      var targetIdx = highestEmptyTrackIdx(seq, x.track - 1, startSec, guardEndSec);
      var target = seq.videoTracks[targetIdx];
      if (!target) { logMsg("\u2717 " + label + " \u2014 no free track above.", "err"); failed++; continue; }

      try { target.overwriteClip(pItem, startSec); }
      catch (e2) { logMsg("\u2717 " + label + " \u2014 placement failed: " + e2, "err"); failed++; continue; }

      /* locate what we just laid down */
      var placed = null, placedIdx = -1;
      for (c = 0; c < target.clips.numItems; c++) {
        var ps = 0; try { ps = target.clips[c].start.seconds; } catch (e3) {}
        if (Math.abs(ps - startSec) < 0.002) { placed = target.clips[c]; placedIdx = c; break; }
      }
      if (!placed) { logMsg("\u26a0 " + label + " \u2014 placed on V" + (targetIdx + 1) + " but couldn't be re-found; speed not applied.", "warn"); failed++; continue; }

      /* 3 — constant rate via QE */
      var rateFactor = x.rate / 100;
      var speedOk = false;
      try {
        app.enableQE();
        var qseq = qe.project.getActiveSequence();
        var qtrack = qseq ? qseq.getVideoTrackAt(targetIdx) : null;
        var qclip = qtrack ? qeRealClipAt(qtrack, placedIdx) : null;
        if (qclip) {
          /* ripple = false: a ripple edit would shove every later clip on the
             destination track rightward as each copy is retimed. */
          try { qclip.setSpeed(rateFactor, "00:00:00:00", false, false, false); speedOk = true; }
          catch (s1) {
            try { qclip.setSpeed(rateFactor); speedOk = true; } catch (s2) {}
          }
        }
      } catch (e4) {}
      if (!speedOk) logMsg("\u26a0 " + label + " \u2014 copy placed on V" + (targetIdx + 1) + " but setSpeed failed; set " + x.rate + "% by hand.", "warn");

      /* 4 — re-assert the end, since setSpeed recalculates duration */
      try {
        var endT = new Time();
        endT.seconds = endSec;
        placed.end = endT;
      } catch (e5) {
        logMsg("\u26a0 " + label + " \u2014 couldn't re-trim the tail; check the out point.", "warn");
      }

      logMsg("\u2713 " + label + "  \u2192  V" + (targetIdx + 1) +
             "   src " + x.srcIn + "\u2013" + x.srcOut +
             "   @ " + x.rate + "%", "ok");
      built++;
    }

    logMsg("\u2022 " + built + " built, " + failed + " skipped.", "");
    return reply({ ok: true, built: built, failed: failed });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* ── Sequence & settings report (Developer) ────────────────────────────────
   Dumps the active sequence's own properties plus everything getSettings()
   exposes. The settings object is enumerated reflectively rather than by a
   hard-coded key list, so anything a given Premiere build exposes shows up
   without this needing to be updated. Read-only. */
function DH_sequenceInfo(jsonArg) {
  resetLog();
  try {
    var proj = app.project;
    if (!proj) return reply({ ok: false, error: "No project open." });
    var seq = proj.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });

    function safe(fn) {
      var v; try { v = fn(); } catch (e) { return "err"; }
      if (typeof v === "undefined" || v === null) return "n/a";
      return String(v);
    }

    logMsg("\u2500\u2500 Project", "ok");
    logMsg("   name: " + safe(function () { return proj.name; }), "");
    logMsg("   path: " + safe(function () { return proj.path; }), "");

    logMsg("\u2500\u2500 Sequence", "ok");
    logMsg("   name: " + safe(function () { return seq.name; }), "");
    logMsg("   sequenceID: " + safe(function () { return seq.sequenceID; }), "");
    logMsg("   projectItemID: " + safe(function () { return seq.projectItem.nodeId; }), "");

    var fps = 0;
    try { fps = fpsFromSeq(seq); } catch (eF) { fps = 0; }
    logMsg("   timebase: " + safe(function () { return seq.timebase; }) +
           "  (" + (fps ? (Math.round(fps * 1000) / 1000) : "?") + " fps)", "");
    logMsg("   frame size: " + safe(function () { return seq.frameSizeHorizontal; }) +
           " \u00d7 " + safe(function () { return seq.frameSizeVertical; }), "");
    logMsg("   par: " + safe(function () { return seq.videoPixelAspectRatio; }) +
           "   fieldType: " + safe(function () { return seq.videoFieldType; }), "");
    logMsg("   zeroPoint: " + safe(function () { return seq.zeroPoint; }), "");
    logMsg("   end: " + safe(function () { return seq.end; }), "");
    logMsg("   inPoint: " + safe(function () { return seq.getInPointAsTime().seconds; }) +
           "s   outPoint: " + safe(function () { return seq.getOutPointAsTime().seconds; }) + "s", "");
    logMsg("   video tracks: " + safe(function () { return seq.videoTracks.numTracks; }) +
           "   audio tracks: " + safe(function () { return seq.audioTracks.numTracks; }), "");
    logMsg("   markers: " + safe(function () { return seq.markers.numMarkers; }), "");

    /* reflective settings dump */
    var st = null;
    try { st = seq.getSettings(); } catch (eS) { st = null; }
    if (!st) {
      logMsg("\u2500\u2500 getSettings(): unavailable on this build.", "warn");
    } else {
      var keys = [], k;
      for (k in st) { keys.push(String(k)); }
      keys.sort();
      logMsg("\u2500\u2500 getSettings()  \u2014 " + keys.length + " exposed", "ok");
      for (var i = 0; i < keys.length; i++) {
        var kk = keys[i];
        var val = "n/a";
        try {
          var raw = st[kk];
          if (typeof raw === "function") continue;
          val = String(raw);
        } catch (eV) { val = "err"; }
        logMsg("   " + kk + ": " + val, "");
      }
    }

    return reply({ ok: true });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* ====================== VOICE OVER (ElevenLabs) ======================
 * The panel does all network and disk work — ExtendScript's Socket has no
 * TLS, so it can never reach api.elevenlabs.io. By the time the host is
 * called, the audio already exists on disk. These two functions only answer
 * "where do I write?" and "put this file on the timeline".
 *
 *   DH_voContext(jsonArg) -> { ok, projectDir, voDir, projectName,
 *                              audioTracks, playhead }
 *   DH_importVO(jsonArg)  -> { ok, error, track, at, log:[{msg,cls}] }
 * ==================================================================== */

/* ---- MMDD stamp, shared by the disk folder and the project bin ---- */
function DH_mmdd() {
  var d = new Date();
  var m = d.getMonth() + 1, dy = d.getDate();
  return (m < 10 ? "0" : "") + m + (dy < 10 ? "0" : "") + dy;
}

/* Case-insensitive child-folder lookup. Job templates get renamed by hand all
   the time, so "02_AUDIO" and "02_Audio" both have to resolve. Prefix matching
   is deliberate: "02_Audio_MIX" should still count as the audio folder. */
function DH_findChildFolder(parentFolder, name) {
  var want = String(name).toLowerCase();
  var kids, i, f, nm;
  try { kids = parentFolder.getFiles(); } catch (e) { return null; }
  if (!kids) return null;

  /* Exact match wins before any prefix match, so 01_VO is never shadowed by
     a folder like 01_VOX sitting next to it. */
  for (i = 0; i < kids.length; i++) {
    f = kids[i];
    if (!(f instanceof Folder)) continue;
    nm = String(f.name).toLowerCase();
    if (nm === want) return f;
  }
  for (i = 0; i < kids.length; i++) {
    f = kids[i];
    if (!(f instanceof Folder)) continue;
    nm = String(f.name).toLowerCase();
    if (nm.indexOf(want) === 0) return f;
  }
  return null;
}

/* Same hard guard as the panel side: a folder is only ever created while a
   write is genuinely in progress. DH_voContext runs on panel boot and on page
   navigation, so any resolve path that reached a create call left empty MMDD
   folders behind in whatever job happened to be open. */
var DH_WRITING = false;

function DH_childFolder(parentFolder, name, create) {
  var found = DH_findChildFolder(parentFolder, name);
  if (found) return found;
  if (!create || !DH_WRITING) return null;
  try {
    var f = new Folder(parentFolder.fsName + "/" + name);
    if (!f.exists) f.create();
    if (f.exists) return f;
  } catch (e) {}
  return null;
}

/* Locate the job's asset root. The project lives in a Premiere folder; the
   assets folder is either a sibling of it or an ancestor that contains it.
   Rather than assume one shape, walk up a few levels and take the first hit,
   checking each level itself and its children. Four levels is enough for
   every layout that has come through and stops well short of the drive root. */
function DH_findAssetsRoot(startFolder) {
  var cur = startFolder, hop, hit;
  for (hop = 0; hop < 4 && cur; hop++) {
    try {
      if (String(cur.name).toLowerCase().indexOf("01_asset") === 0) return cur;
    } catch (e1) {}
    hit = DH_findChildFolder(cur, "01_ASSETS");
    if (hit) return hit;
    try { cur = cur.parent; } catch (e2) { cur = null; }
  }
  return null;
}

/* Resolve where a generated file belongs on disk:
 *   <assets root>/02_Audio/01_VO/<MMDD>/
 * The MMDD folder is created; the two above it are only created when the
 * assets root was found, so a stray "01_ASSETS" is never invented next to
 * someone's project. Falls back to the old behaviour (a folder beside the
 * project) when the template does not match, and reports which happened so
 * the panel can say so out loud instead of writing somewhere unexpected.
 *
 * leaf: the audio subfolder to target, e.g. "01_VO".
 * Returns { dir, matched, why }.
 */
/* create=false resolves the path without touching the disk.
   DH_voContext runs when the panel opens, so creating folders during resolve
   meant simply launching Deckhand left an empty MMDD folder in every job that
   was open - whether or not anyone recorded anything. Folders are now created
   at write time only. */
function DH_audioOutDir(leaf, create) {
  var mk = (create === true);
  var projFolder = null;
  try {
    var p = app.project.path;
    if (p) {
      var pf = new File(p);
      if (pf && pf.parent) projFolder = pf.parent;
    }
  } catch (e) {}

  if (!projFolder) {
    var tmp = "";
    try { tmp = Folder.temp.fsName; } catch (e2) { tmp = ""; }
    return { dir: tmp, matched: false, why: "Project has not been saved — writing to the temp folder." };
  }

  var assets = DH_findAssetsRoot(projFolder);
  if (assets) {
    var audio = DH_childFolder(assets, "02_Audio", mk);
    if (audio) {
      var leafF = DH_childFolder(audio, leaf, mk);
      if (leafF) {
        var dated = DH_childFolder(leafF, DH_mmdd(), mk);
        if (dated) return { dir: dated.fsName, matched: true, why: "" };
        /* Resolving only: report where the file will go without making it. */
        if (!mk) return { dir: leafF.fsName + "/" + DH_mmdd(), matched: true, why: "" };
        return { dir: leafF.fsName, matched: true, why: "Could not create the " + DH_mmdd() + " folder — writing one level up." };
      }
      if (!mk) return { dir: audio.fsName + "/" + leaf + "/" + DH_mmdd(), matched: true, why: "" };
    }
    if (!mk) return { dir: assets.fsName + "/02_Audio/" + leaf + "/" + DH_mmdd(), matched: true, why: "" };
  }

  /* No template match: keep the old behaviour so a generation never fails
     outright over folder naming. */
  var fb = projFolder.fsName + "/STN_VO";
  if (!mk) return { dir: fb, matched: false,
    why: "No 01_ASSETS folder found near the project — will write beside the project instead." };
  try {
    var ff = new Folder(fb);
    if (!ff.exists) ff.create();
    if (ff.exists) return { dir: ff.fsName, matched: false,
      why: "No 01_ASSETS folder found near the project — writing beside the project instead." };
  } catch (e3) {}
  return { dir: projFolder.fsName, matched: false,
    why: "Could not create an output folder — writing beside the project." };
}

function DH_voContext(jsonArg) {
  resetLog();
  try {
    if (!app.project) return reply({ ok: false, error: "No project open." });

    var seq = app.project.activeSequence;
    var nTracks = 0, head = "", pName = "";

    if (seq) {
      try { nTracks = seq.audioTracks.numTracks; } catch (e1) { nTracks = 0; }
      try {
        var fps = fpsFromSeq(seq);
        var info = tcInfo(fps);
        var pos = seq.getPlayerPosition();
        head = framesToTC(Math.round(pos.seconds * fps), info);
      } catch (e2) { head = ""; }
    }
    try { pName = app.project.name; } catch (e3) { pName = ""; }

    var vo = DH_audioOutDir("01_VO", false);
    if (!vo.dir) return reply({ ok: false, error: "Could not resolve a folder to write audio into." });

    return reply({
      ok: true,
      projectName: pName,
      voDir: String(vo.dir).replace(/\\/g, "/"),
      voMatched: vo.matched,
      voWhy: vo.why,
      dateStamp: DH_mmdd(),
      audioTracks: nTracks,
      playhead: head,
      hasSequence: seq ? true : false
    });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* Build (or find) a nested bin path from the project root and return the
   deepest bin. getOrCreateBin matches an existing bin by name, so an editor's
   own 02_Audio bin is reused rather than duplicated.

   path is an array, e.g. ["02_Audio", "01_VO", "Deckhand_VO", "0724"].
   Any failure mid-walk returns the deepest bin reached, so a generation still
   lands somewhere sane instead of erroring out over bin structure. */
function DH_binPath(path) {
  var bin = app.project.rootItem, i, next;
  if (!path || !path.length) return bin;
  for (i = 0; i < path.length; i++) {
    if (!path[i]) continue;
    try {
      next = getOrCreateBin(bin, String(path[i]));
      if (!next) return bin;
      bin = next;
    } catch (e) { return bin; }
  }
  return bin;
}

/* Walk a bin tree looking for an item already pointing at this file, so
   regenerating a take does not stack duplicate project items. */
function DH_findByMediaPath(bin, wanted) {
  var i, child, mp, found;
  if (!bin || !bin.children) return null;
  for (i = 0; i < bin.children.numItems; i++) {
    child = bin.children[i];
    if (!child) continue;
    try {
      if (child.type === ProjectItemType.BIN) {
        found = DH_findByMediaPath(child, wanted);
        if (found) return found;
        continue;
      }
    } catch (eB) {}
    mp = "";
    try { mp = String(child.getMediaPath()); } catch (eM) { mp = ""; }
    if (mp && mp.replace(/\\/g, "/").toLowerCase() === wanted) return child;
  }
  return null;
}

/* True when nothing on this track overlaps [startSec, endSec). A tiny epsilon
   keeps a clip that ends exactly on the playhead from counting as a collision. */
function DH_audioTrackFree(track, startSec, endSec) {
  var c, cs, ce;
  try {
    for (c = 0; c < track.clips.numItems; c++) {
      cs = track.clips[c].start.seconds;
      ce = track.clips[c].end.seconds;
      if (ce > startSec + 0.0005 && cs < endSec - 0.0005) return false;
    }
  } catch (e) { return false; }
  return true;
}

function DH_importVO(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var filePath = String(a.path || "");
  var wantTrack = (a.track === undefined) ? -1 : parseInt(a.track, 10);
  if (isNaN(wantTrack)) wantTrack = -1;
  /* binPath is an array of bin names walked from the project root. A bare
     string is still accepted so an older panel build cannot break placement. */
  var binPath = a.binPath;
  if (!binPath || !binPath.length) binPath = [String(a.bin || "STN_VO")];
  var binLabel = binPath.join(" > ");

  try {
    if (!app.project) return reply({ ok: false, error: "No project open." });
    if (!filePath) return reply({ ok: false, error: "No file path given." });

    var f = new File(filePath);
    if (!f.exists) return reply({ ok: false, error: "Rendered file is missing: " + filePath });

    /* place:false imports without touching the sequence, so a take can be
       captured with no sequence open at all. The sequence checks below only
       apply when we are actually going to lay the clip down. */
    var noPlace = (a.place === false);

    var seq = app.project.activeSequence;
    var nTracks = 0;
    if (seq) { try { nTracks = seq.audioTracks.numTracks; } catch (eT) { nTracks = 0; } }

    if (!noPlace) {
      if (!seq) return reply({ ok: false, error: "No active sequence — open a sequence and try again." });
      if (!nTracks) return reply({ ok: false, error: "This sequence has no audio tracks." });
    }

    /* ---- import (or reuse an existing item for the same file) ---- */
    var wanted = filePath.replace(/\\/g, "/").toLowerCase();
    var item = DH_findByMediaPath(app.project.rootItem, wanted);

    if (!item) {
      var bin = DH_binPath(binPath);
      var ok = false;
      try { ok = app.project.importFiles([filePath], true, bin, false); } catch (eI) { ok = false; }
      if (!ok) return reply({ ok: false, error: "Premiere refused to import the audio file." });

      item = DH_findByMediaPath(bin, wanted);
      if (!item) item = DH_findByMediaPath(app.project.rootItem, wanted);
      if (!item) return reply({ ok: false, error: "Imported, but the project item could not be located." });
      logMsg("Imported " + item.name + " into " + binLabel + ".", "");
    } else {
      logMsg("Reusing existing project item " + item.name + ".", "");
    }

    if (noPlace) {
      return reply({ ok: true, placed: false, imported: true, name: String(item.name), bin: binLabel });
    }

    /* ---- where does it land ---- */
    var startSec = 0;
    try { startSec = seq.getPlayerPosition().seconds; } catch (eP) { startSec = 0; }

    var durSec = 0;
    try {
      var od = item.getOutPoint();
      if (od && od.seconds) durSec = od.seconds;
    } catch (eD) { durSec = 0; }
    if (!durSec) {
      /* MP3 duration is unknown until Premiere conforms it. Reserve a nominal
         window so track selection still has something to test against. */
      durSec = 1;
    }
    var endSec = startSec + durSec;

    var idx = -1, t;
    if (wantTrack >= 0) {
      if (wantTrack >= nTracks)
        return reply({ ok: false, error: "A" + (wantTrack + 1) + " does not exist in this sequence." });
      idx = wantTrack;
    } else {
      for (t = 0; t < nTracks; t++) {
        if (DH_audioTrackFree(seq.audioTracks[t], startSec, endSec)) { idx = t; break; }
      }
      /* Everything is busy at the playhead. Rather than refuse and make the
         editor go clear a track, add one at the bottom of the audio stack via
         QE and use that. addTracks appends, so existing patching is untouched. */
      if (idx < 0) {
        var added = false;
        try {
          app.enableQE();
          var qs = qe.project.getActiveSequence();
          if (qs) { qs.addTracks(0, 0, 1, seq.audioTracks.numTracks, 0, 0); added = true; }
        } catch (eA) { added = false; }

        if (added) {
          var nowTracks = 0;
          try { nowTracks = seq.audioTracks.numTracks; } catch (eN2) { nowTracks = 0; }
          if (nowTracks > nTracks) {
            idx = nowTracks - 1;
            logMsg("All audio tracks were busy at the playhead — added A" + (idx + 1) + ".", "");
          }
        }
        if (idx < 0)
          return reply({ ok: false, error: "Every audio track is occupied at the playhead and a new one could not be added." });
      }
    }

    var track = seq.audioTracks[idx];
    if (!track) return reply({ ok: false, error: "Could not access audio track A" + (idx + 1) + "." });

    if (wantTrack >= 0 && !DH_audioTrackFree(track, startSec, endSec))
      logMsg("A" + (idx + 1) + " already had media at the playhead — it was overwritten.", "warn");

    try {
      track.overwriteClip(item, startSec);
    } catch (eO) {
      return reply({ ok: false, error: "Placement failed: " + String(eO) });
    }

    /* ---- report back in timecode, not seconds ---- */
    var at = "";
    try {
      var fps = fpsFromSeq(seq);
      at = framesToTC(Math.round(startSec * fps), tcInfo(fps));
    } catch (eF) { at = startSec.toFixed(2) + "s"; }

    return reply({ ok: true, track: "A" + (idx + 1), at: at, name: item.name });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* Where the project file lives on disk. The Audio page walks up from here to
   build 01_ASSETS > 02_Audio > 01_VO for the take destination. */
function DH_projectPath(jsonArg) {
  resetLog();
  try {
    if (!app.project) return reply({ ok: false, error: "No project open." });
    var p = "";
    try { p = String(app.project.path || ""); } catch (e) { p = ""; }
    if (!p) return reply({ ok: false, error: "This project has not been saved yet, so it has no folder to build from." });
    return reply({ ok: true, path: p.replace(/\\/g, "/") });
  } catch (e2) {
    return reply({ ok: false, error: String(e2) });
  }
}

/* Nested bin tree for the Audio page's manual bin picker.
   Bins only - media items are noise in a destination picker. Depth is capped
   so a pathological project cannot stall the panel. */
function DH_binTreeWalk(bin, depth) {
  var out = [], i, child, isBin;
  if (!bin || !bin.children || depth > 8) return out;
  for (i = 0; i < bin.children.numItems; i++) {
    child = bin.children[i];
    if (!child) continue;
    isBin = false;
    try { isBin = (child.type === ProjectItemType.BIN); } catch (eT) { isBin = false; }
    if (!isBin) continue;
    out.push({
      name: String(child.name),
      nodeId: String(child.nodeId),
      children: DH_binTreeWalk(child, depth + 1)
    });
  }
  return out;
}

function DH_binTree(jsonArg) {
  resetLog();
  try {
    if (!app.project) return reply({ ok: false, error: "No project open." });
    return reply({ ok: true, bins: DH_binTreeWalk(app.project.rootItem, 0) });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

/* Open the job root in Finder / Explorer.
 *
 * Premiere's own "Reveal in Finder" lands on the folder holding the .prproj,
 * which in the Harbor template is <job root>/00_PROJECTS/01_Premiere. The
 * template is fixed across Harbor jobs, so the root is exactly two levels
 * above the project file. */
function DH_jobRoot() {
  var projFolder = null, p = "";
  try { p = String(app.project.path || ""); } catch (e) { p = ""; }
  if (!p) return null;
  try {
    var pf = new File(p);
    if (pf && pf.parent) projFolder = pf.parent;   // 01_Premiere
  } catch (e2) { projFolder = null; }
  if (!projFolder) return null;

  var up1 = null, up2 = null;
  try { up1 = projFolder.parent; } catch (e3) { up1 = null; }   // 00_PROJECTS
  try { if (up1) up2 = up1.parent; } catch (e4) { up2 = null; } // job root

  if (up2 && up2.exists) return up2;
  if (up1 && up1.exists) return up1;
  return projFolder;
}

function DH_openJobRoot(jsonArg) {
  resetLog();
  try {
    if (!app.project) return reply({ ok: false, error: "No project open." });

    var pth = "";
    try { pth = String(app.project.path || ""); } catch (eP) { pth = ""; }
    if (!pth) return reply({ ok: false, error: "This project has not been saved yet, so it has no folder to open." });

    var root = DH_jobRoot();
    if (!root || !root.exists) return reply({ ok: false, error: "Could not work out the project root from " + pth });

    var opened = false;
    try { opened = root.execute(); } catch (eE) { opened = false; }
    if (!opened) return reply({ ok: false, error: "Found " + root.fsName + " but the system would not open it." });

    return reply({ ok: true, path: String(root.fsName).replace(/\\/g, "/") });
  } catch (e) {
    return reply({ ok: false, error: String(e) });
  }
}

function DH_addVideoTrack(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var qseq = qeActiveSequence();
    if (!qseq) return reply({ ok: false, error: "Could not open the QE sequence to add a track." });
    var n = seq.videoTracks.numTracks;
    qseq.addTracks(1, n, 0, 0, 0, 0);
    return reply({ ok: true, message: "Video track V" + (n + 1) + " added." });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

function DH_addAudioTrack(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var qseq = qeActiveSequence();
    if (!qseq) return reply({ ok: false, error: "Could not open the QE sequence to add a track." });
    var n = seq.audioTracks.numTracks;
    qseq.addTracks(0, 0, 1, n, 0, 0);
    return reply({ ok: true, message: "Audio track A" + (n + 1) + " added." });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* ===================== Slate: insert the STN slate MOGRT ===================== *
 * Places the matching Slate/Signal Slate_<W>x<H>.mogrt (shipped in the extension) at the
 * head of the active sequence — the sequence start, which by convention is
 * 00:59:53:00 (slate 5s, 2s black, program at 01:00:00:00) — and trims it to
 * exactly 5 seconds of timecode. Track: the lowest track that keeps it
 * visible (V1 when nothing else is at the head), or a new top track. */
var SLATE_LEN_SEC = 5;          // seconds of timecode
var SLATE_START_TC_SEC = 3593;  // 00:59:53:00

/* Index of the highest video track with any clip overlapping [s0,s1) seconds, or -1. */
function highestOverlappingVideoTrack(seq, s0, s1) {
  var vts = seq.videoTracks, hi = -1;
  for (var t = 0; t < vts.numTracks; t++) {
    var clips = vts[t].clips;
    for (var c = 0; c < clips.numItems; c++) {
      var a = -1, b = -1;
      try { a = clips[c].start.seconds; b = clips[c].end.seconds; } catch (e) {}
      if (a < s1 - 0.0005 && b > s0 + 0.0005) { hi = t; break; }
    }
  }
  return hi;
}

function DH_insertSlate(jsonArg) {
  resetLog();
  var a = safeParse(jsonArg);
  var dir = a && a.dir ? String(a.dir) : "";
  if (!app.project || !app.project.activeSequence) return reply({ ok: false, error: "No active sequence." });
  var seq = app.project.activeSequence;

  // Pick the template that matches the sequence's shape: 16:9, 9:16 or square.
  // Files: Slate/Signal Slate_1920x1080.mogrt, _1080x1920.mogrt, _1080x1080.mogrt.
  var W = 0, H = 0;
  try { var st0 = seq.getSettings(); W = Number(st0.videoFrameWidth); H = Number(st0.videoFrameHeight); } catch (eS) {}
  var ar = (W && H) ? W / H : 16 / 9;
  var want = ar > 1.2 ? [1920, 1080] : (ar < 0.8 ? [1080, 1920] : [1080, 1080]);
  var tw = want[0], th = want[1];
  var f = new File(dir + "/Signal Slate_" + tw + "x" + th + ".mogrt");
  if (!f.exists) {
    logMsg("⚠ No " + tw + "×" + th + " slate template yet — using the 1920×1080 one, scaled to fit.", "warn");
    tw = 1920; th = 1080;
    f = new File(dir + "/Signal Slate_1920x1080.mogrt");
  }
  if (!f.exists) return reply({ ok: false, error: "Slate template not found in " + dir });

  var existing = findSlateComponent(seq);
  if (existing) {
    var en = ""; try { en = String(existing.clip.name); } catch (e0) {}
    return reply({ ok: false, exists: true, error: "This sequence already has a slate (" + en + ") — edit it below, or delete it to insert a fresh one." });
  }

  var TPS = 254016000000;
  var tpf = 0; try { tpf = Number(seq.timebase); } catch (e1) {}
  if (!tpf) tpf = TPS / 24;
  var nom = Math.round(TPS / tpf);                       // 24 for 23.976, 30 for 29.97 …
  var lenTicks = SLATE_LEN_SEC * nom * tpf;

  // Sanity-check the sequence start against 00:59:53:00 (drop-frame tolerant).
  var zeroFrames = 0; try { zeroFrames = Number(seq.zeroPoint) / tpf; } catch (e2) {}
  var expected = SLATE_START_TC_SEC * nom;
  var tol = (nom === 30 || nom === 60) ? expected * 0.0012 : 0.5;
  if (Math.abs(zeroFrames - expected) > tol)
    logMsg("⚠ This sequence doesn't start at 00:59:53:00 — the slate was placed at its start anyway. Check the head (slate 5s, 2s black, picture at 01:00:00:00).", "warn");

  // Track: just above anything already at the head, else a new top track.
  var endSec = lenTicks / TPS;
  var hi = highestOverlappingVideoTrack(seq, 0, endSec);
  var vIdx = hi + 1;
  if (vIdx >= seq.videoTracks.numTracks) {
    try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0, 0, 0, 0); }
    catch (e3) { return reply({ ok: false, error: "Couldn't add a video track for the slate: " + e3 }); }
    vIdx = seq.videoTracks.numTracks - 1;
  }

  var item = null;
  try { item = seq.importMGT(f.fsName, "0", vIdx, 0); }
  catch (e4) { return reply({ ok: false, error: "Couldn't insert the slate MOGRT: " + e4 }); }
  if (!item) {   // some versions return nothing — find it on the track
    var tc = seq.videoTracks[vIdx].clips;
    for (var k = 0; k < tc.numItems; k++) { var s = 1; try { s = tc[k].start.seconds; } catch (x) {} if (s < 0.002) { item = tc[k]; break; } }
  }
  if (!item) return reply({ ok: false, error: "Inserted the slate but couldn't find it on V" + (vIdx + 1) + "." });

  try { var endT = new Time(); endT.ticks = String(Math.round(lenTicks)); item.end = endT; }
  catch (e5) { logMsg("⚠ Couldn't trim the slate to 5 seconds: " + e5, "warn"); }
  try { item.name = "Signal Slate"; } catch (e6) {}

  // Fit the template to other frame sizes (e.g. UHD, or a missing size).
  if (W && H && (W !== tw || H !== th)) {
    if (!setMotionScale(item, Math.min(W / tw, H / th) * 100))
      logMsg("⚠ Sequence is " + W + "×" + H + "; couldn't scale the " + tw + "×" + th + " slate — adjust Scale manually.", "warn");
  }
  return reply({ ok: true, message: "Signal Slate (" + tw + "×" + th + ") inserted on V" + (vIdx + 1) + " at the head, 5 seconds." });
}

/* ===================== Prep: TC burn-in layer =====================
   An adjustment layer from 01:00:00:00 to the end of the sequence on the
   TC Burns track, carrying Premiere's "Metadata & Timecode Burn-in" effect
   set to a saved look. The look is captured once from a clip the user has
   set up by hand (Capture), saved to
   ~/Library/Application Support/STN AE Helper/burnin.json, and falls back to
   the copy bundled in the extension's Presets folder. */
var BURNIN_FX = "Metadata & Timecode Burn-in";

function burninStoreFile() {
  var dir = new Folder(Folder.userData.fsName + "/STN AE Helper");
  if (!dir.exists) dir.create();
  return new File(dir.fsName + "/burnin.json");
}
function readTextFile(f) {
  if (!f || !f.exists) return null;
  f.encoding = "UTF-8";
  if (!f.open("r")) return null;
  var t = f.read(); f.close(); return t;
}
function findBurninComponent(trackItem) {
  try {
    var comps = trackItem.components;
    for (var i = 0; i < comps.numItems; i++) {
      var dn = ""; try { dn = String(comps[i].displayName); } catch (e) {}
      if (/metadata/i.test(dn) && /burn/i.test(dn)) return comps[i];
    }
  } catch (e2) {}
  return null;
}
function plainValue(v) {
  var t = typeof v;
  if (t === "number" || t === "boolean" || t === "string") return v;
  if (v && v.length !== undefined && typeof v !== "function") {
    var out = [];
    for (var i = 0; i < v.length; i++) { if (typeof v[i] !== "number") return undefined; out.push(v[i]); }
    return out;
  }
  return undefined;
}

/* Capture: read every parameter of the burn-in effect on the selected clip. */
function DH_captureBurnin(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var sel = null, vts = seq.videoTracks;
    for (var t = 0; t < vts.numTracks && !sel; t++) {
      var clips = vts[t].clips;
      for (var c = 0; c < clips.numItems; c++) {
        var s = false; try { s = clips[c].isSelected(); } catch (e) {}
        if (s && findBurninComponent(clips[c])) { sel = clips[c]; break; }
      }
    }
    if (!sel) return reply({ ok: false, error: "Select the clip or adjustment layer that has your '" + BURNIN_FX + "' effect set up, then Capture." });
    var comp = findBurninComponent(sel), props = comp.properties, params = [], skipped = 0;
    for (var p = 0; p < props.numItems; p++) {
      var nm = ""; try { nm = String(props[p].displayName); } catch (e1) {}
      var v; try { v = plainValue(props[p].getValue()); } catch (e2) { v = undefined; }
      if (v === undefined) { skipped++; continue; }
      params.push({ i: p, n: nm, v: v });
    }
    var data = { effect: BURNIN_FX, captured: String(new Date()), params: params };
    var f = burninStoreFile(); f.encoding = "UTF-8";
    if (!f.open("w")) return reply({ ok: false, error: "Couldn't write " + f.fsName });
    f.write(JSON.stringify(data)); f.close();
    return reply({ ok: true, count: params.length, skipped: skipped, path: f.fsName,
      message: "Captured " + params.length + " burn-in settings from '" + sel.name + "'." });
  } catch (e) { return reply({ ok: false, error: String(e) }); }
}

/* Add: place the burn-in layer from 01:00:00:00 to the sequence end. */
function DH_addBurninLayer(jsonArg) {
  resetLog();
  try {
    var a = safeParse(jsonArg);
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var trackNum = parseInt(a.track, 10) || 5, idx = trackNum - 1;

    // Saved look: user capture first, bundled default second.
    var raw = readTextFile(burninStoreFile()), src = "your captured settings";
    if (!raw && a.ext) { raw = readTextFile(new File(String(a.ext) + "/Presets/STN_Burnin.json")); src = "the bundled default"; }
    var look = null; try { look = raw ? JSON.parse(raw) : null; } catch (ej) { look = null; }

    // Range: 01:00:00:00 (relative to the sequence's start TC) to the end.
    // Work in frames: at 23.976/29.97, an hour of *timecode* is not 3600 real
    // seconds, so 01:00:00:00 = (3600 × nominal fps) frames from 00:00:00:00.
    var tpf = Number(seq.timebase);
    var fpsNom = Math.round(TICKS_PER_SECOND / tpf);
    var zeroFrames = 0; try { zeroFrames = Math.round(Number(seq.zeroPoint) / tpf); } catch (ez) {}
    var startFrames = Math.max(0, 3600 * fpsNom - zeroFrames);
    var startTicks = startFrames * tpf;
    var startSec = startTicks / TICKS_PER_SECOND;
    var endSec = seqEndSeconds(seq);
    if (!(endSec > startSec + 0.01)) return reply({ ok: false, error: "Nothing in the sequence after 01:00:00:00." });
    var endTicks = Math.round(endSec * TICKS_PER_SECOND / tpf) * tpf;

    // Make sure the TC Burns track exists.
    var guard = 0;
    while (seq.videoTracks.numTracks <= idx && guard++ < 20) {
      try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, seq.videoTracks.numTracks, 0, 0, 0, 0); } catch (eA) { break; }
    }
    var track = seq.videoTracks[idx];
    if (!track) return reply({ ok: false, error: "Couldn't find or add V" + trackNum + "." });

    // Clear an earlier burn-in layer; refuse to overwrite real content.
    var tc = track.clips;
    for (var k = tc.numItems - 1; k >= 0; k--) {
      var cl = tc[k];
      if (cl.end.seconds <= startSec + 0.0005 || cl.start.seconds >= endSec - 0.0005) continue;
      var isOurs = /^(stn burn-in|adjustment layer)/i.test(String(cl.name)) || !!findBurninComponent(cl);
      if (!isOurs) return reply({ ok: false, error: "V" + trackNum + " already has '" + cl.name + "' in that range. Clear it, or set TC Burns to an empty track." });
      try { cl.remove(false, false); logMsg("• Replaced the previous burn-in layer on V" + trackNum + ".", ""); } catch (eR) {}
    }

    var adj = getAdjustmentSource(seq);
    if (!adj) return reply({ ok: false, error: "Couldn't find or create an Adjustment Layer. Make one once (File ▸ New ▸ Adjustment Layer) and retry." });
    var durTicks = String(endTicks - startTicks), trimmed = false;
    try { adj.setInPoint("0", 4); adj.setOutPoint(durTicks, 4); trimmed = true; } catch (t1) {}
    if (!trimmed) { try { adj.setInPoint("0"); adj.setOutPoint(durTicks); } catch (t2) {} }

    try { track.overwriteClip(adj, startSec); }
    catch (eO) { return reply({ ok: false, error: "Couldn't place the layer: " + eO }); }

    var added = null, pos = -1;
    tc = seq.videoTracks[idx].clips;
    for (var m = 0; m < tc.numItems; m++) {
      if (Math.abs(tc[m].start.seconds - startSec) < 0.002) { added = tc[m]; pos = m; break; }
    }
    if (!added) return reply({ ok: false, error: "Placed the layer but couldn't find it again on V" + trackNum + "." });
    try { if (Math.abs(Number(added.end.ticks) - endTicks) > tpf / 2) { var te = new Time(); te.ticks = String(endTicks); added.end = te; } } catch (eE) {
      logMsg("⚠ Couldn't stretch the layer to the sequence end — drag its tail out.", "warn"); }
    try { added.name = "STN Burn-in"; } catch (eN) {}

    // Add the effect.
    var fxOk = false;
    try {
      app.enableQE();
      var qTrack = qe.project.getActiveSequence().getVideoTrackAt(idx);
      var qClip = (pos >= 0 && qTrack) ? qeRealClipAt(qTrack, pos) : null;
      var fx = qe.project.getVideoEffectByName(BURNIN_FX);
      if (!fx) return reply({ ok: false, error: "The '" + BURNIN_FX + "' effect wasn't found in this Premiere." });
      if (qClip) { qClip.addVideoEffect(fx); fxOk = true; }
    } catch (eF) { logMsg("⚠ Effect step: " + eF, "warn"); }
    if (!fxOk) return reply({ ok: false, error: "Layer placed on V" + trackNum + ", but the effect couldn't be added — drop '" + BURNIN_FX + "' on it by hand." });

    // Apply the saved look.
    if (!look || !look.params || !look.params.length) {
      return reply({ ok: true, message: "Burn-in layer added on V" + trackNum + " with default effect settings. Set it up once, select it, and hit Capture — later layers will match." });
    }
    var comp = findBurninComponent(added);
    if (!comp) return reply({ ok: true, message: "Burn-in layer added on V" + trackNum + ", but its settings couldn't be applied (effect not visible to scripting)." });
    var props = comp.properties, set = 0, failed = [];
    for (var q = 0; q < look.params.length; q++) {
      var pr = look.params[q], prop = null;
      if (pr.i < props.numItems) {
        var dn = ""; try { dn = String(props[pr.i].displayName); } catch (eD) {}
        if (dn === pr.n) prop = props[pr.i];
      }
      if (!prop) { failed.push(pr.n); continue; }
      try { prop.setValue(pr.v, true); set++; } catch (eS) { failed.push(pr.n + " (#" + pr.i + ")"); }
    }
    if (failed.length) logMsg("⚠ Couldn't set: " + failed.join(", "), "warn");
    return reply({ ok: true, message: "Burn-in layer added on V" + trackNum + " (" + framesToTCsafe(seq, startSec) + " to end), " + set + " settings applied from " + src + "." });
  } catch (e) { return reply({ ok: false, error: String(e) + (e.line ? " (line " + e.line + ")" : "") }); }
}

/* ===================== Prep: Pre-flight & Music/Stock report ===================== */

/* Absolute HH:MM:SS:FF for a sequence-relative tick count (start TC included). */
function tcAtTicks(seq, ticks) {
  try {
    var tpf = Number(seq.timebase), fps = Math.round(TICKS_PER_SECOND / tpf);
    var f = Math.round((Number(ticks) + (Number(seq.zeroPoint) || 0)) / tpf);
    function p(n) { return (n < 10 ? "0" : "") + n; }
    return p(Math.floor(f / (fps * 3600))) + ":" + p(Math.floor(f / (fps * 60)) % 60) + ":" + p(Math.floor(f / fps) % 60) + ":" + p(f % fps);
  } catch (e) { return "?"; }
}
function durTC(seq, ticks) {
  try {
    var tpf = Number(seq.timebase), fps = Math.round(TICKS_PER_SECOND / tpf);
    var f = Math.round(Number(ticks) / tpf);
    function p(n) { return (n < 10 ? "0" : "") + n; }
    return p(Math.floor(f / (fps * 60))) + ":" + p(Math.floor(f / fps) % 60) + ":" + p(f % fps);
  } catch (e) { return "?"; }
}
function clipPath(clip) {
  try { var pi = clip.projectItem; if (pi) return String(pi.getMediaPath() || ""); } catch (e) {}
  return "";
}
function fileOnly(p) { return String(p).replace(/^.*[\/\\]/, ""); }
function inRange(n, lo, hi, on) { return on !== false && n >= lo && n <= hi; }

/* Walk every clip of a track list. fn(clip, trackNumber1Based). */
function eachClip(tracks, fn) {
  for (var t = 0; t < tracks.numTracks; t++) {
    var cl = tracks[t].clips;
    for (var c = 0; c < cl.numItems; c++) fn(cl[c], t + 1);
  }
}

/* Pre-flight: what would make this turnover go out broken. */
function DH_preflight(jsonArg) {
  resetLog();
  try {
    var a = safeParse(jsonArg);
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var L = a.layout || {};
    var clipsLo = L.clipsLow || 1, clipsHi = L.clipsHigh || 99, gfxLo = L.gfxLow || 0, gfxHi = L.gfxHigh || -1, burnLo = L.burnLow || 0, burnHi = L.burnHigh || -1;
    var issues = [];   // { sev: "err"|"warn", what, where[] }
    function add(sev, what, where) {
      for (var i = 0; i < issues.length; i++) if (issues[i].what === what) { if (where) issues[i].where.push(where); return; }
      issues.push({ sev: sev, what: what, where: where ? [where] : [] });
    }
    function at(clip, kind, n) { return kind + n + " " + tcAtTicks(seq, clip.start.ticks) + "  " + clip.name; }

    var vCount = 0, aCount = 0, offline = {}, slateRe = /signal slate|harbor slate|\bslate\b/i;

    eachClip(seq.videoTracks, function (clip, n) {
      vCount++;
      var pi = null; try { pi = clip.projectItem; } catch (e) {}
      var isMGT = false; try { isMGT = !!(clip.isMGT && clip.isMGT()); } catch (e1) {}
      var isSlate = isMGT && slateRe.test(String(clip.name));
      var isBurn = !!findBurninComponent(clip);
      var isAdj = /^adjustment layer|^stn burn-in/i.test(String(clip.name));
      if (pi) {
        var off = false; try { off = pi.isOffline(); } catch (e2) {}
        if (off && !offline[pi.nodeId]) { offline[pi.nodeId] = 1; add("err", "Offline media", at(clip, "V", n)); }
        var nested = false; try { nested = pi.isSequence(); } catch (e3) {}
        if (nested) add("warn", "Nested sequences (flatten or confirm the conform can read them)", at(clip, "V", n));
        var mc = false; try { mc = pi.isMulticamClip && pi.isMulticamClip(); } catch (e4) {}
        if (mc) add("warn", "Multicam clips (flatten before turnover)", at(clip, "V", n));
      }
      var dis = false; try { dis = clip.disabled; } catch (e5) {}
      if (dis && !isSlate) add("warn", "Disabled clips (they still travel in the XML)", at(clip, "V", n));
      var sp = 1; try { sp = clip.getSpeed(); } catch (e6) {}
      var rev = false; try { rev = clip.isSpeedReversed(); } catch (e7) {}
      if (rev) add("warn", "Reversed clips", at(clip, "V", n));
      else if (Math.abs(sp - 1) > 0.0001) add("warn", "Speed changes (" + "check the conform honours them)", at(clip, "V", n) + "  @" + Math.round(sp * 100) + "%");

      if (isSlate) return;
      if (isBurn || (isAdj && inRange(n, burnLo, burnHi, a.burnOn))) {
        if (!inRange(n, burnLo, burnHi, a.burnOn)) add("err", "Burn-in layer outside the TC Burns tracks (it would end up in the clean ref and XML)", at(clip, "V", n));
        return;
      }
      if (isMGT) {
        if (!inRange(n, gfxLo, gfxHi, a.gfxOn)) add("warn", "Graphics/MOGRTs outside the Graphics tracks (Color would receive them)", at(clip, "V", n));
        return;
      }
      if (inRange(n, gfxLo, gfxHi, a.gfxOn) || inRange(n, burnLo, burnHi, a.burnOn) || inRange(n, clipsLo, clipsHi, a.clipsOn)) return;
      add("warn", "Clips on tracks outside the Track layout ranges", at(clip, "V", n));
    });

    eachClip(seq.audioTracks, function (clip, n) {
      aCount++;
      var pi = null; try { pi = clip.projectItem; } catch (e) {}
      if (pi) {
        var off = false; try { off = pi.isOffline(); } catch (e2) {}
        if (off && !offline[pi.nodeId]) { offline[pi.nodeId] = 1; add("err", "Offline media", at(clip, "A", n)); }
      }
    });

    // Variable speed (time remapping) needs the XML round-trip to detect.
    var vs = null; try { vs = vsCollectHits(seq); } catch (eV) {}
    if (vs && vs.ok && vs.hits.length) {
      for (var h = 0; h < vs.hits.length; h++) add("warn", "Variable speed / time remap (use 'Convert Variable Speed Clips' before turnover)", "V" + vs.hits[h].track + "  " + vs.hits[h].name);
    }

    // In/Out
    var rng = readMarkedRange(seq);
    var note = rng ? "In/Out set: references will render " + framesToTCsafe(seq, rng.inSec) + " – " + framesToTCsafe(seq, rng.outSec) + "."
                   : "No In/Out set: references will render the whole sequence.";

    var errs = 0, warns = 0;
    for (var k = 0; k < issues.length; k++) { if (issues[k].sev === "err") errs++; else warns++; }
    return reply({ ok: true, issues: issues, errors: errs, warnings: warns, note: note,
      summary: vCount + " video and " + aCount + " audio clips checked on '" + seq.name + "'." });
  } catch (e) { return reply({ ok: false, error: String(e) + (e.line ? " (line " + e.line + ")" : "") }); }
}

/* Music & stock: every use in the cut, flags, and a CSV beside the project. */
var STOCK_RE = /adobestock|adobe ?stock|istock|getty|shutterstock|pond5|storyblocks|videoblocks|artgrid|artlist|envato|filmsupply|stocksy|dissolve|motion ?array|motionelements|\bstock\b/i;
var STOCK_COMP_RE = /preview|watermark|_wm\b|\bwm\b|\bcomp\b|_comp\b|\bfpo\b|\bsample\b/i;
var MUSIC_RE = /music|\bsongs?\b|\bscore\b|\bcues?\b|soundtrack|artlist|musicbed|epidemic|soundstripe|audio ?network|\bapm\b|extreme music|universal production|marmoset|songtradr|premiumbeat|audiojungle|\bmx\b/i;
var VO_RE = /01_vo|stn_vo|[\/_ ]vo[\/_ ]|voice ?over|\bvo\b|narration|\bsfx\b|sound ?effects|dialog|dialogue|\bdx\b/i;
var TEMP_RE = /\btemp\b|_temp|temp_|\btmp\b|scratch|placeholder|\bdemo\b|\bref\b|_ref\b|reference|uncleared/i;

function csvRow(arr) { var o = []; for (var i = 0; i < arr.length; i++) o.push(csvCell(arr[i])); return o.join(","); }
function csvCell(v) { v = String(v === undefined || v === null ? "" : v); return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; }

function DH_musicStockReport(jsonArg) {
  resetLog();
  try {
    var seq = app.project.activeSequence;
    if (!seq) return reply({ ok: false, error: "No active sequence." });
    var music = [], stock = [];

    eachClip(seq.audioTracks, function (clip, n) {
      var p = clipPath(clip), hay = p + " " + clip.name;
      if (!p || VO_RE.test(hay) || !MUSIC_RE.test(hay)) return;
      music.push({ track: "A" + n, title: String(clip.name), file: fileOnly(p), path: p,
        tin: tcAtTicks(seq, clip.start.ticks), tout: tcAtTicks(seq, clip.end.ticks),
        dur: durTC(seq, Number(clip.end.ticks) - Number(clip.start.ticks)),
        durSec: (Number(clip.end.ticks) - Number(clip.start.ticks)) / TICKS_PER_SECOND,
        flag: TEMP_RE.test(hay) ? "TEMP / uncleared?" : "" });
    });
    eachClip(seq.videoTracks, function (clip, n) {
      var p = clipPath(clip), hay = p + " " + clip.name;
      if (!p || !STOCK_RE.test(hay)) return;
      stock.push({ track: "V" + n, title: String(clip.name), file: fileOnly(p), path: p,
        tin: tcAtTicks(seq, clip.start.ticks), tout: tcAtTicks(seq, clip.end.ticks),
        dur: durTC(seq, Number(clip.end.ticks) - Number(clip.start.ticks)),
        durSec: (Number(clip.end.ticks) - Number(clip.start.ticks)) / TICKS_PER_SECOND,
        flag: STOCK_COMP_RE.test(hay) ? "COMP / watermarked?" : "" });
    });
    function byTime(x, y) { return x.tin < y.tin ? -1 : x.tin > y.tin ? 1 : 0; }
    music.sort(byTime); stock.sort(byTime);

    // Cue-sheet style totals per music file.
    var totals = {}, order = [];
    for (var i = 0; i < music.length; i++) {
      var k = music[i].file;
      if (!totals[k]) { totals[k] = { uses: 0, sec: 0 }; order.push(k); }
      totals[k].uses++; totals[k].sec += music[i].durSec;
    }

    var csvPath = "";
    if (music.length || stock.length) {
      var rows = ["Type,Track,In,Out,Duration,Title,File,Flag,Path"];
      var all = music.concat(stock);
      for (var r = 0; r < all.length; r++) {
        var u = all[r];
        rows.push(csvRow([u.track.charAt(0) === "A" ? "Music" : "Stock", u.track, u.tin, u.tout, u.dur, u.title, u.file, u.flag, u.path]));
      }
      rows.push("");
      rows.push("Music totals (cue sheet),,,,,,,,");
      rows.push("File,Uses,Total seconds,,,,,,");
      for (var o = 0; o < order.length; o++) rows.push(csvRow([order[o], totals[order[o]].uses, Math.round(totals[order[o]].sec * 100) / 100]) + ",,,,,,");
      try {
        var proj = new File(app.project.path), dir = proj.parent;
        var f = new File(dir.fsName + "/" + sanitize(seq.name) + "_MusicStock_" + DH_mmdd() + ".csv");
        f.encoding = "UTF-8";
        if (f.open("w")) { f.write(rows.join("\n")); f.close(); csvPath = f.fsName; }
      } catch (eW) { logMsg("⚠ Couldn't write the CSV: " + eW, "warn"); }
    }
    var tots = [];
    for (var q = 0; q < order.length; q++) tots.push({ file: order[q], uses: totals[order[q]].uses, sec: Math.round(totals[order[q]].sec * 10) / 10 });
    return reply({ ok: true, music: music, stock: stock, totals: tots, csv: csvPath });
  } catch (e) { return reply({ ok: false, error: String(e) + (e.line ? " (line " + e.line + ")" : "") }); }
}
